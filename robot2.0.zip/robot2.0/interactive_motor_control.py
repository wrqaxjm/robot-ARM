#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
交互式电机控制工具
基于motor_can_lib库，支持电机使能、速度控制和停止命令
专为CANable设备设计，支持COM11端口，500K波特率
"""

import sys
import time
from typing import Optional

# 导入motor_can_lib库
from motor_can_lib import (
    MotorCANBase, CANError, CANTimeoutError,
    EnableControlCommand, SpeedControlCommand, StopControlCommand, PositionControlCommand, SyncControlCommand, HomingControlCommand,
    EnableResponse, SpeedResponse, StopResponse, PositionResponse, SyncResponse, HomingResponse,
    # 新增诊断读取支持
    DiagnosticCommand, DiagnosticResponse
)


class InteractiveMotorControl:
    """交互式电机控制工具类"""
    
    def __init__(self):
        """初始化电机控制工具"""
        # 默认配置参数
        self.com_port = "COM11"
        self.bitrate = 500000
        self.timeout = 2.0
        self.current_address = 1  # 当前操作的电机地址
        
        # 创建CAN通信基础实例
        self.can_base = MotorCANBase(
            com_port=self.com_port,
            bitrate=self.bitrate,
            timeout=self.timeout
        )
        
    def show_main_menu(self):
        """显示主菜单"""
        print("\n" + "="*60)
        print("                交互式电机控制工具")
        print("="*60)
        print(f"配置信息:")
        print(f"  端口: {self.com_port}")
        print(f"  波特率: {self.bitrate} bps")
        print(f"  超时时间: {self.timeout}s")
        print(f"  当前电机地址: {self.current_address}")
        print(f"  连接状态: {'已连接' if self.can_base.is_connected else '未连接'}")
        print("-"*60)
        print("请选择操作:")
        print("  1. 连接CAN设备")
        print("  2. 电机使能控制")
        print("  3. 电机速度控制")
        print("  4. 电机位置控制")
        print("  5. 电机停止控制")
        print("  6. 多机同步运动")
        print("  7. 原点回零控制")
        print("  11. 读取模式（诊断/状态查询）")
        print("  8. 设置电机地址")
        print("  9. 设置通信参数")
        print("  10. 断开连接")
        print("  0. 退出程序")
        print("-"*60)
    
    def connect_device(self):
        """连接CAN设备"""
        print(f"\n正在连接到 {self.com_port}...")
        
        if self.can_base.connect():
            print("✓ CAN设备连接成功!")
            print("✓ 可以开始进行电机控制操作")
        else:
            print("✗ CAN设备连接失败")
            print("请检查:")
            print("  - CANable设备是否正确连接")
            print("  - COM端口是否正确")
            print("  - 设备是否被其他程序占用")
    
    def disconnect_device(self):
        """断开设备连接"""
        if self.can_base.disconnect():
            print("✓ CAN设备已断开连接")
        else:
            print("✗ 断开连接时出现问题")
    
    def motor_enable_control(self):
        """电机使能控制"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 电机使能控制 (地址: {self.current_address}) ===")
        print("请选择操作:")
        print("  1. 使能电机")
        print("  2. 禁用电机")
        print("  0. 返回主菜单")
        
        choice = input("请输入选择 (0-2): ").strip()
        
        if choice == "0":
            return
        elif choice in ["1", "2"]:
            enable_state = choice == "1"
            
            # 询问是否启用多机同步
            multi_sync_input = input("是否启用多机同步? (y/N): ").strip().lower()
            multi_sync = multi_sync_input in ['y', 'yes', '是']
            
            try:
                # 创建使能控制命令
                if enable_state:
                    cmd = EnableControlCommand.create_enable_command(
                        address=self.current_address, 
                        multi_sync=multi_sync
                    )
                else:
                    cmd = EnableControlCommand.create_disable_command(
                        address=self.current_address, 
                        multi_sync=multi_sync
                    )
                
                # 执行命令
                print(f"\n正在{'使能' if enable_state else '禁用'}电机...")
                response_data = cmd.execute(self.can_base, timeout=self.timeout)
                
                if response_data:
                    # 解析响应
                    response = EnableResponse(response_data)
                    response.print_summary()
                    
                    if response.is_success():
                        print(f"✓ 电机{'使能' if enable_state else '禁用'}成功!")
                    else:
                        print(f"✗ 电机{'使能' if enable_state else '禁用'}失败: {response.get_status_meaning()}")
                else:
                    print("✗ 未收到响应数据")
                    
            except (CANError, CANTimeoutError) as e:
                print(f"✗ 命令执行失败: {e}")
            except Exception as e:
                print(f"✗ 发生未知错误: {e}")
        else:
            print("✗ 无效选择")
    
    def motor_speed_control(self):
        """电机速度控制"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 电机速度控制 (地址: {self.current_address}) ===")
        
        try:
            # 获取速度参数
            speed_input = input("请输入目标速度 (RPM, 0-65535): ").strip()
            if not speed_input:
                print("✗ 速度不能为空")
                return
            
            speed_rpm = int(speed_input)
            if speed_rpm < 0 or speed_rpm > 65535:
                print("✗ 速度值超出范围 (0-65535)")
                return
            
            # 获取方向参数
            print("请选择旋转方向:")
            print("  0. 顺时针 (CW)")
            print("  1. 逆时针 (CCW)")
            direction_input = input("请输入方向 (0/1): ").strip()
            
            if direction_input not in ["0", "1"]:
                print("✗ 方向必须是 0 或 1")
                return
            
            direction = int(direction_input)
            
            # 获取加速度参数
            accel_input = input("请输入加速度档位 (0-255, 默认10): ").strip()
            acceleration = 10  # 默认值
            if accel_input:
                acceleration = int(accel_input)
                if acceleration < 0 or acceleration > 255:
                    print("✗ 加速度档位超出范围 (0-255)")
                    return
            
            # 询问是否启用多机同步
            multi_sync_input = input("是否启用多机同步? (y/N): ").strip().lower()
            multi_sync = multi_sync_input in ['y', 'yes', '是']
            
            # 创建速度控制命令
            cmd = SpeedControlCommand.create_speed_command(
                speed_rpm=speed_rpm,
                direction=direction,
                acceleration=acceleration,
                address=self.current_address,
                multi_sync=multi_sync
            )
            
            # 执行命令
            print(f"\n正在设置电机速度...")
            response_data = cmd.execute(self.can_base, timeout=self.timeout)
            
            if response_data:
                # 解析响应
                response = SpeedResponse(response_data)
                response.print_summary()
                
                if response.is_success():
                    print("✓ 速度设置成功!")
                else:
                    print(f"✗ 速度设置失败: {response.get_status_meaning()}")
            else:
                print("✗ 未收到响应数据")
                
        except ValueError as e:
            print(f"✗ 输入格式错误: {e}")
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def motor_position_control(self):
        """电机位置控制（支持分包发送）"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 电机位置控制 (地址: {self.current_address}) ===")
        print("注意: 位置控制命令大于8字节，将使用分包发送")
        
        try:
            # 获取脉冲数参数
            pulse_input = input("请输入目标脉冲数 (0-4294967295): ").strip()
            if not pulse_input:
                print("✗ 脉冲数不能为空")
                return
            
            pulse_count = int(pulse_input)
            if pulse_count < 0 or pulse_count > 4294967295:
                print("✗ 脉冲数超出范围 (0-4294967295)")
                return
            
            # 获取方向参数
            print("请选择旋转方向:")
            print("  0. 顺时针 (CW)")
            print("  1. 逆时针 (CCW)")
            direction_input = input("请输入方向 (0/1): ").strip()
            
            if direction_input not in ["0", "1"]:
                print("✗ 方向必须是 0 或 1")
                return
            
            direction = int(direction_input)
            
            # 获取速度参数
            speed_input = input("请输入运行速度 (RPM, 1-65535, 默认1000): ").strip()
            speed_rpm = 1000  # 默认值
            if speed_input:
                speed_rpm = int(speed_input)
                if speed_rpm < 1 or speed_rpm > 65535:
                    print("✗ 速度值超出范围 (1-65535)")
                    return
            
            # 获取加速度参数
            accel_input = input("请输入加速度档位 (0-255, 默认10): ").strip()
            acceleration = 10  # 默认值
            if accel_input:
                acceleration = int(accel_input)
                if acceleration < 0 or acceleration > 255:
                    print("✗ 加速度档位超出范围 (0-255)")
                    return
            
            # 获取位置模式参数
            print("请选择位置模式:")
            print("  0. 绝对位置模式")
            print("  1. 相对位置模式")
            position_mode_input = input("请输入位置模式 (0/1, 默认0): ").strip()
            position_mode = 0  # 默认绝对位置模式
            if position_mode_input:
                if position_mode_input not in ["0", "1"]:
                    print("✗ 位置模式必须是 0 或 1")
                    return
                position_mode = int(position_mode_input)
            
            # 询问是否启用多机同步
            multi_sync_input = input("是否启用多机同步? (y/N): ").strip().lower()
            multi_sync = multi_sync_input in ['y', 'yes', '是']
            
            # 创建位置控制命令
            cmd = PositionControlCommand.create_position_command(
                pulse_count=pulse_count,
                direction=direction,
                speed_rpm=speed_rpm,
                acceleration=acceleration,
                position_mode=position_mode,
                address=self.current_address,
                multi_sync=multi_sync
            )
            
            # 执行命令（支持分包发送）
            print(f"\n正在执行位置控制...")
            print(f"  目标脉冲数: {pulse_count}")
            print(f"  方向: {'逆时针' if direction else '顺时针'}")
            print(f"  速度: {speed_rpm} RPM")
            print(f"  加速度: {acceleration}")
            print(f"  位置模式: {'相对位置' if position_mode else '绝对位置'}")
            print(f"  多机同步: {'是' if multi_sync else '否'}")
            
            response_data = cmd.execute(self.can_base, timeout=self.timeout)
            
            if response_data:
                # 解析响应
                response = PositionResponse(response_data)
                response.print_summary()
                
                if response.is_success():
                    print("✓ 位置控制命令发送成功!")
                    print("电机将开始移动到目标位置")
                else:
                    print(f"✗ 位置控制失败: {response.get_status_meaning()}")
            else:
                print("✗ 未收到响应数据")
                
        except ValueError as e:
            print(f"✗ 输入格式错误: {e}")
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def motor_stop_control(self):
        """电机停止控制"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 电机停止控制 (地址: {self.current_address}) ===")
        
        # 询问是否启用多机同步
        multi_sync_input = input("是否启用多机同步? (y/N): ").strip().lower()
        multi_sync = multi_sync_input in ['y', 'yes', '是']
        
        try:
            # 创建停止控制命令
            cmd = StopControlCommand.create_stop_command(
                address=self.current_address,
                multi_sync=multi_sync
            )
            
            # 执行命令
            print(f"\n正在停止电机...")
            response_data = cmd.execute(self.can_base, timeout=self.timeout)
            
            if response_data:
                # 解析响应
                response = StopResponse(response_data)
                response.print_summary()
                
                if response.is_success():
                    print("✓ 电机停止成功!")
                else:
                    print(f"✗ 电机停止失败: {response.get_status_meaning()}")
            else:
                print("✗ 未收到响应数据")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def motor_sync_control(self):
        """多机同步运动控制"""
        print(f"\n=== 多机同步运动控制 ===")
        print("多机同步运动有两种模式：")
        print()
        print("1. 广播模式同步运动：")
        print("   - 使用帧ID为00的广播地址")
        print("   - 直接发送运动指令，所有电机立即运动")
        print("   - 只有地址1的电机会反馈信息")
        print("   - 无法控制特定几个电机")
        print()
        print("2. 指定地址同步运动：")
        print("   - 先在其他模式下给不同地址电机发送带同步标志的指令")
        print("   - 电机收到命令但不会立即运动（等待同步触发）")
        print("   - 发送固定的同步触发命令：00 FF 66 6B")
        print("   - 所有设置了同步标志的电机会同时开始运动")
        print("-" * 60)
        
        if not self.can_base.is_connected:
            print("✗ 请先连接CAN设备")
            return
        
        print("请选择操作：")
        print("  1. 发送同步触发命令（用于指定地址同步运动）")
        print("  2. 查看使用说明")
        print("  0. 返回主菜单")
        
        try:
            choice = input("请输入选择 (0-2): ").strip()
            
            if choice == "0":
                return
            elif choice == "1":
                # 发送同步触发命令
                print(f"\n--- 同步触发命令 ---")
                print("即将发送固定的同步触发命令：00 FF 66 6B")
                print("注意：")
                print("- 只有预先设置了同步标志的电机会响应此命令")
                print("- 只有地址1的电机会回复响应")
                print("- 所有设置了同步标志的电机会同时开始运动")
                print()
                
                confirm = input("确认发送同步触发命令? (y/N): ").strip().lower()
                if confirm != 'y':
                    print("✗ 操作已取消")
                    return
                
                # 创建同步触发命令
                sync_cmd = SyncControlCommand.create_sync_command()
                
                # 执行同步命令
                print(f"\n正在发送同步触发命令...")
                response_data = sync_cmd.execute(self.can_base, timeout=self.timeout)
                
                if response_data:
                    # 解析响应
                    response = SyncResponse(response_data)
                    print(f"\n--- 响应解析 ---")
                    print(f"响应地址: {response.address}")
                    print(f"命令状态: {response.get_status_description()}")
                    
                    if response.is_success():
                        print("✓ 同步触发命令执行成功！")
                        print("所有设置了同步标志的电机现在应该开始同步运动")
                    else:
                        print(f"✗ 同步触发命令失败: {response.get_status_description()}")
                        if response.status and hasattr(response.status, 'name') and response.status.name == "CONDITION_NOT_MET":
                            print("  可能原因：")
                            print("  - 没有电机设置了同步标志")
                            print("  - 电机触发了堵转保护")
                            print("  - 电机没有使能")
                            print("  建议：先在位置/速度控制中设置多机同步标志")
                else:
                    print("✗ 未收到响应数据")
                    print("  可能原因：")
                    print("  - 地址1的电机不在线")
                    print("  - CAN通信故障")
                    print("  - 没有电机设置了同步标志")
                    
            elif choice == "2":
                # 显示使用说明
                self._show_sync_usage_guide()
            else:
                print("✗ 无效选择")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")

    def motor_read_mode(self):
        """诊断读取模式（选择读取命令，发送并解析打印）"""
        # 读取模式参考其它模式的参数配置与异常处理
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return

        print(f"\n=== 读取模式 (地址: {self.current_address}) ===")
        print("请选择读取命令：")
        print("  1. 读取固件/硬件版本 (0x1F)")
        print("  2. 读取相电阻/相电感 (0x20)")
        print("  3. 读取位置环PID参数 (0x21)")
        print("  4. 读取总线电压 (0x24)")
        print("  5. 读取相电流 (0x27)")
        print("  6. 读取电机实时转速 (0x35)")
        print("  7. 读取电机实时位置 (0x36)")
        print("  8. 读取电机位置误差 (0x37)")
        print("  9. 读取电机状态标志位 (0x3A)")
        print("  10. 读取驱动配置参数 (0x42 0x6C)")
        print("  11. 读取系统状态参数 (0x43 0x7A)")
        print("  0. 返回主菜单")

        choice = input("请输入选择 (0-11): ").strip()
        if choice == "0":
            return

        # 映射选择到具体执行方法与命令码
        # 说明：命令数据不包含地址，地址在CAN ID；首字节为命令码，最后一字节为校验0x6B
        cmd = DiagnosticCommand.create(address=self.current_address)

        # 定义执行表：key=菜单项，value=(调用方法, 期望命令码)
        exec_table = {
            "1": (cmd.execute_read_fw_hw_version, 0x1F),
            "2": (cmd.execute_read_phase_res_ind, 0x20),
            "3": (cmd.execute_read_position_pid, 0x21),
            "4": (cmd.execute_read_bus_voltage, 0x24),
            "5": (cmd.execute_read_phase_current, 0x27),
            "6": (cmd.execute_read_motor_speed, 0x35),
            "7": (cmd.execute_read_motor_position, 0x36),
            "8": (cmd.execute_read_position_error, 0x37),
            "9": (cmd.execute_read_motor_state_flags, 0x3A),
            "10": (cmd.execute_read_driver_config, 0x42),
            "11": (cmd.execute_read_system_status, 0x43),
        }

        if choice not in exec_table:
            print("✗ 无效选择")
            return

        exec_fn, expect_code = exec_table[choice]

        try:
            print("\n正在发送读取命令...")
            response_data = exec_fn(self.can_base, timeout=self.timeout)

            if not response_data:
                print("✗ 未收到响应数据")
                return

            # 响应解析：按命令码分派到对应解析函数
            # 注意：仅支持新格式（首字节为命令码）
            parsed = DiagnosticResponse.parse_response(
                response_data=response_data,
                command_code=expect_code,
                address=self.current_address
            )

            # 打印解析结果
            print("\n--- 响应解析 ---")
            # 统一打印常用字段，如果存在则输出
            def _print_if_exists(label: str, key: str):
                if key in parsed:
                    val = parsed[key]
                    if isinstance(val, (bytes, bytearray)):
                        print(f"{label}: {' '.join(f'{b:02X}' for b in val)}")
                    else:
                        print(f"{label}: {val}")

            # 基本信息
            _print_if_exists("地址", 'address')
            _print_if_exists("命令码", 'command_code')
            _print_if_exists("原始数据", 'raw_data')

            # 分类信息（根据不同命令可能存在）
            _print_if_exists("固件版本码", 'firmware_code')
            _print_if_exists("硬件版本码", 'hardware_code')
            _print_if_exists("相电阻(mΩ)", 'phase_resistance_milliohm')
            _print_if_exists("相电感(µH)", 'phase_inductance_uH')
            _print_if_exists("Kp", 'Kp')
            _print_if_exists("Ki", 'Ki')
            _print_if_exists("Kd", 'Kd')
            _print_if_exists("总线电压(mV)", 'bus_voltage_mv')
            _print_if_exists("相电流(mA)", 'phase_current_ma')
            _print_if_exists("速度符号", 'sign')
            _print_if_exists("速度(RPM)", 'speed_rpm')
            _print_if_exists("位置原始值", 'position_raw')
            _print_if_exists("位置(度)", 'position_degrees')
            _print_if_exists("位置误差原始值", 'error_raw')
            _print_if_exists("位置误差(度)", 'error_degrees')
            _print_if_exists("状态标志字节", 'flags_byte')
            _print_if_exists("已使能", 'enabled')
            _print_if_exists("到位", 'in_position')
            _print_if_exists("堵转", 'stalled')
            _print_if_exists("堵转保护", 'stall_protection')
            _print_if_exists("总长度", 'total_len')
            _print_if_exists("参数个数", 'param_count')
            _print_if_exists("负载数据", 'payload')

            # 针对驱动配置（0x42 0x6C）输出更详细的字段，便于用户直接查看
            if expect_code == 0x42:
                print("\n--- 驱动配置明细 ---")
                _print_if_exists("电机类型", 'motor_type_desc')
                _print_if_exists("电机类型码", 'motor_type_code')
                _print_if_exists("脉冲控制模式", 'pulse_mode_desc')
                _print_if_exists("脉冲控制模式码", 'pulse_mode_code')
                _print_if_exists("通讯复用模式", 'comm_func_desc')
                _print_if_exists("通讯复用模式码", 'comm_func_code')
                _print_if_exists("En引脚有效电平", 'en_level_desc')
                _print_if_exists("En引脚码", 'en_level_code')
                _print_if_exists("Dir方向", 'dir_desc')
                _print_if_exists("Dir码", 'dir_code')
                _print_if_exists("细分值", 'subdivision_value')
                _print_if_exists("细分原始码", 'subdivision_raw')
                _print_if_exists("细分插补开启", 'subdivision_interp_enabled')
                _print_if_exists("自动熄屏开启", 'auto_screen_off_enabled')
                _print_if_exists("开环工作电流(mA)", 'open_loop_current_ma')
                _print_if_exists("堵转最大电流(mA)", 'stall_max_current_ma')
                _print_if_exists("闭环最大输出电压(mV)", 'max_output_voltage_mv')
                _print_if_exists("串口波特率", 'uart_baud_rate')
                _print_if_exists("串口波特率选项码", 'uart_baud_option')
                _print_if_exists("CAN速率", 'can_bitrate_value')
                _print_if_exists("CAN速率选项码", 'can_bitrate_option')
                _print_if_exists("设备ID", 'device_id')
                _print_if_exists("校验模式", 'checksum_mode_desc')
                _print_if_exists("校验模式码", 'checksum_mode_code')
                _print_if_exists("命令应答模式", 'command_ack_mode_desc')
                _print_if_exists("命令应答模式码", 'command_ack_mode_code')
                _print_if_exists("堵转保护开启", 'stall_protect_enabled')
                _print_if_exists("堵转速度阈值(RPM)", 'stall_speed_threshold_rpm')
                _print_if_exists("堵转电流阈值(mA)", 'stall_current_threshold_ma')
                _print_if_exists("堵转检测时间阈值(ms)", 'stall_time_threshold_ms')
                _print_if_exists("位置到达窗口原始值", 'position_window_raw')
                _print_if_exists("位置到达窗口(度)", 'position_window_deg')

            # 针对系统状态（0x43 0x7A）输出更详细的字段
            if expect_code == 0x43:
                print("\n--- 系统状态明细 ---")
                _print_if_exists("总线电压(mV)", 'bus_voltage_mv')
                _print_if_exists("总线相电流(mA)", 'phase_current_ma')
                _print_if_exists("校准后编码器值", 'encoder_calibrated_value')
                _print_if_exists("目标位置符号", 'target_position_sign')
                _print_if_exists("目标位置原始值", 'target_position_raw')
                _print_if_exists("目标位置(度)", 'target_position_degrees')
                _print_if_exists("速度符号", 'speed_sign')
                _print_if_exists("速度(RPM)", 'speed_rpm')
                _print_if_exists("实时位置符号", 'position_sign')
                _print_if_exists("实时位置原始值", 'position_raw')
                _print_if_exists("实时位置(度)", 'position_degrees')
                _print_if_exists("位置误差符号", 'error_sign')
                _print_if_exists("位置误差原始值", 'error_raw')
                _print_if_exists("位置误差(度)", 'error_degrees')
                _print_if_exists("就绪状态标志字节", 'ready_flags_byte')
                _print_if_exists("编码器就绪", 'encoder_ready')
                _print_if_exists("校准表就绪", 'calibration_table_ready')
                _print_if_exists("正在回零", 'homing_running')
                _print_if_exists("回零失败", 'homing_failed')
                _print_if_exists("电机状态标志字节", 'motor_state_flags_byte')
                _print_if_exists("已使能", 'enabled')
                _print_if_exists("到位", 'in_position')
                _print_if_exists("堵转", 'stalled')
                _print_if_exists("堵转保护", 'stall_protection')

            print("\n✓ 读取命令执行完成")

        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")

    def _show_sync_usage_guide(self):
        """显示同步运动使用说明"""
        print(f"\n=== 多机同步运动使用说明 ===")
        print()
        print("【指定地址同步运动的完整流程】")
        print()
        print("步骤1：设置同步标志")
        print("  - 进入位置控制或速度控制菜单")
        print("  - 为需要同步的电机发送命令时，选择'是否启用多机同步? (y/N): y'")
        print("  - 电机收到命令但不会立即运动，等待同步触发")
        print()
        print("步骤2：发送同步触发")
        print("  - 进入多机同步运动菜单")
        print("  - 选择'发送同步触发命令'")
        print("  - 系统发送固定命令：00 FF 66 6B")
        print("  - 所有设置了同步标志的电机同时开始运动")
        print()
        print("【示例操作流程】")
        print("1. 给地址1电机发送位置命令，启用多机同步")
        print("2. 给地址2电机发送位置命令，启用多机同步")
        print("3. 发送同步触发命令")
        print("4. 地址1和2的电机同时开始运动")
        print()
        print("【注意事项】")
        print("- 广播模式（帧ID=00）会让所有电机立即运动，不需要同步触发")
        print("- 同步触发命令是固定的，不需要指定地址")
        print("- 只有地址1的电机会回复同步触发命令的响应")
        print("- 如果没有电机设置同步标志，同步触发命令不会有效果")
        
        input("\n按回车键返回...")
    
    def motor_homing_control(self):
        """原点回零控制"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 原点回零控制 (地址: {self.current_address}) ===")
        print("请选择操作:")
        print("  1. 设置单圈回零的零点位置")
        print("  2. 触发回零")
        print("  3. 强制中断并退出回零操作")
        print("  4. 读取原点回零参数")
        print("  5. 修改原点回零参数")
        print("  6. 读取回零状态标志位")
        print("  7. 显示回零使用说明")
        print("  0. 返回主菜单")
        
        choice = input("请输入选择 (0-7): ").strip()
        
        if choice == "0":
            return
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            if choice == "1":
                # 设置单圈回零的零点位置
                print("\n--- 设置单圈回零的零点位置 ---")
                save_choice = input("是否保存到Flash? (Y/n): ").strip().lower()
                save_to_flash = save_choice != 'n'
                
                print(f"正在设置零点位置 (保存到Flash: {'是' if save_to_flash else '否'})...")
                response_data = homing_cmd.execute_set_zero_position(
                    self.can_base, save_to_flash, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示（数据新格式不含地址）
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_set_zero_position_response()
                    if result['success']:
                        print("✓ 零点位置设置成功")
                    else:
                        print("✗ 零点位置设置失败")
                else:
                    print("✗ 未收到响应，设置可能失败")
            
            elif choice == "2":
                # 触发回零
                print("\n--- 触发回零 ---")
                print("回零模式:")
                print("  0. 单圈就近回零")
                print("  1. 单圈方向回零")
                print("  2. 多圈无限位碰撞回零")
                print("  3. 多圈有限位开关回零")
                
                mode_input = input("请选择回零模式 (0-3): ").strip()
                if not mode_input.isdigit() or int(mode_input) not in [0, 1, 2, 3]:
                    print("✗ 无效的回零模式")
                    return
                
                homing_mode = int(mode_input)
                sync_choice = input("是否启用多机同步? (y/N): ").strip().lower()
                multi_sync = sync_choice == 'y'
                
                print(f"正在触发回零 (模式: {homing_mode}, 多机同步: {'是' if multi_sync else '否'})...")
                response_data = homing_cmd.execute_trigger_homing(
                    self.can_base, homing_mode, multi_sync, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_trigger_homing_response()
                    if result['success']:
                        print("✓ 回零命令发送成功")
                        print("注意：回零过程可能需要一些时间，请使用'读取回零状态'查看进度")
                    else:
                        print("✗ 回零命令发送失败")
                else:
                    print("✗ 未收到响应，命令可能失败")
            
            elif choice == "3":
                # 强制中断并退出回零操作
                print("\n--- 强制中断并退出回零操作 ---")
                confirm = input("确认要强制停止回零操作吗? (y/N): ").strip().lower()
                if confirm != 'y':
                    print("操作已取消")
                    return
                
                print("正在强制停止回零操作...")
                response_data = homing_cmd.execute_force_stop_homing(
                    self.can_base, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_force_stop_homing_response()
                    if result['success']:
                        print("✓ 回零操作已强制停止")
                    else:
                        print("✗ 强制停止失败")
                else:
                    print("✗ 未收到响应，操作可能失败")
            
            elif choice == "4":
                # 读取原点回零参数
                print("\n--- 读取原点回零参数 ---")
                print("正在读取回零参数...")
                response_data = homing_cmd.execute_read_homing_params(
                    self.can_base, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_read_homing_params_response()
                    print("✓ 回零参数读取成功:")
                    print(response.format_homing_params(result))
                else:
                    print("✗ 未收到响应，读取失败")
            
            elif choice == "5":
                # 修改原点回零参数
                print("\n--- 修改原点回零参数 ---")
                print("请输入新的回零参数 (直接回车使用默认值):")
                
                # 收集参数
                params = {}
                
                # 回零模式
                mode_input = input("回零模式 (0:就近 1:方向 2:碰撞 3:限位) [0]: ").strip()
                params['homing_mode'] = int(mode_input) if mode_input.isdigit() and int(mode_input) in [0,1,2,3] else 0
                
                # 回零方向
                dir_input = input("回零方向 (0:顺时针 1:逆时针) [0]: ").strip()
                params['direction'] = int(dir_input) if dir_input.isdigit() and int(dir_input) in [0,1] else 0
                
                # 回零速度
                speed_input = input("回零速度 (RPM) [30]: ").strip()
                params['speed_rpm'] = int(speed_input) if speed_input.isdigit() and int(speed_input) > 0 else 30
                
                # 回零超时时间
                timeout_input = input("回零超时时间 (ms) [10000]: ").strip()
                params['timeout_ms'] = int(timeout_input) if timeout_input.isdigit() and int(timeout_input) > 0 else 10000
                
                # 碰撞检测转速
                collision_speed_input = input("碰撞检测转速 (RPM) [300]: ").strip()
                params['collision_speed_rpm'] = int(collision_speed_input) if collision_speed_input.isdigit() and int(collision_speed_input) > 0 else 300
                
                # 碰撞检测电流
                collision_current_input = input("碰撞检测电流 (mA) [800]: ").strip()
                params['collision_current_ma'] = int(collision_current_input) if collision_current_input.isdigit() and int(collision_current_input) > 0 else 800
                
                # 碰撞检测时间
                collision_time_input = input("碰撞检测时间 (ms) [60]: ").strip()
                params['collision_time_ms'] = int(collision_time_input) if collision_time_input.isdigit() and int(collision_time_input) > 0 else 60
                
                # 自动回零使能
                auto_input = input("上电自动回零 (y/N) [N]: ").strip().lower()
                params['auto_homing_enable'] = auto_input == 'y'
                
                # 是否保存到Flash
                save_choice = input("是否保存到Flash? (Y/n): ").strip().lower()
                save_to_flash = save_choice != 'n'
                
                print("正在修改回零参数...")
                response_data = homing_cmd.execute_modify_homing_params(
                    self.can_base, params, save_to_flash, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_modify_homing_params_response()
                    if result['success']:
                        print("✓ 回零参数修改成功")
                    else:
                        print("✗ 回零参数修改失败")
                else:
                    print("✗ 未收到响应，修改可能失败")
            
            elif choice == "6":
                # 读取回零状态标志位
                print("\n--- 读取回零状态标志位 ---")
                print("正在读取回零状态...")
                response_data = homing_cmd.execute_read_homing_status(
                    self.can_base, self.timeout
                )
                
                if response_data:
                    # 传入当前设备地址用于显示
                    response = HomingResponse(response_data, address=self.current_address)
                    result = response.parse_read_homing_status_response()
                    print("✓ 回零状态读取成功:")
                    print(response.format_homing_status(result))
                else:
                    print("✗ 未收到响应，读取失败")
            
            elif choice == "7":
                # 显示回零使用说明
                self._show_homing_usage_guide()
            
            else:
                print("✗ 无效选择")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def _show_homing_usage_guide(self):
        """显示回零使用说明"""
        print(f"\n=== 原点回零使用说明 ===")
        print()
        print("【回零模式说明】")
        print("0. 单圈就近回零：电机转动到最近的零点位置")
        print("1. 单圈方向回零：电机按指定方向转动到零点位置")
        print("2. 多圈无限位碰撞回零：电机转动直到检测到碰撞")
        print("3. 多圈有限位开关回零：电机转动直到触发限位开关")
        print()
        print("【操作流程建议】")
        print("1. 首先读取当前回零参数，了解电机配置")
        print("2. 根据需要修改回零参数（速度、超时时间等）")
        print("3. 设置单圈回零的零点位置（如果需要）")
        print("4. 触发回零操作")
        print("5. 定期读取回零状态，监控回零进度")
        print("6. 如果需要，可以强制中断回零操作")
        print()
        print("【注意事项】")
        print("- 回零过程中电机会运动，请确保安全")
        print("- 碰撞回零模式需要合理设置检测参数")
        print("- 限位开关回零需要硬件支持")
        print("- 回零超时时间应根据实际情况设置")
        print("- 多机同步回零需要先发送同步命令，再发送同步触发")
        print()
        print("【状态说明】")
        print("- 未回零(0)：电机尚未进行回零操作")
        print("- 回零中(1)：电机正在执行回零操作")
        print("- 回零成功(2)：电机已成功完成回零")
        print("- 回零失败(3)：回零操作失败（超时或其他错误）")
        
        input("\n按回车键返回...")
    
    def set_motor_address(self):
        """设置电机地址"""
        print(f"\n=== 设置电机地址 ===")
        print(f"当前电机地址: {self.current_address}")
        
        try:
            # 允许设置0地址，表示广播地址
            address_input = input("请输入新的电机地址 (0-255，0为广播): ").strip()
            if not address_input:
                print("✗ 地址不能为空")
                return
            
            new_address = int(address_input)
            if new_address < 0 or new_address > 255:
                print("✗ 地址超出范围 (0-255)")
                return
            
            self.current_address = new_address
            if self.current_address == 0:
                print(f"✓ 电机地址已设置为: 0 (广播地址)")
                print("提示: 使用广播地址发送的命令将被所有设备接收")
            else:
                print(f"✓ 电机地址已设置为: {self.current_address}")
            
        except ValueError:
            print("✗ 地址必须是数字")
    
    def set_communication_params(self):
        """设置通信参数"""
        print(f"\n=== 设置通信参数 ===")
        print(f"当前配置:")
        print(f"  COM端口: {self.com_port}")
        print(f"  波特率: {self.bitrate}")
        print(f"  超时时间: {self.timeout}s")
        
        # 设置COM端口
        com_input = input(f"请输入COM端口 (当前: {self.com_port}): ").strip()
        if com_input:
            self.com_port = com_input
            self.can_base.com_port = com_input
        
        # 设置波特率
        bitrate_input = input(f"请输入波特率 (当前: {self.bitrate}): ").strip()
        if bitrate_input:
            try:
                new_bitrate = int(bitrate_input)
                self.bitrate = new_bitrate
                self.can_base.bitrate = new_bitrate
            except ValueError:
                print("✗ 波特率必须是数字")
                return
        
        # 设置超时时间
        timeout_input = input(f"请输入超时时间 (秒, 当前: {self.timeout}): ").strip()
        if timeout_input:
            try:
                new_timeout = float(timeout_input)
                self.timeout = new_timeout
                self.can_base.timeout = new_timeout
            except ValueError:
                print("✗ 超时时间必须是数字")
                return
        
        print("✓ 通信参数已更新")
        print("注意: 如果设备已连接，需要重新连接以应用新参数")
    
    def run(self):
        """运行主程序循环"""
        print("欢迎使用交互式电机控制工具!")
        print("基于motor_can_lib库，支持电机使能、速度控制和停止命令")
        
        while True:
            try:
                self.show_main_menu()
                choice = input("请输入选择 (0-11): ").strip()
                
                if choice == "0":
                    print("\n正在退出程序...")
                    if self.can_base.is_connected:
                        self.disconnect_device()
                    print("再见!")
                    break
                elif choice == "1":
                    self.connect_device()
                elif choice == "2":
                    self.motor_enable_control()
                elif choice == "3":
                    self.motor_speed_control()
                elif choice == "4":
                    self.motor_position_control()
                elif choice == "5":
                    self.motor_stop_control()
                elif choice == "6":
                    self.motor_sync_control()
                elif choice == "7":
                    self.motor_homing_control()
                elif choice == "11":
                    self.motor_read_mode()
                elif choice == "8":
                    self.set_motor_address()
                elif choice == "9":
                    self.set_communication_params()
                elif choice == "10":
                    self.disconnect_device()
                else:
                    print("✗ 无效选择，请输入 0-11")
                
                # 等待用户按键继续
                if choice != "0":
                    input("\n按回车键继续...")
                    
            except KeyboardInterrupt:
                print("\n\n检测到 Ctrl+C，正在退出...")
                if self.can_base.is_connected:
                    self.disconnect_device()
                break
            except Exception as e:
                print(f"\n✗ 发生未知错误: {e}")
                input("按回车键继续...")


def main():
    """主函数"""
    try:
        tool = InteractiveMotorControl()
        tool.run()
    except Exception as e:
        print(f"程序启动失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()