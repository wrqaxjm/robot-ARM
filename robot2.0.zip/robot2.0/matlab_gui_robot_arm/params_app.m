function params_app(parent)
% 参数界面（DH 参数配置）
% 说明：
% - 提供 6 轴机械臂的改进 DH 参数配置（a, alpha, d, theta_offset）。
% - 支持从全局加载/保存（使用 appdata 存储 'dh_params'）。
% - 保存后可供 3D 显示与逆解使用（后续界面接入时直接读取全局参数）。
% - 初始化时从 URDF 文件读取默认 DH 参数

    % === URDF 路径配置 ===
    urdfPath = 'e:\traeproject\robot2.0\python_viewer\六轴机械臂\urdf\六轴机械臂.urdf';

    % 根容器：内嵌模式使用传入父容器
    root = parent;
    gl = uigridlayout(root, [3 1]);
    gl.RowHeight = {40, '1x', 40};

    % 顶部标题与说明
    header = uigridlayout(gl,[1 3]); header.ColumnWidth = {'1x','1x','1x'}; header.Layout.Row = 1; header.Layout.Column = 1;
    uilabel(header, 'Text','DH 参数配置（改进DH）', 'HorizontalAlignment','left');
    btnLoadURDF = uibutton(header,'Text','从URDF加载','ButtonPushedFcn',@(s,e) onLoadFromURDF());
    btnLoad = uibutton(header,'Text','从全局加载','ButtonPushedFcn',@(s,e) onLoad());

    % 中部参数网格：6 行（J1..J6），4 列（a, alpha, d, theta_offset）
    pl = uigridlayout(gl, [7 5]); pl.Layout.Row = 2; pl.Layout.Column = 1;
    pl.RowHeight = {24, 30,30,30,30,30,30};
    pl.ColumnWidth = {60, 120, 120, 120, '1x'}; % 关节/参数列宽

    % 列头（中文注释：为易读性设置表头）
    uilabel(pl,'Text','关节','HorizontalAlignment','center');
    % 中文注释：明确单位，alpha/theta₀ 使用“度”，a/d 使用长度单位（建议 mm）
    uilabel(pl,'Text','a (连杆长度, mm)','HorizontalAlignment','center');
    uilabel(pl,'Text','alpha (连杆扭角, 度)','HorizontalAlignment','center');
    uilabel(pl,'Text','d (连杆偏距, mm)','HorizontalAlignment','center');
    uilabel(pl,'Text','theta₀ (零位偏置, 度)','HorizontalAlignment','center');

    % 控件数组，用于统一读写
    jointLabels = gobjects(1,6);
    aFields     = gobjects(1,6);
    alphaFields = gobjects(1,6);
    dFields     = gobjects(1,6);
    theta0Fields= gobjects(1,6);

    for j = 1:6
        jointLabels(j) = uilabel(pl,'Text',sprintf('J%d',j),'HorizontalAlignment','center'); jointLabels(j).Layout.Row = j+1; jointLabels(j).Layout.Column = 1;
        aFields(j)      = uieditfield(pl,'numeric');      aFields(j).Layout.Row = j+1; aFields(j).Layout.Column = 2; aFields(j).Value = 0.0;
        alphaFields(j)  = uieditfield(pl,'numeric');  alphaFields(j).Layout.Row = j+1; alphaFields(j).Layout.Column = 3; alphaFields(j).Value = 0.0;
        dFields(j)      = uieditfield(pl,'numeric');      dFields(j).Layout.Row = j+1; dFields(j).Layout.Column = 4; dFields(j).Value = 0.0;
        theta0Fields(j) = uieditfield(pl,'numeric'); theta0Fields(j).Layout.Row = j+1; theta0Fields(j).Layout.Column = 5; theta0Fields(j).Value = 0.0;
    end

    % 底部操作区：保存到全局
    footer = uigridlayout(gl,[1 2]); footer.ColumnWidth = {'1x','1x'}; footer.Layout.Row = 3; footer.Layout.Column = 1;
    btnSave = uibutton(footer,'Text','保存到全局','ButtonPushedFcn',@(s,e) onSave());
    uilabel(footer,'Text','提示：alpha/theta₀ 以"度"输入并保存；a/d 建议使用 mm。保存后 3D 与逆解会读取。');

    % 初始化：尝试从 URDF 加载默认参数
    onLoadFromURDF();

    % 回调：从 URDF 文件加载
    function onLoadFromURDF()
        try
            % 检查 URDF 文件是否存在
            if ~isfile(urdfPath)
                safeAlert(root, sprintf('未找到 URDF 文件:\n%s', urdfPath), '错误');
                return;
            end
            
            % 导入 URDF 并提取 DH 参数
            try
                robot = importrobot(urdfPath, 'DataFormat', 'row');
            catch ME
                safeAlert(root, sprintf('URDF 导入失败：\n%s', ME.message), '错误');
                return;
            end
            
            % 从机器人模型提取 DH 参数（改进 DH）
            % 注意：URDF 格式不直接存储 DH 参数，需从关节和连杆变换中提取
            bodies = robot.Bodies;
            dhParams = extractDHFromRobot(robot);
            
            if isempty(dhParams)
                safeAlert(root, '无法从 URDF 提取 DH 参数，使用默认值', '提示');
                return;
            end
            
            % 将提取的参数写入控件（alpha 和 theta0 转为度）
            for j = 1:min(6, numel(dhParams.a))
                aFields(j).Value = dhParams.a(j);
                alphaFields(j).Value = rad2deg(dhParams.alpha(j));
                dFields(j).Value = dhParams.d(j);
                theta0Fields(j).Value = rad2deg(dhParams.theta0(j));
            end
            
            safeAlert(root, '已从 URDF 文件加载 DH 参数', '提示');
        catch ME
            safeAlert(root, sprintf('从 URDF 加载失败：\n%s', ME.message), '错误');
        end
    end

    % 回调：从全局加载
    function onLoad()
        try
            dh = [];
            try
                dh = getappdata(0,'dh_params');
            catch
            end
            if isempty(dh) || ~isstruct(dh) || ~isfield(dh,'a')
                safeAlert(root,'未检测到已保存的 DH 参数，使用默认值（0）','提示');
                return;
            end
            % 读取数组并写入控件
            for j = 1:6
                aFields(j).Value      = safeIndex(dh.a, j, 0.0);
                alphaFields(j).Value  = safeIndex(dh.alpha, j, 0.0);
                dFields(j).Value      = safeIndex(dh.d, j, 0.0);
                theta0Fields(j).Value = safeIndex(dh.theta0, j, 0.0);
            end
            safeAlert(root,'已从全局加载 DH 参数','提示');
        catch ME
            safeAlert(root, sprintf('加载失败：\n%s', ME.message), '错误');
        end
    end

    % 回调：保存到全局
    function onSave()
        try
            dh.a      = arrayfun(@(h) double(h.Value), aFields);
            dh.alpha  = arrayfun(@(h) double(h.Value), alphaFields);
            dh.d      = arrayfun(@(h) double(h.Value), dFields);
            dh.theta0 = arrayfun(@(h) double(h.Value), theta0Fields);
            % 存入全局（中文注释）：其他界面可通过 getappdata(0,'dh_params') 读取
            setappdata(0,'dh_params', dh);
            safeAlert(root,'DH 参数已保存到全局','提示');
        catch ME
            safeAlert(root, sprintf('保存失败：\n%s', ME.message), '错误');
        end
    end

    % 工具函数：安全取数组索引（越界或缺失返回默认值）
    function v = safeIndex(arr, idx, def)
        v = def;
        try
            if ~isempty(arr) && numel(arr) >= idx
                v = double(arr(idx));
            end
        catch
        end
    end

    % 工具函数：直接从 URDF XML 文件提取 DH 参数（与 Python 一致）
    function dhParams = extractDHFromRobot(robot)
        % 从 URDF XML 文件提取改进 DH 参数
        % 返回结构：dhParams.a, dhParams.alpha, dhParams.d, dhParams.theta0
        % 注意：直接解析 XML 而不是从 rigidBodyTree 提取，确保与 Python 版本一致
        dhParams = struct();
        dhParams.a = [];
        dhParams.alpha = [];
        dhParams.d = [];
        dhParams.theta0 = [];
        
        try
            % 解析 URDF XML 文件
            if ~isfile(urdfPath)
                warning('URDF 文件不存在: %s', urdfPath);
                return;
            end
            
            % 读取 XML
            xmlDoc = xmlread(urdfPath);
            robotNode = xmlDoc.getDocumentElement();
            
            % 查找所有非固定关节
            jointList = robotNode.getElementsByTagName('joint');
            nonFixedJoints = {};
            
            for i = 0:(jointList.getLength()-1)
                jointNode = jointList.item(i);
                jointType = char(jointNode.getAttribute('type'));
                
                % 跳过固定关节
                if ~strcmpi(jointType, 'fixed')
                    nonFixedJoints{end+1} = jointNode; %#ok<AGROW>
                end
            end
            
            % 只处理前 6 个非固定关节
            for i = 1:min(6, numel(nonFixedJoints))
                jointNode = nonFixedJoints{i};
                
                % 提取 origin 标签（xyz 和 rpy）
                originList = jointNode.getElementsByTagName('origin');
                xyz = [0, 0, 0];
                rpy = [0, 0, 0];
                
                if originList.getLength() > 0
                    originNode = originList.item(0);
                    
                    % 提取 xyz
                    if originNode.hasAttribute('xyz')
                        xyz_str = char(originNode.getAttribute('xyz'));
                        xyz = sscanf(xyz_str, '%f %f %f')';
                        if numel(xyz) < 3
                            xyz = [0, 0, 0];
                        end
                    end
                    
                    % 提取 rpy
                    if originNode.hasAttribute('rpy')
                        rpy_str = char(originNode.getAttribute('rpy'));
                        rpy = sscanf(rpy_str, '%f %f %f')';
                        if numel(rpy) < 3
                            rpy = [0, 0, 0];
                        end
                    end
                end
                
                % 提取 limit 标签（用于计算 theta0）
                limitList = jointNode.getElementsByTagName('limit');
                theta0_val = 0.0;
                
                if limitList.getLength() > 0
                    limitNode = limitList.item(0);
                    
                    if limitNode.hasAttribute('lower') && limitNode.hasAttribute('upper')
                        lower_str = char(limitNode.getAttribute('lower'));
                        upper_str = char(limitNode.getAttribute('upper'));
                        
                        try
                            lower_val = str2double(lower_str);
                            upper_val = str2double(upper_str);
                            % 使用限位中点作为零位
                            theta0_val = (lower_val + upper_val) / 2.0;
                        catch
                            theta0_val = 0.0;
                        end
                    end
                end
                
                % 计算改进 DH 参数（与 Python 一致）
                % a: 沿 x_{i-1} 轴的距离（从 xyz 的 x 分量提取，转换为 mm）
                a_val = xyz(1) * 1000.0;
                
                % alpha: 绕 x_{i-1} 轴的旋转（从 rpy 的 roll 分量提取）
                alpha_val = rpy(1);
                
                % d: 沿 z_i 轴的距离（从 xyz 的 z 分量提取，转换为 mm）
                d_val = xyz(3) * 1000.0;
                
                % 保存参数
                dhParams.a(i) = a_val;
                dhParams.alpha(i) = alpha_val;
                dhParams.d(i) = d_val;
                dhParams.theta0(i) = theta0_val;
            end
            
            % 确保至少有 6 个参数（补零）
            while numel(dhParams.a) < 6
                dhParams.a(end+1) = 0;
                dhParams.alpha(end+1) = 0;
                dhParams.d(end+1) = 0;
                dhParams.theta0(end+1) = 0;
            end
            
        catch ME
            warning('提取 DH 参数失败: %s', ME.message);
            disp(getReport(ME));
        end
    end

    % 工具函数：安全弹窗（查找父图窗；若不可用则降级打印）
    function safeAlert(r, msg, title)
        try
            fig = ancestor(r, 'figure');
            if ~isempty(fig) && isvalid(fig)
                uialert(fig, msg, title);
            else
                disp(msg);
            end
        catch
            disp(msg);
        end
    end
end