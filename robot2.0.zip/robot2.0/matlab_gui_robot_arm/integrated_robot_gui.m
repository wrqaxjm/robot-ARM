function integrated_robot_gui(parent)
% 六轴机械臂控制界面（重构版）
% 设计参照 Python 版本 robot_control_window.py
% 功能说明：
% - 上方：双 3D 显示区域
%   - 左侧：实时模型（从 CAN 获取实际关节角度）
%   - 右侧：理论模型（根据控制面板输入显示）
% - 下方：控制面板，支持关节模式和笛卡尔模式切换

    % === URDF 路径配置 ===
    urdfPath = 'e:\traeproject\robot2.0\python_viewer\六轴机械臂\urdf\六轴机械臂.urdf';
    
    % 检查 URDF 文件
    if ~isfile(urdfPath)
        if nargin > 0 && ~isempty(parent)
            fig = ancestor(parent, 'figure');
            uialert(fig, sprintf('未找到 URDF 文件:\n%s', urdfPath), '错误');
        else
            fig = uifigure('Name', 'URDF 错误');
            uialert(fig, sprintf('未找到 URDF 文件:\n%s', urdfPath), '错误');
        end
        return;
    end

    % === 创建主界面 ===
    if nargin > 0 && ~isempty(parent)
        root = parent;
        fig = ancestor(root, 'figure');
        mainLayout = uigridlayout(root, [2 1]);
    else
        fig = uifigure('Name', '六轴机械臂控制界面', 'Position', [50 50 1400 900]);
        mainLayout = uigridlayout(fig, [2 1]);
    end
    mainLayout.RowHeight = {'2x', '1x'};
    mainLayout.ColumnWidth = {'1x'};

    % ========================================
    % 上半部分：双 3D 显示区域
    % ========================================
    displayGroup = uipanel(mainLayout, 'Title', '3D 显示');
    displayGroup.Layout.Row = 1;
    displayGroup.Layout.Column = 1;
    
    displayLayout = uigridlayout(displayGroup, [2 1]);
    displayLayout.RowHeight = {30, '1x'};
    displayLayout.ColumnWidth = {'1x'};
    
    % 仅保留：理论模型
    theoryLabel = uilabel(displayLayout, 'Text', '理论模型（控制面板输入）', ...
        'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    theoryLabel.Layout.Row = 1;
    theoryLabel.Layout.Column = 1;
    
    theoryAxes = uiaxes(displayLayout);
    theoryAxes.Layout.Row = 2;
    theoryAxes.Layout.Column = 1;
    title(theoryAxes, '');
    grid(theoryAxes, 'off');
    view(theoryAxes, 135, 25);

    % === 导入 URDF ===
    try
        robot = importrobot(urdfPath, 'DataFormat', 'row');
        robot.Gravity = [0 0 -9.81];
    catch ME
        uialert(fig, sprintf('URDF 导入失败：\n%s', ME.message), '错误');
        return;
    end

    % 初始化角度
    q0_raw = homeConfiguration(robot);
    if isstruct(q0_raw)
        q_theory = arrayfun(@(s) s.JointPosition, q0_raw);
    else
        q_theory = q0_raw;
    end
    % 仅保留目标模型显示

    % 变换矩阵：绕 X 轴旋转 -90°
    baseRotation = makehgtform('xrotate', -pi/2);
    
    % 创建 hgtransform 容器（仅理论模型）
    theoryTransform = hgtransform('Parent', theoryAxes);
    theoryTransform.Matrix = baseRotation;

    % ========================================
    % 下半部分：控制面板（可弹出）
    % ========================================
    controlGroup = uipanel(mainLayout, 'Title', '控制面板');
    controlGroup.Layout.Row = 2;
    controlGroup.Layout.Column = 1;
    
    controlLayout = uigridlayout(controlGroup, [2 1]);
    controlLayout.RowHeight = {40, '1x'};
    controlLayout.ColumnWidth = {'1x'};
    
    % 弹出按钮
    btnLayout = uigridlayout(controlLayout, [1 3]);
    btnLayout.Layout.Row = 1;
    btnLayout.Layout.Column = 1;
    btnLayout.RowHeight = {30};
    btnLayout.ColumnWidth = {'1x', 150, 10};
    
    uilabel(btnLayout, 'Text', '提示：控制面板可弹出为独立窗口', ...
        'FontSize', 10, 'FontColor', [0.5 0.5 0.5]);
    
    btnPopout = uibutton(btnLayout, 'Text', '弹出控制面板 ↗', ...
        'ButtonPushedFcn', @(s,e) popoutControlPanel());
    btnPopout.BackgroundColor = [0.2 0.6 0.9];
    btnPopout.FontColor = [1 1 1];
    
    % 控制面板容器
    controlContainer = uigridlayout(controlLayout, [1 1]);
    controlContainer.Layout.Row = 2;
    controlContainer.Layout.Column = 1;
    controlContainer.RowHeight = {'1x'};
    controlContainer.ColumnWidth = {'1x'};

    % ========================================
    % 运动参数配置（每个关节的默认参数）
    % 必须在创建界面之前定义，因为界面创建时会使用这些参数
    % ========================================
    % 默认参数：使用角度模式（position_mode = 0 表示绝对角度）
    defaultParams = struct();
    defaultParams.position_mode = 0;        % 0=相对位置, 1=绝对位置
    defaultParams.max_speed = 100;          % 最大速度 (RPM)
    defaultParams.acceleration = 2;         % 加速度档位 (1-5)
    defaultParams.gear_ratio = 30.0;        % 减速比默认 30（第6关节特殊）
    defaultParams.direction = 0;            % 方向：0=顺时针(CW), 1=逆时针(CCW)
    
    % 为每个关节创建参数副本
    jointParams = repmat(defaultParams, 6, 1);
    % 第6关节减速比为 1
    jointParams(6).gear_ratio = 1.0;
    
    % 关节方向修正：关节2和关节3的模型方向与UI相反
    jointSign = ones(6,1);
    jointSign(2) = -1;
    jointSign(3) = -1;
    
    % ========================================
    % 状态变量
    % ========================================
    app = struct();
    app.can_base = [];
    app.is_connected = false;
    app.timeout = 2.0;
    app.control_mode = 'joint';  % 'joint' 或 'cartesian'
    app.isUpdating = false;  % 防止循环更新的标志
    app.last_sent_angles_deg = nan(6,1);  % 上次发送到电机的角度（度）；用于去重发送
    
    % 控件引用（用于联动更新）
    % 原始面板的控件
    jointControls = struct();
    cartesianControls = struct();
    % 弹出面板的控件
    popoutJointControls = struct();
    popoutCartesianControls = struct();
    
    % 弹出窗口相关变量
    popoutFig = [];
    popoutTabGroup = [];
    
    % 创建标签页组
    tabGroup = uitabgroup(controlContainer);
    tabGroup.Layout.Row = 1;
    tabGroup.Layout.Column = 1;
    
    % 标签页1：关节模式
    jointTab = uitab(tabGroup, 'Title', '关节模式');
    createJointPanel(jointTab, false);
    
    % 标签页2：笛卡尔模式
    cartesianTab = uitab(tabGroup, 'Title', '笛卡尔模式');
    createCartesianPanel(cartesianTab, false);
    
    % 标签页3：参数配置
    paramTab = uitab(tabGroup, 'Title', '参数配置');
    createJointParamPanel(paramTab, false);
    
    % 从全局获取 CAN 连接
    try
        app.can_base = getappdata(0, 'can_base');
        conn_val = getappdata(0, 'can_connected');
        % 确保 is_connected 是标量逻辑值
        if ~isempty(conn_val)
            app.is_connected = logical(conn_val(1));
        else
            app.is_connected = false;
        end
    catch
        app.can_base = [];
        app.is_connected = false;
    end

    % 不再使用实时模型定时器

    % ========================================
    % 初始化显示
    % ========================================
    updateTheoryModel();
    
    % 不再初始化实时模型显示
    % 为理论模型添加地面网格
    try
        drawGroundGrid(theoryAxes);
    catch ME
        warning('添加地面网格失败: %s', ME.message);
    end
    
    % 取消初始化时的正向运动学更新，保持笛卡尔输入默认值为 0

    % ========================================
    % 内部函数：面板创建
    % ========================================
    function layout = createJointPanel(parent, isPopout)
        % 创建网格布局（直接在 Tab 中）
        % isPopout: true 表示弹出窗口，false 表示原始面板
        if nargin < 2
            isPopout = false;
        end
        
        layout = uigridlayout(parent, [7 3]);
        layout.RowHeight = {45, 45, 45, 45, 45, 45, 50};
        layout.ColumnWidth = {100, '1x', 100};
        layout.RowSpacing = 8;
        layout.ColumnSpacing = 10;
        layout.Padding = [15 15 15 15];
        
        % 创建 6 个关节滑条（保存控件引用）
        for i = 1:6
            % 标签
            lbl = uilabel(layout, 'Text', sprintf('关节 %d:', i), ...
                'HorizontalAlignment', 'right', 'FontSize', 11);
            lbl.Layout.Row = i;
            lbl.Layout.Column = 1;
            
            uiValue = jointModelToUI(i, q_theory(i));
            
            % 滑条
            slider = uislider(layout, 'Limits', [-180 180], 'Value', uiValue);
            slider.ValueChangedFcn = @(s,e) onJointSliderChanged(i, s.Value);
            slider.MajorTicks = -180:60:180;
            slider.Layout.Row = i;
            slider.Layout.Column = 2;
            if isPopout
                popoutJointControls.(['slider' num2str(i)]) = slider;  % 保存到弹出控件
            else
                jointControls.(['slider' num2str(i)]) = slider;  % 保存到原始控件
            end
            
            % 数值框
            spin = uispinner(layout, 'Limits', [-180 180], 'Value', uiValue);
            spin.ValueChangedFcn = @(s,e) onJointSpinChanged(i, s.Value);
            spin.Step = 1;
            spin.Layout.Row = i;
            spin.Layout.Column = 3;
            if isPopout
                popoutJointControls.(['spin' num2str(i)]) = spin;  % 保存到弹出控件
            else
                jointControls.(['spin' num2str(i)]) = spin;  % 保存到原始控件
            end
        end
        
        % 发送按钮
        emptyLabel1 = uilabel(layout, 'Text', '');
        emptyLabel1.Layout.Row = 7;
        emptyLabel1.Layout.Column = 1;
        
        sendBtn = uibutton(layout, 'Text', '发送到电机', ...
            'ButtonPushedFcn', @(s,e) sendJointToMotors());
        sendBtn.Layout.Row = 7;
        sendBtn.Layout.Column = 2;
        sendBtn.BackgroundColor = [0.30 0.69 0.31];
        sendBtn.FontColor = [1 1 1];
        sendBtn.FontSize = 12;
    end

    function createJointParamPanel(parent, isPopout)
        % 创建关节参数配置面板
        if nargin < 2
            isPopout = false;
        end

        % 先创建一个充满父容器的根布局，再在其中放入可滚动面板，避免内容缩到角落
        rootLayout = uigridlayout(parent, [1 1]);
        rootLayout.RowHeight = {'1x'};
        rootLayout.ColumnWidth = {'1x'};
        rootLayout.RowSpacing = 0;
        rootLayout.ColumnSpacing = 0;
        rootLayout.Padding = [0 0 0 0];

        % 创建可滚动面板，铺满根布局
        scrollPanel = uipanel(rootLayout, 'Scrollable', 'on');
        scrollPanel.Layout.Row = 1;
        scrollPanel.Layout.Column = 1;
        
        % 在滚动面板内创建网格布局（实际内容容器）
        layout = uigridlayout(scrollPanel, [8 8]);
        layout.RowHeight = [40, repmat({80}, 1, 6), 50];
        layout.ColumnWidth = {80, 120, 120, 120, 120, 120, 120, 10};
        layout.RowSpacing = 5;
        layout.ColumnSpacing = 8;
        layout.Padding = [15 15 15 15];
        
        % 标题行
        headers = {'关节', '位置模式', '速度(RPM)', '加速度档位', '减速比', '方向', '说明'};
        for col = 1:length(headers)
            lbl = uilabel(layout, 'Text', headers{col}, ...
                'FontWeight', 'bold', 'FontSize', 11, ...
                'HorizontalAlignment', 'center');
            lbl.Layout.Row = 1;
            lbl.Layout.Column = col;
        end
        
        % 为每个关节创建参数配置行
        for i = 1:6
            % 关节标签
            jointLabel = uilabel(layout, 'Text', sprintf('关节 %d', i), ...
                'FontWeight', 'bold', 'HorizontalAlignment', 'center');
            jointLabel.Layout.Row = i + 1;
            jointLabel.Layout.Column = 1;
            
            % 位置模式下拉框
            modeDropdown = uidropdown(layout, ...
                'Items', {'相对位置', '绝对位置'}, ...
                'ItemsData', [0, 1], ...
                'Value', jointParams(i).position_mode, ...
                'ValueChangedFcn', @(src, ~) updateJointParam(i, 'position_mode', src.Value));
            modeDropdown.Layout.Row = i + 1;
            modeDropdown.Layout.Column = 2;
            
            % 速度输入
            speedInput = uispinner(layout, ...
                'Limits', [1 500], ...
                'Value', jointParams(i).max_speed, ...
                'Step', 10, ...
                'ValueChangedFcn', @(src, ~) updateJointParam(i, 'max_speed', src.Value));
            speedInput.Layout.Row = i + 1;
            speedInput.Layout.Column = 3;
            
            % 加速度档位
            accelInput = uispinner(layout, ...
                'Limits', [1 5], ...
                'Value', jointParams(i).acceleration, ...
                'Step', 1, ...
                'ValueChangedFcn', @(src, ~) updateJointParam(i, 'acceleration', src.Value));
            accelInput.Layout.Row = i + 1;
            accelInput.Layout.Column = 4;
            
            % 减速比
            gearInput = uispinner(layout, ...
                'Limits', [0.1 100], ...
                'Value', jointParams(i).gear_ratio, ...
                'Step', 0.1, ...
                'ValueDisplayFormat', '%.2f', ...
                'ValueChangedFcn', @(src, ~) updateJointParam(i, 'gear_ratio', src.Value));
            gearInput.Layout.Row = i + 1;
            gearInput.Layout.Column = 5;
            
            % 方向选择（0 顺时针 / 1 逆时针）
            dirDropdown = uidropdown(layout, ...
                'Items', {'顺时针','逆时针'}, ...
                'ItemsData', [0, 1], ...
                'Value', jointParams(i).direction, ...
                'ValueChangedFcn', @(src, ~) updateJointParam(i, 'direction', src.Value));
            dirDropdown.Layout.Row = i + 1;
            dirDropdown.Layout.Column = 6;
            
            % 说明文本
            infoText = uilabel(layout, ...
                'Text', sprintf('默认: RPM=%d, 档=%d, 比=%.1f', ...
                    defaultParams.max_speed, defaultParams.acceleration, defaultParams.gear_ratio), ...
                'FontSize', 9, 'FontColor', [0.5 0.5 0.5]);
            infoText.Layout.Row = i + 1;
            infoText.Layout.Column = 7;
        end
        
        % 底部按钮行
        resetBtn = uibutton(layout, 'Text', '🔄 恢复默认参数', ...
            'ButtonPushedFcn', @(~,~) resetAllParams());
        resetBtn.Layout.Row = 8;
        resetBtn.Layout.Column = [1 3];
        resetBtn.BackgroundColor = [0.95 0.95 0.95];
        
        saveBtn = uibutton(layout, 'Text', '💾 保存参数', ...
            'ButtonPushedFcn', @(~,~) saveAllParams());
        saveBtn.Layout.Row = 8;
        saveBtn.Layout.Column = [4 5];
        saveBtn.BackgroundColor = [0.20 0.60 0.90];
        saveBtn.FontColor = [1 1 1];
        
        infoLabel = uilabel(layout, ...
            'Text', '提示：发送角度 = 目标角度 × 减速比', ...
            'FontSize', 10, 'FontColor', [0 0.5 0.8], ...
            'HorizontalAlignment', 'center');
        infoLabel.Layout.Row = 8;
        infoLabel.Layout.Column = [6 7];
    end
    
    function layout = createCartesianPanel(parent, isPopout)
        % 创建紧凑的网格布局
        % isPopout: true 表示弹出窗口，false 表示原始面板
        if nargin < 2
            isPopout = false;
        end
        
        layout = uigridlayout(parent, [6 7]);
        layout.RowHeight = {50, 50, 60, 10, 50, '1x'};
        layout.ColumnWidth = {100, 50, '1x', 60, '1x', 60, '1x'};
        layout.RowSpacing = 8;
        layout.ColumnSpacing = 8;
        layout.Padding = [20 20 20 20];
        
        % ========== 第1行：位置输入 ==========
        lbl1 = uilabel(layout, 'Text', '位置 (m):', ...
            'FontWeight', 'bold', 'FontSize', 12, 'HorizontalAlignment', 'right');
        lbl1.Layout.Row = 1;
        lbl1.Layout.Column = 1;
        
        lblX = uilabel(layout, 'Text', 'X:', 'HorizontalAlignment', 'right');
        lblX.Layout.Row = 1;
        lblX.Layout.Column = 2;
        
        xInput = uispinner(layout, 'Limits', [-1 1], 'Value', 0.0, 'Step', 0.01);
        xInput.ValueDisplayFormat = '%.3f';
        xInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        xInput.Layout.Row = 1;
        xInput.Layout.Column = 3;
        if isPopout
            popoutCartesianControls.xInput = xInput;  % 保存到弹出控件
        else
            cartesianControls.xInput = xInput;  % 保存到原始控件
        end
        
        lblY = uilabel(layout, 'Text', 'Y:', 'HorizontalAlignment', 'right');
        lblY.Layout.Row = 1;
        lblY.Layout.Column = 4;
        
        yInput = uispinner(layout, 'Limits', [-1 1], 'Value', 0.0, 'Step', 0.01);
        yInput.ValueDisplayFormat = '%.3f';
        yInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        yInput.Layout.Row = 1;
        yInput.Layout.Column = 5;
        if isPopout
            popoutCartesianControls.yInput = yInput;  % 保存到弹出控件
        else
            cartesianControls.yInput = yInput;  % 保存到原始控件
        end
        
        lblZ = uilabel(layout, 'Text', 'Z:', 'HorizontalAlignment', 'right');
        lblZ.Layout.Row = 1;
        lblZ.Layout.Column = 6;
        
        zInput = uispinner(layout, 'Limits', [-1 1], 'Value', 0.0, 'Step', 0.01);
        zInput.ValueDisplayFormat = '%.3f';
        zInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        zInput.Layout.Row = 1;
        zInput.Layout.Column = 7;
        if isPopout
            popoutCartesianControls.zInput = zInput;  % 保存到弹出控件
        else
            cartesianControls.zInput = zInput;  % 保存到原始控件
        end
        
        % ========== 第2行：姿态输入 ==========
        lbl2 = uilabel(layout, 'Text', '姿态 (°):', ...
            'FontWeight', 'bold', 'FontSize', 12, 'HorizontalAlignment', 'right');
        lbl2.Layout.Row = 2;
        lbl2.Layout.Column = 1;
        
        lblRoll = uilabel(layout, 'Text', 'Roll:', 'HorizontalAlignment', 'right');
        lblRoll.Layout.Row = 2;
        lblRoll.Layout.Column = 2;
        
        rollInput = uispinner(layout, 'Limits', [-180 180], 'Value', 0, 'Step', 1);
        rollInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        rollInput.Layout.Row = 2;
        rollInput.Layout.Column = 3;
        if isPopout
            popoutCartesianControls.rollInput = rollInput;  % 保存到弹出控件
        else
            cartesianControls.rollInput = rollInput;  % 保存到原始控件
        end
        
        lblPitch = uilabel(layout, 'Text', 'Pitch:', 'HorizontalAlignment', 'right');
        lblPitch.Layout.Row = 2;
        lblPitch.Layout.Column = 4;
        
        pitchInput = uispinner(layout, 'Limits', [-180 180], 'Value', 0, 'Step', 1);
        pitchInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        pitchInput.Layout.Row = 2;
        pitchInput.Layout.Column = 5;
        if isPopout
            popoutCartesianControls.pitchInput = pitchInput;  % 保存到弹出控件
        else
            cartesianControls.pitchInput = pitchInput;  % 保存到原始控件
        end
        
        lblYaw = uilabel(layout, 'Text', 'Yaw:', 'HorizontalAlignment', 'right');
        lblYaw.Layout.Row = 2;
        lblYaw.Layout.Column = 6;
        
        yawInput = uispinner(layout, 'Limits', [-180 180], 'Value', 0, 'Step', 1);
        yawInput.ValueChangedFcn = @(s,e) onCartesianChanged();
        yawInput.Layout.Row = 2;
        yawInput.Layout.Column = 7;
        if isPopout
            popoutCartesianControls.yawInput = yawInput;  % 保存到弹出控件
        else
            cartesianControls.yawInput = yawInput;  % 保存到原始控件
        end
        
        % ========== 第3行：解算结果 ==========
        lbl3 = uilabel(layout, 'Text', '解算结果:', ...
            'FontWeight', 'bold', 'FontSize', 11, 'HorizontalAlignment', 'right');
        lbl3.Layout.Row = 3;
        lbl3.Layout.Column = 1;
        
        ikResultLabel = uilabel(layout, 'Text', '点击"逆运动学解算"按钮进行解算');
        ikResultLabel.Layout.Row = 3;
        ikResultLabel.Layout.Column = [2 7];
        ikResultLabel.WordWrap = 'on';
        ikResultLabel.FontColor = [0.5 0.5 0.5];
        if isPopout
            popoutCartesianControls.ikResultLabel = ikResultLabel;  % 保存到弹出控件
        else
            cartesianControls.ikResultLabel = ikResultLabel;  % 保存到原始控件
        end
        
        % 第4行：分隔（空行）
        
        % ========== 第5行：按钮 ==========
        solveBtn = uibutton(layout, 'Text', '🔄 逆运动学解算', ...
            'ButtonPushedFcn', @(s,e) solveIK());
        solveBtn.Layout.Row = 5;
        solveBtn.Layout.Column = [1 3];
        solveBtn.BackgroundColor = [0.13 0.59 0.95];
        solveBtn.FontColor = [1 1 1];
        solveBtn.FontSize = 11;
        
        sendBtn2 = uibutton(layout, 'Text', '📤 发送到电机', ...
            'ButtonPushedFcn', @(s,e) sendCartesianToMotors());
        sendBtn2.Layout.Row = 5;
        sendBtn2.Layout.Column = [5 7];
        sendBtn2.BackgroundColor = [0.30 0.69 0.31];
        sendBtn2.FontColor = [1 1 1];
        sendBtn2.FontSize = 11;
        
        % ========== 第6行：参数摘要 ==========
        paramSummaryLabel = uilabel(layout, ...
            'Text', sprintf('💡 提示：详细运动参数（速度、加速度、减速比等）请切换到"参数配置"标签页设置'), ...
            'FontSize', 10, 'FontColor', [0 0.5 0.8], ...
            'HorizontalAlignment', 'center', 'WordWrap', 'on');
        paramSummaryLabel.Layout.Row = 6;
        paramSummaryLabel.Layout.Column = [1 7];
    end

    % ========================================
    % 回调函数：参数配置
    % ========================================
    function updateJointParam(jointIdx, paramName, value)
        % 更新指定关节的参数
        try
            jointParams(jointIdx).(paramName) = value;
            fprintf('关节%d %s 更新为: %s\n', jointIdx, paramName, num2str(value));
        catch ME
            warning('更新关节%d参数失败: %s', jointIdx, ME.message);
        end
    end
    
    function resetAllParams()
        % 恢复所有关节参数为默认值
        for i = 1:6
            jointParams(i).position_mode = defaultParams.position_mode;
            jointParams(i).max_speed = defaultParams.max_speed;
            jointParams(i).acceleration = defaultParams.acceleration;
            jointParams(i).gear_ratio = defaultParams.gear_ratio;
        end
        % 第6关节保持为 1
        jointParams(6).gear_ratio = 1.0;
        
        % 构建提示信息
        msg = sprintf('所有关节参数已恢复为默认值:\n\n');
        msg = sprintf('%s位置模式: %s\n', msg, '相对位置');
        msg = sprintf('%s速度: %d RPM\n', msg, defaultParams.max_speed);
        msg = sprintf('%s加速度: 档 %d\n', msg, defaultParams.acceleration);
        msg = sprintf('%s减速比: 关节1-5=%.1f, 关节6=%.1f\n\n', msg, defaultParams.gear_ratio, 1.0);
        msg = sprintf('%s请切换到其他标签页再返回，以查看更新后的参数。', msg);
        
        % 提示用户
        uialert(fig, msg, '参数重置成功', 'Icon', 'success');
    end
    
    function saveAllParams()
        % 保存当前参数到全局（本次会话内共享）
        try
            setappdata(0, 'joint_params', jointParams);
            uialert(fig, '参数已保存（当前会话）。', '保存成功', 'Icon', 'success');
        catch ME
            uialert(fig, sprintf('保存失败：%s', ME.message), '错误', 'Icon', 'error');
        end
    end
    
    % ========================================
    % 回调函数：关节模式
    % ========================================
    function onJointSliderChanged(idx, value)
        if app.isUpdating
            return;  % 防止循环更新
        end
        app.isUpdating = true;
        
        try
            % 更新对应的数值框（原始和弹出两套）
            spinFieldName = ['spin' num2str(idx)];
            
            % 更新原始控件
            if isfield(jointControls, spinFieldName) && isvalid(jointControls.(spinFieldName))
                jointControls.(spinFieldName).Value = value;
            end
            
            % 更新弹出控件
            if isfield(popoutJointControls, spinFieldName) && isvalid(popoutJointControls.(spinFieldName))
                popoutJointControls.(spinFieldName).Value = value;
            end
            
            % 更新理论模型角度
            q_theory(idx) = jointUIToModel(idx, value);
            updateTheoryModel();
            
            % 正向运动学：更新笛卡尔坐标
            updateCartesianFromJoints();
        catch ME
            warning('关节滑条更新失败: %s', ME.message);
        end
        
        app.isUpdating = false;
    end

    function onJointSpinChanged(idx, value)
        if app.isUpdating
            return;  % 防止循环更新
        end
        app.isUpdating = true;
        
        try
            % 更新对应的滑条（原始和弹出两套）
            sliderFieldName = ['slider' num2str(idx)];
            
            % 更新原始控件
            if isfield(jointControls, sliderFieldName) && isvalid(jointControls.(sliderFieldName))
                jointControls.(sliderFieldName).Value = value;
            end
            
            % 更新弹出控件
            if isfield(popoutJointControls, sliderFieldName) && isvalid(popoutJointControls.(sliderFieldName))
                popoutJointControls.(sliderFieldName).Value = value;
            end
            
            % 更新理论模型角度
            q_theory(idx) = jointUIToModel(idx, value);
            updateTheoryModel();
            
            % 正向运动学：更新笛卡尔坐标
            updateCartesianFromJoints();
        catch ME
            warning('关节数值框更新失败: %s', ME.message);
        end
        
        app.isUpdating = false;
    end

    % ========================================
    % 回调函数：笛卡尔模式
    % ========================================
    function onCartesianChanged()
        if app.isUpdating
            return;  % 防止循环更新
        end
        % 笛卡尔输入变化时，提示用户点击解算按钮
        % 或者可以实时解算（可能影响性能）
    end

    function updateCartesianFromJoints()
        % 正向运动学：根据关节角度计算笛卡尔坐标
        % 注意：此函数被其他已设置 isUpdating 的函数调用，所以不需要再次检查
        
        try
            % 计算末端执行器位姿
            T = getTransform(robot, q_theory, robot.BodyNames{end});
            
            % 提取位置 (单位：米)
            pos = T(1:3, 4);
            
            % 提取姿态（ZYX欧拉角，单位：度）
            rotm = T(1:3, 1:3);
            rpy = rad2deg(rotm2eul(rotm, 'ZYX'));  % [yaw, pitch, roll]
            
            % 更新原始笛卡尔控件
            if isfield(cartesianControls, 'xInput') && isvalid(cartesianControls.xInput)
                cartesianControls.xInput.Value = pos(1);
                cartesianControls.yInput.Value = pos(2);
                cartesianControls.zInput.Value = pos(3);
                cartesianControls.rollInput.Value = rpy(3);
                cartesianControls.pitchInput.Value = rpy(2);
                cartesianControls.yawInput.Value = rpy(1);
            end
            
            % 更新弹出笛卡尔控件
            if isfield(popoutCartesianControls, 'xInput') && isvalid(popoutCartesianControls.xInput)
                popoutCartesianControls.xInput.Value = pos(1);
                popoutCartesianControls.yInput.Value = pos(2);
                popoutCartesianControls.zInput.Value = pos(3);
                popoutCartesianControls.rollInput.Value = rpy(3);
                popoutCartesianControls.pitchInput.Value = rpy(2);
                popoutCartesianControls.yawInput.Value = rpy(1);
            end
            
            % 生成结果文本
            resultText = sprintf('正向运动学: X=%.3f, Y=%.3f, Z=%.3f (m)', pos(1), pos(2), pos(3));
            
            % 更新原始结果显示
            if isfield(cartesianControls, 'ikResultLabel') && isvalid(cartesianControls.ikResultLabel)
                cartesianControls.ikResultLabel.Text = resultText;
                cartesianControls.ikResultLabel.FontColor = [0 0.5 0.8];  % 蓝色
            end
            
            % 更新弹出结果显示
            if isfield(popoutCartesianControls, 'ikResultLabel') && isvalid(popoutCartesianControls.ikResultLabel)
                popoutCartesianControls.ikResultLabel.Text = resultText;
                popoutCartesianControls.ikResultLabel.FontColor = [0 0.5 0.8];  % 蓝色
            end
        catch ME
            % 正向运动学失败（静默处理）
            warning('正向运动学计算失败: %s', ME.message);
        end
    end

    function solveIK()
        % 逆运动学解算
        if app.isUpdating
            return;
        end
        app.isUpdating = true;
        
        try
            % 智能选择控件源：若弹出窗存在且控件有效，优先使用弹出控件；否则使用原始控件
            activeControls = [];
            usePopout = false;
            try
                usePopout = ~isempty(popoutFig) && isvalid(popoutFig) && ...
                            isfield(popoutCartesianControls,'xInput') && isvalid(popoutCartesianControls.xInput);
            catch
                usePopout = false;
            end
            if usePopout
                activeControls = popoutCartesianControls;
            elseif isfield(cartesianControls, 'xInput') && isvalid(cartesianControls.xInput)
                activeControls = cartesianControls;
            else
                error('无法找到有效的笛卡尔控件');
            end
            
            % 获取输入值
            x = activeControls.xInput.Value;
            y = activeControls.yInput.Value;
            z = activeControls.zInput.Value;
            roll = activeControls.rollInput.Value;
            pitch = activeControls.pitchInput.Value;
            yaw = activeControls.yawInput.Value;
            
            % 构建目标变换矩阵
            T = eye(4);
            Rz = axang2tform([0 0 1 deg2rad(yaw)]);
            Ry = axang2tform([0 1 0 deg2rad(pitch)]);
            Rx = axang2tform([1 0 0 deg2rad(roll)]);
            T_rot = Rz * Ry * Rx;
            T(1:3,1:3) = T_rot(1:3,1:3);
            T(1:3,4) = [x; y; z];
            
            % 逆运动学求解
            ik = inverseKinematics('RigidBodyTree', robot);
            weights = [0.5 0.5 0.5 1 1 1];
            initialGuess = q_theory;
            [configSol, solInfo] = ik(robot.BodyNames{end}, T, weights, initialGuess);
            
            % 确保标量逻辑运算
            isSuccess = strcmp(solInfo.Status, 'success');
            errorNorm = double(solInfo.PoseErrorNorm);
            if isSuccess || (isscalar(errorNorm) && errorNorm < 0.01)
                % 解算成功
                q_theory = configSol;
                
                % 更新关节面板的滑条和数值框（原始和弹出两套）
                for i = 1:min(6, numel(q_theory))
                    deg_val = jointModelToUI(i, q_theory(i));
                    
                    % 更新原始控件的滑条
                    sliderFieldName = ['slider' num2str(i)];
                    if isfield(jointControls, sliderFieldName) && isvalid(jointControls.(sliderFieldName))
                        jointControls.(sliderFieldName).Value = deg_val;
                    end
                    
                    % 更新原始控件的数值框
                    spinFieldName = ['spin' num2str(i)];
                    if isfield(jointControls, spinFieldName) && isvalid(jointControls.(spinFieldName))
                        jointControls.(spinFieldName).Value = deg_val;
                    end
                    
                    % 更新弹出控件的滑条
                    if isfield(popoutJointControls, sliderFieldName) && isvalid(popoutJointControls.(sliderFieldName))
                        popoutJointControls.(sliderFieldName).Value = deg_val;
                    end
                    
                    % 更新弹出控件的数值框
                    if isfield(popoutJointControls, spinFieldName) && isvalid(popoutJointControls.(spinFieldName))
                        popoutJointControls.(spinFieldName).Value = deg_val;
                    end
                end
                
                % 更新结果标签（原始和弹出两套）
                resultText = sprintf('逆运动学解算成功:\n');
                for i = 1:min(6, numel(q_theory))
                    resultText = sprintf('%s关节%d: %.2f°  ', resultText, i, jointModelToUI(i, q_theory(i)));
                end
                
                % 更新原始控件的结果标签
                if isfield(cartesianControls, 'ikResultLabel') && isvalid(cartesianControls.ikResultLabel)
                    cartesianControls.ikResultLabel.Text = resultText;
                    cartesianControls.ikResultLabel.FontColor = [0 0.6 0]; % 绿色
                end
                
                % 更新弹出控件的结果标签
                if isfield(popoutCartesianControls, 'ikResultLabel') && isvalid(popoutCartesianControls.ikResultLabel)
                    popoutCartesianControls.ikResultLabel.Text = resultText;
                    popoutCartesianControls.ikResultLabel.FontColor = [0 0.6 0]; % 绿色
                end
                
                % 更新理论模型
                updateTheoryModel();
            else
                % 解算失败 - 更新两套控件
                failText = '解算失败：无法到达目标位姿';
                if isfield(cartesianControls, 'ikResultLabel') && isvalid(cartesianControls.ikResultLabel)
                    cartesianControls.ikResultLabel.Text = failText;
                    cartesianControls.ikResultLabel.FontColor = [0.8 0 0]; % 红色
                end
                if isfield(popoutCartesianControls, 'ikResultLabel') && isvalid(popoutCartesianControls.ikResultLabel)
                    popoutCartesianControls.ikResultLabel.Text = failText;
                    popoutCartesianControls.ikResultLabel.FontColor = [0.8 0 0]; % 红色
                end
                uialert(fig, '无法到达目标位姿，请调整目标参数', '解算失败', 'Icon', 'warning');
            end
            
        catch ME
            % 捕获异常 - 更新两套控件
            errorText = sprintf('解算错误: %s', ME.message);
            if isfield(cartesianControls, 'ikResultLabel') && isvalid(cartesianControls.ikResultLabel)
                cartesianControls.ikResultLabel.Text = errorText;
                cartesianControls.ikResultLabel.FontColor = [0.8 0 0];
            end
            if isfield(popoutCartesianControls, 'ikResultLabel') && isvalid(popoutCartesianControls.ikResultLabel)
                popoutCartesianControls.ikResultLabel.Text = errorText;
                popoutCartesianControls.ikResultLabel.FontColor = [0.8 0 0];
            end
            uialert(fig, sprintf('逆运动学解算失败:\n%s', ME.message), '错误');
        end
        
        app.isUpdating = false;
    end

    % ========================================
    % 3D 显示更新
    % ========================================
    function updateTheoryModel()
        % 更新理论模型的 3D 显示
        try
            delete(allchild(theoryTransform));
            
            % 在临时 figure 中渲染
            tmpFig = figure('Visible', 'off');
            tmpAx = axes('Parent', tmpFig);
            show(robot, q_theory, 'Visuals', 'on', 'Parent', tmpAx);
            
            % 复制到目标 axes
            objs = allchild(tmpAx);
            copyobj(objs, theoryTransform);
            
            delete(tmpFig);
            
            % 设置视角和坐标轴范围（确保模型居中显示）
            if strcmp(theoryAxes.XLimMode, 'auto')
                axis(theoryAxes, 'equal');
                view(theoryAxes, 135, 25);
                
                % 设置合适的坐标轴范围（以米为单位，机器人尺寸）
                xlim(theoryAxes, [-0.5 0.5]);
                ylim(theoryAxes, [-0.5 0.5]);
                zlim(theoryAxes, [-0.1 0.8]);
                
                theoryAxes.XLimMode = 'manual';
                theoryAxes.YLimMode = 'manual';
                theoryAxes.ZLimMode = 'manual';
                
                % 添加地面网格
                drawGroundGrid(theoryAxes);
            end
        catch ME
            % 静默处理错误
            warning('更新理论模型失败: %s', ME.message);
        end
    end

    % 实时模型相关函数与勾选逻辑已移除（仅保留目标模型显示）

    % ========================================
    % 发送命令到电机
    % ========================================
    function sendJointToMotors()
        % 检查连接
        try
            app.can_base = getappdata(0, 'can_base');
            conn_val = getappdata(0, 'can_connected');
            % 确保 is_connected 是标量逻辑值
            if ~isempty(conn_val)
                app.is_connected = logical(conn_val(1));
            else
                app.is_connected = false;
            end
        catch
            app.can_base = [];
            app.is_connected = false;
        end
        
        if isempty(app.can_base) || ~isequal(app.is_connected, true)
            uialert(fig, '未连接CAN设备，请先在"指令控制"界面连接设备。', '警告', 'Icon', 'warning');
            return;
        end
        
        % 计算实际发送角度（应用减速比）
        angles_deg = arrayfun(@(idx) jointModelToUI(idx, q_theory(idx)), 1:6).';
        send_angles_deg = zeros(6, 1);
        for i = 1:6
            send_angles_deg(i) = angles_deg(i) * jointParams(i).gear_ratio;
        end
        
        % 确认对话框
        msg = sprintf('即将发送以下指令到电机:\n\n');
        msg = sprintf('%s%-8s %-12s %-12s %-10s %-10s %-10s\n', msg, ...
            '关节', '目标角度', '发送角度', '减速比', '速度', '加速度');
        msg = sprintf('%s%s\n', msg, repmat('-', 1, 75));
        for i = 1:6
                msg = sprintf('%s关节%d   %.1f°       %.1f°       %.2f      %dRPM    档%d\n', ...
                msg, i, angles_deg(i), send_angles_deg(i), ...
                jointParams(i).gear_ratio, jointParams(i).max_speed, ...
                jointParams(i).acceleration);
        end
        % 确定控制模式文本
        if jointParams(1).position_mode == 0
            modeText = '相对位置';
        else
            modeText = '绝对位置';
        end
        msg = sprintf('%s\n控制模式: %s\n\n是否继续？', msg, modeText);
        
        selection = uiconfirm(fig, msg, '确认发送', ...
            'Options', {'是', '否'}, ...
            'DefaultOption', 2, 'CancelOption', 2, ...
            'Icon', 'question');
        
        if strcmp(selection, '否')
            return;
        end
        
        % 发送到每个电机（逐个发送，参考指令控制界面）
        success_count = 0;
        % 判断阈值（度）：小于该变化视为未变更不发送
        change_tol_deg = 1e-3;
        for i = 1:6
            try
                % 如果与上次发送角度无显著变化，则跳过发送
                last_deg = app.last_sent_angles_deg(i);
                if ~isnan(last_deg) && abs(send_angles_deg(i) - last_deg) < change_tol_deg
                    fprintf('↷ 跳过关节%d：角度未变化（%.4f°）\n', i, send_angles_deg(i));
                    continue;
                end

                cmd = py.motor_can_lib.PositionControlCommand(int32(i));
                % 使用角度接口、逐个下发
                angle_to_send = abs(send_angles_deg(i));
                direction_to_send = jointParams(i).direction;
                if send_angles_deg(i) < 0
                    direction_to_send = 1 - direction_to_send;
                end
                cmd = cmd.set_angle_degrees(double(angle_to_send));
                cmd = cmd.set_direction(int32(direction_to_send));
                cmd = cmd.set_speed(int32(jointParams(i).max_speed));
                cmd = cmd.set_acceleration(int32(jointParams(i).acceleration));
                cmd = cmd.set_position_mode(int32(jointParams(i).position_mode));
                % 关闭多机同步，确保不并发
                try
                    cmd = cmd.set_multi_sync(false);
                catch
                end
                
                resp = cmd.execute(app.can_base, app.timeout);
                
                if ~isempty(resp)
                    success_count = success_count + 1;
                    % 记录本次下发角度
                    app.last_sent_angles_deg(i) = send_angles_deg(i);
                    fprintf('✓ 关节%d: 发送角度 %.1f° (目标 %.1f° × 减速比 %.2f, 确定方向=%d)\n', ...
                        i, angle_to_send, angles_deg(i), jointParams(i).gear_ratio, direction_to_send);
                end
                
                % 小延时，避免总线拥塞/设备忙
                pause(0.05);
            catch ME
                fprintf('✗ 关节%d命令发送失败: %s\n', i, ME.message);
                pause(0.05);
            end
        end
        
        % 显示结果
        if success_count == 6
            uialert(fig, sprintf('成功发送命令到所有%d个关节', success_count), '成功', 'Icon', 'success');
        elseif success_count > 0
            uialert(fig, sprintf('成功发送命令到%d/6个关节', success_count), '部分成功', 'Icon', 'warning');
        else
            uialert(fig, '所有关节命令发送失败', '失败', 'Icon', 'error');
        end
    end
    function uiDeg = jointModelToUI(idx, qRad)
        uiDeg = rad2deg(qRad) * jointSign(idx);
    end
    
    function qRad = jointUIToModel(idx, uiDeg)
        qRad = deg2rad(uiDeg) * jointSign(idx);
    end
    

    function sendCartesianToMotors()
        % 先解算 IK
        solveIK();
        
        % 检查是否解算成功（检查两套控件）
        isSuccess = false;
        
        % 检查原始控件
        if isfield(cartesianControls, 'ikResultLabel') && isvalid(cartesianControls.ikResultLabel)
            if contains(cartesianControls.ikResultLabel.Text, '成功')
                isSuccess = true;
            end
        end
        
        % 如果原始控件没有成功标记，检查弹出控件
        if ~isSuccess && isfield(popoutCartesianControls, 'ikResultLabel') && isvalid(popoutCartesianControls.ikResultLabel)
            if contains(popoutCartesianControls.ikResultLabel.Text, '成功')
                isSuccess = true;
            end
        end
        
        % 如果解算成功，发送到电机
        if isSuccess
            sendJointToMotors();
        end
    end

    % ========================================
    % 清理函数
    % ========================================
    function cleanup(~, ~)
        try
            % 停止并删除定时器
            if exist('updateTimer', 'var') && isvalid(updateTimer)
                stop(updateTimer);
                delete(updateTimer);
            end
        catch ME
            warning('清理定时器失败: %s', ME.message);
        end
        
        % 关闭弹出窗口
        try
            if ~isempty(popoutFig) && isvalid(popoutFig)
                delete(popoutFig);
            end
        catch ME
            warning('关闭弹出窗口失败: %s', ME.message);
        end
        
        % 如果是嵌入模式，不要删除 fig（由主窗口管理）
        if nargin == 0 || isempty(parent)
            % 独立模式：删除窗口
            try
                if isvalid(fig)
                    delete(fig);
                end
            catch
            end
        end
    end

    % ========================================
    % 弹出控制面板函数
    % ========================================
    function popoutControlPanel()
        % 检查是否已经弹出
        if ~isempty(popoutFig) && isvalid(popoutFig)
            % 已经弹出，聚焦到该窗口
            figure(popoutFig);
            return;
        end
        
        % 创建弹出窗口
        popoutFig = uifigure('Name', '控制面板（独立窗口）', ...
                            'Position', [200 200 800 500], ...
                            'CloseRequestFcn', @closePopout);
        
        % 在弹出窗口中创建布局
        popoutLayout = uigridlayout(popoutFig, [1 1]);
        popoutLayout.RowHeight = {'1x'};
        popoutLayout.ColumnWidth = {'1x'};
        
        % 创建新的标签页组
        popoutTabGroup = uitabgroup(popoutLayout);
        
        % 标签页1：关节模式（传入 true 表示弹出窗口）
        popoutJointTab = uitab(popoutTabGroup, 'Title', '关节模式');
        createJointPanel(popoutJointTab, true);
        
        % 标签页2：笛卡尔模式（传入 true 表示弹出窗口）
        popoutCartesianTab = uitab(popoutTabGroup, 'Title', '笛卡尔模式');
        createCartesianPanel(popoutCartesianTab, true);
        
        % 标签页3：参数配置（传入 true 表示弹出窗口）
        popoutParamTab = uitab(popoutTabGroup, 'Title', '参数配置');
        createJointParamPanel(popoutParamTab, true);
        
        % 隐藏原位置的控制面板，显示提示
        tabGroup.Visible = 'off';
        
        % 在原位置显示提示信息
        if ~isfield(app, 'popoutHint') || isempty(app.popoutHint) || ~isvalid(app.popoutHint)
            app.popoutHint = uilabel(controlContainer, ...
                'Text', sprintf('控制面板已弹出到独立窗口\n\n关闭独立窗口即可恢复到此处'), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'center', ...
                'FontSize', 14, ...
                'FontColor', [0.5 0.5 0.5]);
            app.popoutHint.Layout.Row = 1;
            app.popoutHint.Layout.Column = 1;
        else
            app.popoutHint.Visible = 'on';
        end
        
        % 更新弹出按钮
        btnPopout.Text = '控制面板已弹出 ✓';
        btnPopout.Enable = 'off';
    end

    function closePopout(~, ~)
        % 关闭弹出窗口
        try
            if ~isempty(popoutFig) && isvalid(popoutFig)
                delete(popoutFig);
            end
            popoutFig = [];
            popoutTabGroup = [];
            
            % 清空弹出控件引用
            popoutJointControls = struct();
            popoutCartesianControls = struct();
            
            % 恢复原位置的控制面板
            tabGroup.Visible = 'on';
            
            % 隐藏提示信息
            if isfield(app, 'popoutHint') && ~isempty(app.popoutHint) && isvalid(app.popoutHint)
                app.popoutHint.Visible = 'off';
            end
            
            % 恢复弹出按钮
            btnPopout.Text = '弹出控制面板 ↗';
            btnPopout.Enable = 'on';
        catch ME
            warning('关闭弹出窗口失败: %s', ME.message);
        end
    end

    % 设置窗口关闭回调（仅独立模式）
    if nargin == 0 || isempty(parent)
        fig.CloseRequestFcn = @cleanup;
    end
    
    % ========================================
    % 辅助函数：绘制地面网格
    % ========================================
    function drawGroundGrid(ax)
        % 在指定的 axes 上绘制地面网格
        try
            % 检查是否已经绘制过网格（避免重复）
            existingGrid = findobj(ax, 'Tag', 'GroundGrid');
            if ~isempty(existingGrid)
                return;
            end
            
            % 获取坐标轴范围
            xLim = xlim(ax);
            yLim = ylim(ax);
            zFloor = -0.05;  % 地面高度（稍低于z=0）
            
            % 网格参数
            numGridX = 20;
            numGridY = 20;
            
            dx = (xLim(2) - xLim(1)) / numGridX;
            dy = (yLim(2) - yLim(1)) / numGridY;
            
            % 四舍五入到合理的步长
            dx = round(dx / 0.05) * 0.05;
            dy = round(dy / 0.05) * 0.05;
            
            hold(ax, 'on');
            
            % 绘制 X 方向的网格线
            yVals = yLim(1):dy:yLim(2);
            for y = yVals
                line(ax, [xLim(1) xLim(2)], [y y], [zFloor zFloor], ...
                    'Color', [0.7 0.7 0.7], 'LineWidth', 0.5, ...
                    'Tag', 'GroundGrid', 'PickableParts', 'none');
            end
            
            % 绘制 Y 方向的网格线
            xVals = xLim(1):dx:xLim(2);
            for x = xVals
                line(ax, [x x], [yLim(1) yLim(2)], [zFloor zFloor], ...
                    'Color', [0.7 0.7 0.7], 'LineWidth', 0.5, ...
                    'Tag', 'GroundGrid', 'PickableParts', 'none');
            end
            
            % 绘制坐标轴（X轴-红色，Y轴-绿色）
            line(ax, [0 0.2], [0 0], [zFloor zFloor], ...
                'Color', [1 0 0], 'LineWidth', 2, ...
                'Tag', 'GroundGrid', 'PickableParts', 'none');
            
            line(ax, [0 0], [0 0.2], [zFloor zFloor], ...
                'Color', [0 1 0], 'LineWidth', 2, ...
                'Tag', 'GroundGrid', 'PickableParts', 'none');
            
            hold(ax, 'off');
            
        catch ME
            warning('绘制地面网格失败: %s', ME.message);
        end
    end
    
end
