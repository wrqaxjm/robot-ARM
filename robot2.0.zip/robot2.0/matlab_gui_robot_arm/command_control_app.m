function command_control_app(parent)
% 指令控制界面（MATLAB）
% 说明：
% - 本界面仅实现“指令控制界面”的核心交互：连接/断开 CAN、选择电机/广播、选择指令、填写参数并发送、右侧日志显示。
% - 参照 e:\traeproject\robot2.0\interactive_motor_control.py 的封装库调用方式。
% - 通过 MATLAB 调用 Python 库 motor_can_lib（需保证 MATLAB 已配置 Python，且 Python 能 import 该库）。
% - 代码包含中文注释，便于理解与维护。

    % ----------------------------
    % 基本配置（可按需调整）
    % ----------------------------
    cfg.com_port = 'COM11';    % 默认串口
    cfg.bitrate  = int32(500000); % 波特率
    cfg.timeout  = 2.0;           % 超时（秒）
    cfg.repo_path = 'e:\traeproject\robot2.0'; % Python 库所在路径

    % 应用状态结构体
    app.can_base = [];     % Python 的 MotorCANBase 实例
    app.is_connected = false;
    app.cfg = cfg;

    % ----------------------------
    % UI 框架：左中右布局（此处只做指令控制界面）
    % 支持内嵌：如提供父容器 parent，则在其内创建；否则创建独立窗口
    % ----------------------------
    hasParent = (nargin >= 1) && ~isempty(parent) && isvalid(parent);
    if hasParent
        % 直接使用传入的父容器作为根，避免嵌套面板导致尺寸未铺满
        root = parent;
    else
        root = uifigure('Name','指令控制界面','Position',[100 100 980 620]);
    end
    gl = uigridlayout(root,[1 2]);
    gl.ColumnWidth = {'2x','1x'};

    % 左侧主区域
    leftPanel = uipanel(gl, 'Title','指令控制');
    leftPanel.Layout.Column = 1;
    leftLayout = uigridlayout(leftPanel,[3 1]);
    leftLayout.RowHeight = {50, '1x', 40};

    % 连接/断开行：前置端口与波特率选择
    connRow = uigridlayout(leftLayout,[1 6]);
    connRow.ColumnWidth = {'fit',120,'fit',140,'1x','1x'};
    connRow.ColumnSpacing = 8;
    connRow.Padding = [8 4 8 4];
    
    uilabel(connRow,'Text','端口：','HorizontalAlignment','right');
    % 端口列表：尝试自动获取；失败则提供常见端口
    try
        portList = {};
        try
            % R2020b+ 可用
            portList = cellstr(serialportlist("all"));
        catch
            % 旧版本兼容（可能不可用）
        end
        if isempty(portList)
            % 兜底：常见端口
            portList = cellstr(arrayfun(@(k) sprintf('COM%d',k), 1:30, 'UniformOutput', false));
        end
    catch
        portList = cellstr(arrayfun(@(k) sprintf('COM%d',k), 1:30, 'UniformOutput', false));
    end
    if ~ismember(app.cfg.com_port, portList)
        portList = [cellstr(app.cfg.com_port); portList(:)];
    end
    ddPort = uidropdown(connRow,'Items',portList,'Value',app.cfg.com_port);
    
    uilabel(connRow,'Text','波特率：','HorizontalAlignment','right');
    bitrateItems = {'10000','20000','50000','100000','125000','250000','400000','500000','1000000'};
    defaultBitrateStr = char(string(app.cfg.bitrate));
    if ~ismember(defaultBitrateStr, bitrateItems)
        bitrateItems = [defaultBitrateStr, bitrateItems];
    end
    ddBitrate = uidropdown(connRow,'Items',bitrateItems,'Value',defaultBitrateStr);
    
    btnConnect = uibutton(connRow,'Text','连接CAN设备', 'ButtonPushedFcn', @(src,evt) onConnect());
    btnDisconnect = uibutton(connRow,'Text','断开CAN设备', 'ButtonPushedFcn', @(src,evt) onDisconnect());

    % 电机/广播选项（七个横栏）
    tabs = uitabgroup(leftLayout);
    tBroadcast = uitab(tabs,'Title','广播');
    tM1 = uitab(tabs,'Title','电机1');
    tM2 = uitab(tabs,'Title','电机2');
    tM3 = uitab(tabs,'Title','电机3');
    tM4 = uitab(tabs,'Title','电机4');
    tM5 = uitab(tabs,'Title','电机5');
    tM6 = uitab(tabs,'Title','电机6');

    % 底部状态条（简要连接状态显示）
    statusLabel = uilabel(leftLayout, 'Text','状态：未连接', 'HorizontalAlignment','left');

    % 右侧日志区域
    rightPanel = uipanel(gl,'Title','日志');
    rightPanel.Layout.Column = 2;
    logLayout = uigridlayout(rightPanel,[1 1]);
    txtLog = uitextarea(logLayout,'Editable','off');
    txtLog.Value = {''};

    % 在各 Tab 内构建命令选择与参数面板
    buildTabUI(tBroadcast, 0);
    buildTabUI(tM1, 1);
    buildTabUI(tM2, 2);
    buildTabUI(tM3, 3);
    buildTabUI(tM4, 4);
    buildTabUI(tM5, 5);
    buildTabUI(tM6, 6);

    % ----------------------------
    % 内部函数：日志输出
    % ----------------------------
    function appendLog(lines)
        % 追加日志（支持 char/string/cell），统一为按列 cell，避免维度不一致
        % 修复：此前使用 lines(:)' 形成行向量，易与已有列向量拼接时报“维度不一致”。
        % 现改为列向量统一处理。
        
        % 归一化待追加的行
        if ischar(lines) || isstring(lines)
            lines = cellstr(lines);
        elseif iscell(lines)
            try
                % 将 cell 元素统一转为 char，再转 cellstr
                lines = cellfun(@char, lines, 'UniformOutput', false);
            catch
                % 兼容非字符元素
                lines = cellfun(@(x) char(string(x)), lines, 'UniformOutput', false);
            end
        else
            % 兜底：转为单行字符串
            lines = {char(string(lines))};
        end
        lines = lines(:); % 列向量

        % 读取当前日志并归一化为列向量 cell
        cur = txtLog.Value;
        if isempty(cur)
            cur = {};
        elseif ischar(cur)
            cur = {cur};
        elseif isstring(cur)
            cur = cellstr(cur(:));
        elseif iscell(cur)
            cur = cur(:);
        else
            cur = {};
        end

        % 安全纵向拼接
        txtLog.Value = [cur; lines];
        drawnow;
    end

    % ----------------------------
    % 内部函数：Python 环境与路径检查
    % ----------------------------
    function ok = ensurePythonReady()
        ok = true;
        try
            % 确保可以调用 pyenv
            pe = pyenv;
            appendLog(sprintf('Python 环境：Version=%s, Executable=%s', pe.Version, pe.Executable));
        catch ME
            appendLog({'✗ 无法获取 Python 环境（请在 MATLAB 中配置 pyenv）', ME.message});
            ok = false; return;
        end

        try
            % 确保 Python 搜索路径包含仓库路径（MATLAB 操作 Python list 使用 insert 函数）
            % 说明：直接点调用 append（py.sys.path.append）在 MATLAB 中会触发
            % “对函数调用结果进行点索引需要在函数名称后加圆括号”的错误。
            % 推荐使用 insert 进行列表头插入，或检测后跳过重复路径。
            alreadyInPath = false;
            try
                pathCells = cell(py.list(py.sys.path));
                alreadyInPath = any(strcmp(pathCells, app.cfg.repo_path));
            catch
                % 如转换失败，按未包含处理
                alreadyInPath = false;
            end

            if ~alreadyInPath
                insert(py.sys.path, int32(0), app.cfg.repo_path);
                appendLog(sprintf('已将路径加入 Python sys.path：%s', app.cfg.repo_path));
            else
                appendLog(sprintf('路径已在 Python sys.path 中：%s', app.cfg.repo_path));
            end
        catch ME
            appendLog({'✗ 无法设置 Python 路径','请检查路径是否存在：', app.cfg.repo_path, ME.message});
            ok = false; return;
        end

        % 尝试导入 motor_can_lib
        try
            py.importlib.import_module('motor_can_lib');
        catch ME
            appendLog({'✗ 导入 motor_can_lib 失败','请确认 Python 能 import motor_can_lib，路径是否正确。', ME.message});
            ok = false;
        end
    end

    % ----------------------------
    % 连接/断开逻辑
    % ----------------------------
    function onConnect()
        if ~ensurePythonReady()
            statusLabel.Text = '状态：Python未就绪';
            return;
        end
        
        % 从下拉框读取端口与波特率
        try
            if isvalid(ddPort)
                app.cfg.com_port = char(ddPort.Value);
            end
        catch
        end
        try
            if isvalid(ddBitrate)
                app.cfg.bitrate = int32(str2double(ddBitrate.Value));
            end
        catch
        end

        try
            appendLog({'--- 尝试连接 CAN 设备 ---', sprintf('端口: %s, 波特率: %d, 超时: %.2fs', app.cfg.com_port, app.cfg.bitrate, app.cfg.timeout)});
            app.can_base = py.motor_can_lib.MotorCANBase(app.cfg.com_port, app.cfg.bitrate, app.cfg.timeout);
            ok = logical(app.can_base.connect());
            if ok
                app.is_connected = true;
                statusLabel.Text = '状态：已连接';
                appendLog({'✓ CAN设备连接成功'});
                % 将 CAN 连接句柄共享到全局 AppData，便于其他界面复用
                try
                    setappdata(0, 'can_base', app.can_base);
                    setappdata(0, 'can_connected', true);
                catch
                    % 共享失败不影响本界面使用，仅记录日志
                    appendLog('⚠ 无法写入全局连接共享（appdata）');
                end
            else
                app.is_connected = false;
                statusLabel.Text = '状态：未连接';
                appendLog({'✗ CAN设备连接失败'});
            end
        catch ME
            app.is_connected = false;
            statusLabel.Text = '状态：未连接';
            appendLog({'✗ 连接过程中发生错误', ME.message});
            % 清理全局共享标志
            try
                setappdata(0, 'can_connected', false);
                setappdata(0, 'can_base', []);
            catch
            end
        end
    end

    function onDisconnect()
        % 优雅断开：为 slcan 写串口关闭序列预留时间，降低析构期报错概率
        try
            if ~isempty(app.can_base)
                try
                    res = logical(app.can_base.disconnect()); %#ok<NASGU>
                    pause(0.2); % 等待底层关闭序列（发送 'C'）完成
                catch MEi
                    appendLog({'⚠ 断开过程出现警告', MEi.message});
                end
            end
            app.is_connected = false;
            statusLabel.Text = '状态：未连接';
            appendLog({'✓ CAN设备已断开'});
            % 同步更新全局共享标志
            try
                setappdata(0, 'can_connected', false);
                setappdata(0, 'can_base', []);
            catch
            end
        catch ME
            appendLog({'✗ 断开连接时出现错误', ME.message});
        end
    end

    % ----------------------------
    % 在 Tab 中构建命令选择与参数面板
    % ----------------------------
    function buildTabUI(tab, address)
        % 每个 Tab：命令下拉、参数区、多机同步、发送按钮
        tl = uigridlayout(tab,[5 2]);
        tl.RowHeight = {30, 'fit', '1x', 30, 34};
        tl.ColumnWidth = {'1x','1x'};

        % 电机地址只读显示
        uilabel(tl,'Text',sprintf('当前地址：%d', address),'HorizontalAlignment','left');
        uilabel(tl,'Text','');

        % 命令选择
        uilabel(tl,'Text','选择指令：','HorizontalAlignment','left');
        % 以列向量的单元格数组构建 Items，避免跨行省略号导致的维度拼接错误
        items = {
            '使能电机'
            '禁用电机'
            '设置速度'
            '位置控制'
            '角度控制'
            '停止电机'
            '同步触发'
            '原点设置零点'
            '原点触发回零'
            '原点强制中断'
            '原点读取参数'
            '原点修改参数'
            '原点读取状态'
            '诊断读取'
            '读取固件/硬件版本 (0x1F)'
            '读取相电阻/相电感 (0x20)'
            '读取位置环PID参数 (0x21)'
            '读取总线电压 (0x24)'
            '读取相电流 (0x27)'
            '读取电机实时转速 (0x35)'
            '读取电机实时位置 (0x36)'
            '读取电机位置误差 (0x37)'
            '读取电机状态标志位 (0x3A)'
            '读取驱动配置参数 (0x42 0x6C)'
            '读取系统状态参数 (0x43 0x7A)'
        };
        ddCmd = uidropdown(tl,'Items',items, 'Value','使能电机');

        % 参数面板
        paramPanel = uipanel(tl,'Title','参数');
        paramPanel.Layout.Row = 3; paramPanel.Layout.Column = [1 2];
        % 参数网格适当加大行数，覆盖原点修改/诊断读取等较多参数
        pl = uigridlayout(paramPanel,[8 4]);
        pl.RowHeight = {30,30,30,30,30,30,30,30}; pl.ColumnWidth = {120,'1x',120,'1x'};

        % 多机同步 & 发送按钮行
        cbSync = uicheckbox(tl,'Text','启用多机同步'); cbSync.Value = false;
        btnSend = uibutton(tl,'Text','发送指令', 'ButtonPushedFcn', @(s,e) onSend());

        % 参数控件（按需显示/隐藏）
        % 速度控制参数
        lblSpeed = uilabel(pl,'Text','目标速度 (RPM)：','HorizontalAlignment','right');
        edtSpeed = uieditfield(pl,'numeric','Limits',[0 65535],'RoundFractionalValues','on'); edtSpeed.Value = 1000;
        lblDir = uilabel(pl,'Text','方向 (0顺/1逆)：','HorizontalAlignment','right');
        ddDir = uidropdown(pl,'Items',{'0','1'},'Value','0');

        lblAccel = uilabel(pl,'Text','加速度档位 (0-255)：','HorizontalAlignment','right');
        edtAccel = uieditfield(pl,'numeric','Limits',[0 255],'RoundFractionalValues','on'); edtAccel.Value = 10;
        % 位置控制参数
        lblPulse = uilabel(pl,'Text','目标脉冲数：','HorizontalAlignment','right');
        edtPulse = uieditfield(pl,'numeric','Limits',[0 4294967295],'RoundFractionalValues','on'); edtPulse.Value = 1000;
        lblPosMode = uilabel(pl,'Text','位置模式 (0相对/1绝对)：','HorizontalAlignment','right');
        ddPosMode = uidropdown(pl,'Items',{'0','1'},'Value','0');

        % 角度控制参数
        lblAngle = uilabel(pl,'Text','目标角度 (度)：','HorizontalAlignment','right');
        edtAngle = uieditfield(pl,'numeric'); edtAngle.Value = 90.0;

        % 原点设置零点/修改参数：保存到Flash
        lblSaveFlash = uilabel(pl,'Text','保存到Flash：','HorizontalAlignment','right');
        cbSaveFlash = uicheckbox(pl,'Text','是'); cbSaveFlash.Value = true;

        % 原点触发/修改参数：回零模式
        lblHomingMode = uilabel(pl,'Text','回零模式 (0/1/2/3)：','HorizontalAlignment','right');
        ddHomingMode = uidropdown(pl,'Items',{'0','1','2','3'},'Value','0');

        % 原点修改参数：方向/速度/超时/碰撞参数/自动回零
        lblHDir = uilabel(pl,'Text','回零方向 (0顺/1逆)：','HorizontalAlignment','right');
        ddHDir = uidropdown(pl,'Items',{'0','1'},'Value','0');
        lblHSpeed = uilabel(pl,'Text','回零速度 (RPM)：','HorizontalAlignment','right');
        edtHSpeed = uieditfield(pl,'numeric'); edtHSpeed.Value = 30;
        lblHTimeout = uilabel(pl,'Text','回零超时 (ms)：','HorizontalAlignment','right');
        edtHTimeout = uieditfield(pl,'numeric'); edtHTimeout.Value = 10000;
        lblHColSpeed = uilabel(pl,'Text','碰撞检测转速 (RPM)：','HorizontalAlignment','right');
        edtHColSpeed = uieditfield(pl,'numeric'); edtHColSpeed.Value = 300;
        lblHColCurrent = uilabel(pl,'Text','碰撞检测电流 (mA)：','HorizontalAlignment','right');
        edtHColCurrent = uieditfield(pl,'numeric'); edtHColCurrent.Value = 800;
        lblHColTime = uilabel(pl,'Text','碰撞检测时间 (ms)：','HorizontalAlignment','right');
        edtHColTime = uieditfield(pl,'numeric'); edtHColTime.Value = 60;
        lblAutoHoming = uilabel(pl,'Text','上电自动回零：','HorizontalAlignment','right');
        cbAutoHoming = uicheckbox(pl,'Text','启用'); cbAutoHoming.Value = false;

        % 诊断读取选择
        lblDiag = uilabel(pl,'Text','诊断读取项：','HorizontalAlignment','right');
        ddDiag = uidropdown(pl,'Items',{
            '固件/硬件版本 (0x1F)',
            '相电阻/相电感 (0x20)',
            '位置环PID (0x21)',
            '总线电压 (0x24)',
            '相电流 (0x27)',
            '电机实时转速 (0x35)',
            '电机实时位置 (0x36)',
            '位置误差 (0x37)',
            '电机状态标志位 (0x3A)',
            '驱动配置 (0x42 0x6C)',
            '系统状态 (0x43 0x7A)'
        }, 'Value','固件/硬件版本 (0x1F)');

        % 默认仅显示与当前命令相关的参数
        function refreshParamFields()
            cmd = ddCmd.Value;
            % 先隐藏所有参数控件
            set([lblSpeed, edtSpeed, lblDir, ddDir, lblAccel, edtAccel, ...
                 lblPulse, edtPulse, lblPosMode, ddPosMode, ...
                 lblAngle, edtAngle, ...
                 lblSaveFlash, cbSaveFlash, ...
                 lblHomingMode, ddHomingMode, ...
                 lblHDir, ddHDir, lblHSpeed, edtHSpeed, lblHTimeout, edtHTimeout, ...
                 lblHColSpeed, edtHColSpeed, lblHColCurrent, edtHColCurrent, lblHColTime, edtHColTime, ...
                 lblAutoHoming, cbAutoHoming, ...
                 lblDiag, ddDiag
            ],'Visible','off');
            switch cmd
                case {'使能电机','禁用电机','停止电机','同步触发'}
                    % 无参数
                case '设置速度'
                    set([lblSpeed, edtSpeed, lblDir, ddDir, lblAccel, edtAccel],'Visible','on');
                case '位置控制'
                    set([lblPulse, edtPulse, lblDir, ddDir, lblSpeed, edtSpeed, lblAccel, edtAccel, lblPosMode, ddPosMode],'Visible','on');
                case '角度控制'
                    set([lblAngle, edtAngle, lblDir, ddDir, lblSpeed, edtSpeed, lblAccel, edtAccel, lblPosMode, ddPosMode],'Visible','on');
                case '原点设置零点'
                    set([lblSaveFlash, cbSaveFlash],'Visible','on');
                case '原点触发回零'
                    set([lblHomingMode, ddHomingMode, lblSpeed, edtSpeed, lblAccel, edtAccel],'Visible','on');
                case '原点强制中断'
                    % 无参数
                case '原点读取参数'
                    % 无参数
                case '原点修改参数'
                    set([lblHomingMode, ddHomingMode, lblHDir, ddHDir, lblHSpeed, edtHSpeed, lblHTimeout, edtHTimeout, ...
                         lblHColSpeed, edtHColSpeed, lblHColCurrent, edtHColCurrent, lblHColTime, edtHColTime, ...
                         lblAutoHoming, cbAutoHoming, lblSaveFlash, cbSaveFlash],'Visible','on');
                case '原点读取状态'
                    % 无参数
                case '诊断读取'
                    set([lblDiag, ddDiag],'Visible','on');
                case {'读取固件/硬件版本 (0x1F)', '读取相电阻/相电感 (0x20)', '读取位置环PID参数 (0x21)', ...
                      '读取总线电压 (0x24)', '读取相电流 (0x27)', '读取电机实时转速 (0x35)', ...
                      '读取电机实时位置 (0x36)', '读取电机位置误差 (0x37)', '读取电机状态标志位 (0x3A)', ...
                      '读取驱动配置参数 (0x42 0x6C)', '读取系统状态参数 (0x43 0x7A)'}
                    % 无参数
            end
        end
        refreshParamFields();

        ddCmd.ValueChangedFcn = @(s,e) refreshParamFields();

        % 发送按钮回调
        function onSend()
            if ~app.is_connected
                appendLog({'✗ CAN设备未连接，请先点击“连接CAN设备”'});
                return;
            end

            try
                cmd = ddCmd.Value;
                multiSync = cbSync.Value;
                addr = int32(address);

                switch cmd
                    case '使能电机'
                        % 实例化并链式设置，避免 MATLAB 对类方法点索引报错
                        c = py.motor_can_lib.EnableControlCommand(int32(addr));
                        c = c.set_enable(true, logical(multiSync));
                        appendLog({sprintf('→ 发送：使能电机 (地址=%d, 多机同步=%d)', addr, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpEnableResponse(resp_data);

                    case '禁用电机'
                        c = py.motor_can_lib.EnableControlCommand(int32(addr));
                        c = c.set_enable(false, logical(multiSync));
                        appendLog({sprintf('→ 发送：禁用电机 (地址=%d, 多机同步=%d)', addr, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpEnableResponse(resp_data);

                    case '设置速度'
                        speed_rpm = int32(edtSpeed.Value);
                        direction = int32(str2double(ddDir.Value));
                        acceleration = int32(edtAccel.Value);
                        c = py.motor_can_lib.SpeedControlCommand(int32(addr));
                        c = c.set_direction(direction);
                        c = c.set_speed(speed_rpm);
                        c = c.set_acceleration(acceleration);
                        c = c.set_multi_sync(logical(multiSync));
                        appendLog({sprintf('→ 发送：速度控制 (地址=%d, 速度=%dRPM, 方向=%d, 加速度=%d, 多机同步=%d)', addr, speed_rpm, direction, acceleration, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpSpeedResponse(resp_data);

                    case '位置控制'
                        pulse_count = int64(edtPulse.Value);
                        direction = int32(str2double(ddDir.Value));
                        speed_rpm = int32(edtSpeed.Value);
                        acceleration = int32(edtAccel.Value);
                        position_mode = int32(str2double(ddPosMode.Value));
                        c = py.motor_can_lib.PositionControlCommand(int32(addr));
                        c = c.set_pulse_count(pulse_count);
                        c = c.set_direction(direction);
                        c = c.set_speed(speed_rpm);
                        c = c.set_acceleration(acceleration);
                        c = c.set_position_mode(position_mode);
                        c = c.set_multi_sync(logical(multiSync));
                        appendLog({sprintf('→ 发送：位置控制 (地址=%d, 脉冲=%d, 方向=%d, 速度=%dRPM, 加速度=%d, 模式=%d, 多机同步=%d)', addr, pulse_count, direction, speed_rpm, acceleration, position_mode, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpPositionResponse(resp_data);

                    case '停止电机'
                        c = py.motor_can_lib.StopControlCommand(int32(addr));
                        c = c.set_multi_sync(logical(multiSync));
                        appendLog({sprintf('→ 发送：停止电机 (地址=%d, 多机同步=%d)', addr, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpStopResponse(resp_data);

                    case '同步触发'
                        c = py.motor_can_lib.SyncControlCommand();
                        appendLog({'→ 发送：同步触发命令（广播触发）'});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpSyncResponse(resp_data);

                    case '角度控制'
                        angle_deg = double(edtAngle.Value);
                        direction = int32(str2double(ddDir.Value));
                        speed_rpm = int32(edtSpeed.Value);
                        acceleration = int32(edtAccel.Value);
                        position_mode = int32(str2double(ddPosMode.Value));
                        c = py.motor_can_lib.PositionControlCommand(int32(addr));
                        c = c.set_angle_degrees(angle_deg);
                        c = c.set_direction(direction);
                        c = c.set_speed(speed_rpm);
                        c = c.set_acceleration(acceleration);
                        c = c.set_position_mode(position_mode);
                        c = c.set_multi_sync(logical(multiSync));
                        appendLog({sprintf('→ 发送：角度控制 (地址=%d, 角度=%.2f°, 方向=%d, 速度=%dRPM, 加速度=%d, 模式=%d, 多机同步=%d)', addr, angle_deg, direction, speed_rpm, acceleration, position_mode, multiSync)});
                        resp_data = c.execute(app.can_base, app.cfg.timeout);
                        dumpPositionResponse(resp_data);

                    case '原点设置零点'
                        save_to_flash = logical(cbSaveFlash.Value);
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点设置零点 (地址=%d, 保存到Flash=%d)', addr, save_to_flash)});
                        resp_data = h.execute_set_zero_position(app.can_base, save_to_flash, app.cfg.timeout);
                        dumpHomingSimple(resp_data, '设置零点');

                    case '原点触发回零'
                        homing_mode = int32(str2double(ddHomingMode.Value));
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点触发回零 (地址=%d, 模式=%d, 多机同步=%d)', addr, homing_mode, multiSync)});
                        resp_data = h.execute_trigger_homing(app.can_base, homing_mode, logical(multiSync), app.cfg.timeout);
                        dumpHomingSimple(resp_data, '触发回零');

                    case '原点强制中断'
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点强制中断 (地址=%d)', addr)});
                        resp_data = h.execute_force_stop_homing(app.can_base, app.cfg.timeout);
                        dumpHomingSimple(resp_data, '强制中断');

                    case '原点读取参数'
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点读取参数 (地址=%d)', addr)});
                        resp_data = h.execute_read_homing_params(app.can_base, app.cfg.timeout);
                        dumpHomingParams(resp_data, addr);

                    case '原点修改参数'
                        params = py.dict();
                        py.setitem(params, 'homing_mode', int32(str2double(ddHomingMode.Value)));
                        py.setitem(params, 'direction', int32(str2double(ddHDir.Value)));
                        py.setitem(params, 'speed_rpm', int32(edtHSpeed.Value));
                        py.setitem(params, 'timeout_ms', int32(edtHTimeout.Value));
                        py.setitem(params, 'collision_speed_rpm', int32(edtHColSpeed.Value));
                        py.setitem(params, 'collision_current_ma', int32(edtHColCurrent.Value));
                        py.setitem(params, 'collision_time_ms', int32(edtHColTime.Value));
                        py.setitem(params, 'auto_homing_enable', logical(cbAutoHoming.Value));
                        save_to_flash = logical(cbSaveFlash.Value);
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点修改参数 (地址=%d, 保存到Flash=%d)', addr, save_to_flash)});
                        resp_data = h.execute_modify_homing_params(app.can_base, params, save_to_flash, app.cfg.timeout);
                        dumpHomingSimple(resp_data, '修改参数');

                    case '原点读取状态'
                        h = py.motor_can_lib.HomingControlCommand(int32(addr));
                        appendLog({sprintf('→ 发送：原点读取状态 (地址=%d)', addr)});
                        resp_data = h.execute_read_homing_status(app.can_base, app.cfg.timeout);
                        dumpHomingStatus(resp_data, addr);

                    case '诊断读取'
                        diag_sel = ddDiag.Value;
                        [execCode, execFnName] = mapDiagSelection(diag_sel);
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：诊断读取 (地址=%d, 项=%s, 码=0x%02X)', addr, diag_sel, execCode)});
                        % 直接按命令码调用实例方法，避免 getattr 调用引发 MATLAB 索引错误
                        switch uint8(execCode)
                            case uint8(hex2dec('1F'))
                                resp_data = d.execute_read_fw_hw_version(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('20'))
                                resp_data = d.execute_read_phase_res_ind(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('21'))
                                resp_data = d.execute_read_position_pid(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('24'))
                                resp_data = d.execute_read_bus_voltage(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('27'))
                                resp_data = d.execute_read_phase_current(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('35'))
                                resp_data = d.execute_read_motor_speed(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('36'))
                                resp_data = d.execute_read_motor_position(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('37'))
                                resp_data = d.execute_read_position_error(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('3A'))
                                resp_data = d.execute_read_motor_state_flags(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('42'))
                                resp_data = d.execute_read_driver_config(app.can_base, app.cfg.timeout);
                            case uint8(hex2dec('43'))
                                resp_data = d.execute_read_system_status(app.can_base, app.cfg.timeout);
                            otherwise
                                resp_data = [];
                        end
                        dumpDiagnostic(resp_data, execCode, addr);

                    % 直接在主下拉中提供 11 项诊断读取
                    case '读取固件/硬件版本 (0x1F)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取固件/硬件版本 (地址=%d)', addr)});
                        resp_data = d.execute_read_fw_hw_version(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('1F')), addr);

                    case '读取相电阻/相电感 (0x20)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取相电阻/相电感 (地址=%d)', addr)});
                        resp_data = d.execute_read_phase_res_ind(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('20')), addr);

                    case '读取位置环PID参数 (0x21)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取位置环PID参数 (地址=%d)', addr)});
                        resp_data = d.execute_read_position_pid(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('21')), addr);

                    case '读取总线电压 (0x24)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取总线电压 (地址=%d)', addr)});
                        resp_data = d.execute_read_bus_voltage(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('24')), addr);

                    case '读取相电流 (0x27)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取相电流 (地址=%d)', addr)});
                        resp_data = d.execute_read_phase_current(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('27')), addr);

                    case '读取电机实时转速 (0x35)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取电机实时转速 (地址=%d)', addr)});
                        resp_data = d.execute_read_motor_speed(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('35')), addr);

                    case '读取电机实时位置 (0x36)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取电机实时位置 (地址=%d)', addr)});
                        resp_data = d.execute_read_motor_position(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('36')), addr);

                    case '读取电机位置误差 (0x37)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取电机位置误差 (地址=%d)', addr)});
                        resp_data = d.execute_read_position_error(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('37')), addr);

                    case '读取电机状态标志位 (0x3A)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取电机状态标志位 (地址=%d)', addr)});
                        resp_data = d.execute_read_motor_state_flags(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('3A')), addr);

                    case '读取驱动配置参数 (0x42 0x6C)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取驱动配置参数 (地址=%d)', addr)});
                        resp_data = d.execute_read_driver_config(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('42')), addr);

                    case '读取系统状态参数 (0x43 0x7A)'
                        d = py.motor_can_lib.DiagnosticCommand(int32(addr));
                        appendLog({sprintf('→ 发送：读取系统状态参数 (地址=%d)', addr)});
                        resp_data = d.execute_read_system_status(app.can_base, app.cfg.timeout);
                        dumpDiagnostic(resp_data, uint8(hex2dec('43')), addr);
                end
            catch ME
                appendLog({'✗ 指令发送/解析失败', ME.message});
            end
        end

        % 响应解析辅助函数（尽量调用 Python 响应对象的方法）
        function dumpEnableResponse(resp_data)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.EnableResponse(resp_data);
                ok = logical(r.is_success());
                msg = char(r.get_status_meaning());
                appendLog({sprintf('← 使能/禁用响应：%s', msg)});
                if ok, appendLog({'✓ 操作成功'}); else, appendLog({'✗ 操作失败'}); end
            catch
                appendLog({'(原始) 响应数据：', char(py.str(resp_data))});
            end
        end

        function dumpSpeedResponse(resp_data)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.SpeedResponse(resp_data);
                ok = logical(r.is_success());
                msg = char(r.get_status_meaning());
                appendLog({sprintf('← 速度响应：%s', msg)});
                if ok, appendLog({'✓ 速度设置成功'}); else, appendLog({'✗ 速度设置失败'}); end
            catch
                appendLog({'(原始) 响应数据：', char(py.str(resp_data))});
            end
        end

        function dumpPositionResponse(resp_data)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.PositionResponse(resp_data);
                ok = logical(r.is_success());
                msg = char(r.get_status_meaning());
                appendLog({sprintf('← 位置响应：%s', msg)});
                if ok, appendLog({'✓ 位置控制命令发送成功'}); else, appendLog({'✗ 位置控制失败'}); end
            catch
                appendLog({'(原始) 响应数据：', char(py.str(resp_data))});
            end
        end

        function dumpStopResponse(resp_data)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.StopResponse(resp_data);
                ok = logical(r.is_success());
                msg = char(r.get_status_meaning());
                appendLog({sprintf('← 停止响应：%s', msg)});
                if ok, appendLog({'✓ 停止成功'}); else, appendLog({'✗ 停止失败'}); end
            catch
                appendLog({'(原始) 响应数据：', char(py.str(resp_data))});
            end
        end

        function dumpSyncResponse(resp_data)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.SyncResponse(resp_data);
                desc = char(r.get_status_description());
                appendLog({sprintf('← 同步响应：%s', desc)});
            catch
                appendLog({'(原始) 响应数据：', char(py.str(resp_data))});
            end
        end

        % 原点响应（简单状态类：设置/触发/强制/修改）
        function dumpHomingSimple(resp_data, actionName)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.HomingResponse(resp_data);
                % 根据动作名选择解析方法
                switch actionName
                    case '设置零点'
                        res = r.parse_set_zero_position_response();
                    case '触发回零'
                        res = r.parse_trigger_homing_response();
                    case '强制中断'
                        res = r.parse_force_stop_homing_response();
                    case '修改参数'
                        res = r.parse_modify_homing_params_response();
                    otherwise
                        res = py.dict();
                end
                % 使用函数式访问字典，避免 getattr(...)(...) 导致索引错误
                ok_val = py.dict.get(res, 'success');
                ok = ~isempty(ok_val) && logical(ok_val);
                appendLog({sprintf('← 原点响应（%s）：%s', actionName, ternary(ok,'成功','失败'))});
            catch
                appendLog({'(原始) 原点响应数据：', char(py.str(resp_data))});
            end
        end

        % 原点参数读取
        function dumpHomingParams(resp_data, addr)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.HomingResponse(resp_data, int32(addr));
                res = r.parse_read_homing_params_response();
                text = r.format_homing_params(res);
                appendLog({'← 原点参数读取成功：', char(text)});
            catch
                appendLog({'(原始) 原点参数响应数据：', char(py.str(resp_data))});
            end
        end

        % 原点状态读取
        function dumpHomingStatus(resp_data, addr)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                r = py.motor_can_lib.HomingResponse(resp_data, int32(addr));
                res = r.parse_read_homing_status_response();
                text = r.format_homing_status(res);
                appendLog({'← 原点状态读取成功：', char(text)});
            catch
                appendLog({'(原始) 原点状态响应数据：', char(py.str(resp_data))});
            end
        end

        % 诊断选择映射：返回命令码与执行函数名
        function [code, fnName] = mapDiagSelection(sel)
            switch sel
                case '固件/硬件版本 (0x1F)'
                    code = uint8(hex2dec('1F')); fnName = 'execute_read_fw_hw_version';
                case '相电阻/相电感 (0x20)'
                    code = uint8(hex2dec('20')); fnName = 'execute_read_phase_res_ind';
                case '位置环PID (0x21)'
                    code = uint8(hex2dec('21')); fnName = 'execute_read_position_pid';
                case '总线电压 (0x24)'
                    code = uint8(hex2dec('24')); fnName = 'execute_read_bus_voltage';
                case '相电流 (0x27)'
                    code = uint8(hex2dec('27')); fnName = 'execute_read_phase_current';
                case '电机实时转速 (0x35)'
                    code = uint8(hex2dec('35')); fnName = 'execute_read_motor_speed';
                case '电机实时位置 (0x36)'
                    code = uint8(hex2dec('36')); fnName = 'execute_read_motor_position';
                case '位置误差 (0x37)'
                    code = uint8(hex2dec('37')); fnName = 'execute_read_position_error';
                case '电机状态标志位 (0x3A)'
                    code = uint8(hex2dec('3A')); fnName = 'execute_read_motor_state_flags';
                case '驱动配置 (0x42 0x6C)'
                    code = uint8(hex2dec('42')); fnName = 'execute_read_driver_config';
                case '系统状态 (0x43 0x7A)'
                    code = uint8(hex2dec('43')); fnName = 'execute_read_system_status';
                otherwise
                    code = uint8(0); fnName = '';
            end
        end

        % 诊断响应解析与打印（避免类方法点索引，使用实例方法）
        function dumpDiagnostic(resp_data, code, addr)
            if isempty(resp_data)
                appendLog({'✗ 未收到响应数据'}); return; end
            try
                dr = py.motor_can_lib.responses.DiagnosticResponse(resp_data, int32(addr));
                % 按命令码选择实例解析方法
                switch uint8(code)
                    case uint8(hex2dec('1F'))
                        parsed = dr.parse_fw_hw_version();
                    case uint8(hex2dec('20'))
                        parsed = dr.parse_phase_res_ind();
                    case uint8(hex2dec('21'))
                        parsed = dr.parse_position_pid();
                    case uint8(hex2dec('24'))
                        parsed = dr.parse_bus_voltage();
                    case uint8(hex2dec('27'))
                        parsed = dr.parse_phase_current();
                    case uint8(hex2dec('35'))
                        parsed = dr.parse_motor_speed();
                    case uint8(hex2dec('36'))
                        parsed = dr.parse_motor_position();
                    case uint8(hex2dec('37'))
                        parsed = dr.parse_position_error();
                    case uint8(hex2dec('3A'))
                        parsed = dr.parse_motor_state_flags();
                    case uint8(hex2dec('42'))
                        parsed = dr.parse_driver_config();
                    case uint8(hex2dec('43'))
                        parsed = dr.parse_system_status();
                    otherwise
                        parsed = py.dict();
                end

                % 打印通用/重要字段（参照交互脚本一致的风格）
                appendLog({'--- 响应解析 ---'});
                printField(parsed,'address','地址');
                printField(parsed,'command_code','命令码');
                printField(parsed,'raw_data','原始数据');
                printField(parsed,'firmware_code','固件版本码');
                printField(parsed,'hardware_code','硬件版本码');
                printField(parsed,'phase_resistance_milliohm','相电阻(mΩ)');
                printField(parsed,'phase_inductance_uH','相电感(µH)');
                printField(parsed,'Kp','Kp'); printField(parsed,'Ki','Ki'); printField(parsed,'Kd','Kd');
                printField(parsed,'bus_voltage_mv','总线电压(mV)');
                printField(parsed,'phase_current_ma','相电流(mA)');
                printField(parsed,'sign','速度符号');
                printField(parsed,'speed_rpm','速度(RPM)');
                printField(parsed,'position_raw','位置原始值');
                printField(parsed,'position_degrees','位置(度)');
                printField(parsed,'error_raw','位置误差原始值');
                printField(parsed,'error_degrees','位置误差(度)');
                printField(parsed,'flags_byte','状态标志字节');
                printField(parsed,'enabled','已使能');
                printField(parsed,'in_position','到位');
                printField(parsed,'stalled','堵转');
                printField(parsed,'stall_protection','堵转保护');
                printField(parsed,'total_len','总长度');
                printField(parsed,'param_count','参数个数');
                printField(parsed,'payload','负载数据');

                if uint8(code) == uint8(hex2dec('42'))
                    appendLog({'--- 驱动配置明细 ---'});
                    printField(parsed,'motor_type_desc','电机类型');
                    printField(parsed,'motor_type_code','电机类型码');
                    printField(parsed,'pulse_mode_desc','脉冲控制模式');
                    printField(parsed,'pulse_mode_code','脉冲控制模式码');
                    printField(parsed,'comm_func_desc','通讯复用模式');
                    printField(parsed,'comm_func_code','通讯复用模式码');
                    printField(parsed,'en_level_desc','En引脚有效电平');
                    printField(parsed,'en_level_code','En引脚码');
                    printField(parsed,'dir_desc','Dir方向');
                    printField(parsed,'dir_code','Dir码');
                    printField(parsed,'subdivision_value','细分值');
                    printField(parsed,'subdivision_raw','细分原始码');
                    printField(parsed,'subdivision_interp_enabled','细分插补开启');
                    printField(parsed,'auto_screen_off_enabled','自动熄屏开启');
                    printField(parsed,'open_loop_current_ma','开环工作电流(mA)');
                    printField(parsed,'stall_max_current_ma','堵转最大电流(mA)');
                    printField(parsed,'max_output_voltage_mv','闭环最大输出电压(mV)');
                    printField(parsed,'uart_baud_rate','串口波特率');
                    printField(parsed,'uart_baud_option','串口波特率选项码');
                    printField(parsed,'can_bitrate_value','CAN速率');
                    printField(parsed,'can_bitrate_option','CAN速率选项码');
                    printField(parsed,'device_id','设备ID');
                    printField(parsed,'checksum_mode_desc','校验模式');
                    printField(parsed,'checksum_mode_code','校验模式码');
                    printField(parsed,'command_ack_mode_desc','命令应答模式');
                    printField(parsed,'command_ack_mode_code','命令应答模式码');
                    printField(parsed,'stall_protect_enabled','堵转保护开启');
                    printField(parsed,'stall_speed_threshold_rpm','堵转速度阈值(RPM)');
                    printField(parsed,'stall_current_threshold_ma','堵转电流阈值(mA)');
                    printField(parsed,'stall_time_threshold_ms','堵转检测时间阈值(ms)');
                    printField(parsed,'position_window_raw','位置到达窗口原始值');
                    printField(parsed,'position_window_deg','位置到达窗口(度)');
                end

                if uint8(code) == uint8(hex2dec('43'))
                    appendLog({'--- 系统状态明细 ---'});
                    printField(parsed,'bus_voltage_mv','总线电压(mV)');
                    printField(parsed,'phase_current_ma','总线相电流(mA)');
                    printField(parsed,'encoder_calibrated_value','校准后编码器值');
                    printField(parsed,'target_position_sign','目标位置符号');
                    printField(parsed,'target_position_raw','目标位置原始值');
                    printField(parsed,'target_position_degrees','目标位置(度)');
                    printField(parsed,'speed_sign','速度符号');
                    printField(parsed,'speed_rpm','速度(RPM)');
                    printField(parsed,'position_sign','实时位置符号');
                    printField(parsed,'position_raw','实时位置原始值');
                    printField(parsed,'position_degrees','实时位置(度)');
                    printField(parsed,'error_sign','位置误差符号');
                    printField(parsed,'error_raw','位置误差原始值');
                    printField(parsed,'error_degrees','位置误差(度)');
                    printField(parsed,'ready_flags_byte','就绪状态标志字节');
                    printField(parsed,'encoder_ready','编码器就绪');
                    printField(parsed,'calibration_table_ready','校准表就绪');
                    printField(parsed,'homing_running','正在回零');
                    printField(parsed,'homing_failed','回零失败');
                    printField(parsed,'motor_state_flags_byte','电机状态标志字节');
                    printField(parsed,'enabled','已使能');
                    printField(parsed,'in_position','到位');
                    printField(parsed,'stalled','堵转');
                    printField(parsed,'stall_protection','堵转保护');
                end

                % 如果未打印到具体字段，至少打印完整解析内容
                try
                    if isa(parsed,'py.dict')
                        appendLog({'--- 诊断完整内容 ---', char(py.str(parsed))});
                    else
                        appendLog({'诊断内容：', char(py.str(parsed))});
                    end
                catch
                    % 忽略无法转字符串的对象
                end

                appendLog({'✓ 诊断读取完成'});
            catch ME
                appendLog({'✗ 诊断解析失败', ME.message});
                appendLog({'(原始) 诊断响应数据：', char(py.str(resp_data))});
            end
        end

        % 打印字段辅助（存在则打印；bytes 转十六进制）
        function printField(parsed, key, label)
            try
                % 首选使用 py.dict.get，若失败则回退到 parsed.get
                val = [];
                try
                    val = py.dict.get(parsed, py.str(key));
                catch
                    try
                        getfn = py.getattr(parsed,'get');
                        val = getfn(py.str(key));
                    catch
                        val = [];
                    end
                end

                % 过滤 None
                if ~isempty(val)
                    sval = char(py.str(val));
                    if strcmpi(sval,'None')
                        val = [];
                    end
                end

                if ~isempty(val)
                    if isa(val,'py.bytes') || isa(val,'py.bytearray')
                        s = pyBytesToHexStr(val);
                        appendLog({sprintf('%s: %s', label, s)});
                    else
                        appendLog({sprintf('%s: %s', label, char(py.str(val)))});
                    end
                end
            catch
                % 忽略不可打印字段
            end
        end

        % 将 Python bytes/bytearray 转为十六进制字符串（形如 "1F 05 82 6B"）
        function s = pyBytesToHexStr(pyBytes)
            try
                lst = cell(py.list(pyBytes));             % Python 列表 -> MATLAB cell
                nums = cellfun(@double, lst);             % 每个元素转为 double
                hexes = arrayfun(@(b) upper(dec2hex(b,2)), nums, 'UniformOutput', false);
                s = strjoin(hexes, ' ');
            catch
                % 回退到 Python 字符串表示
                s = char(py.str(pyBytes));
            end
        end

        % 简单三元选择
        function out = ternary(cond, a, b)
            if cond, out = a; else, out = b; end
        end
    end
end