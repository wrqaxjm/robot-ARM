function main_app()
% 主界面（左右布局，左侧切换栏：主页/指令控制）
% 说明：
% - 左侧为切换按钮，右侧为内容区域；当前包含“主页”和“指令控制”。
% - 指令控制界面内嵌自 command_control_app.m（支持传入父容器）。
% - 代码包含中文注释，便于理解与维护。

    % 创建主窗口
    fig = uifigure('Name','主界面','Position',[100 100 1024 720]);
    % 关闭事件：优雅断开 CAN，避免 slcanBus 未正确关闭
    fig.CloseRequestFcn = @(src,evt) cleanupOnClose();

    % 顶层网格布局：左右两列
    gl = uigridlayout(fig,[1 2]);
    gl.ColumnWidth = {180, '1x'};

    % 左侧切换栏
    leftPanel = uipanel(gl, 'Title','切换');
    leftPanel.Layout.Column = 1;
    leftLayout = uigridlayout(leftPanel,[6 1]);
    leftLayout.RowHeight = {40,40,40,40,'1x',30};

    btnHome   = uibutton(leftLayout, 'Text','主页');
    btnCmd    = uibutton(leftLayout, 'Text','指令控制');
    btnArm    = uibutton(leftLayout, 'Text','机械臂控制');
    btnParams = uibutton(leftLayout, 'Text','参数界面');

    % 调整按钮在侧栏中的显示顺序：将“参数界面”置于“机械臂控制”之上
    try
        btnHome.Layout.Row   = 1;
        btnCmd.Layout.Row    = 2;
        btnParams.Layout.Row = 3;
        btnArm.Layout.Row    = 4;
    catch
        % 若旧版 MATLAB 不支持显式设置，默认按创建顺序显示（不影响功能）
    end

    % 右侧内容区域
    contentPanel = uipanel(gl, 'Title','内容');
    contentPanel.Layout.Column = 2;
    contentLayout = uigridlayout(contentPanel,[1 1]);

    % 子界面容器：主页/指令控制/机械臂控制/参数界面/3D显示界面
    homePanel = uipanel(contentLayout, 'Title','主页');
    homePanel.Layout.Row = 1; homePanel.Layout.Column = 1;
    % 主页暂为空白，可后续填充

    cmdPanel = uipanel(contentLayout, 'Title','指令控制');
    cmdPanel.Layout.Row = 1; cmdPanel.Layout.Column = 1;
    cmdPanel.Visible = 'off'; % 默认显示主页
    
    armPanel = uipanel(contentLayout, 'Title','机械臂控制');
    armPanel.Layout.Row = 1; armPanel.Layout.Column = 1;
    armPanel.Visible = 'off';

    paramsPanel = uipanel(contentLayout, 'Title','参数界面');
    paramsPanel.Layout.Row = 1; paramsPanel.Layout.Column = 1;
    paramsPanel.Visible = 'off';


    % 懒加载各子界面（避免重复创建）
    cmdViewInitialized = false;
    armViewInitialized = false;
    paramsViewInitialized = false;
    

    % 切换回调
    btnHome.ButtonPushedFcn   = @(s,e) showPanel('home');
    btnCmd.ButtonPushedFcn    = @(s,e) showPanel('cmd');
    btnArm.ButtonPushedFcn    = @(s,e) showPanel('arm');
    btnParams.ButtonPushedFcn = @(s,e) showPanel('params');
    

    function showPanel(which)
        switch which
            case 'home'
                homePanel.Visible = 'on';
                cmdPanel.Visible  = 'off'; armPanel.Visible = 'off'; paramsPanel.Visible = 'off';
            case 'cmd'
                homePanel.Visible = 'off';
                cmdPanel.Visible  = 'on';
                if ~cmdViewInitialized
                    % 内嵌指令控制界面到 cmdPanel
                    try
                        command_control_app(cmdPanel);
                        cmdViewInitialized = true;
                    catch ME
                        uialert(fig, sprintf('加载指令控制界面失败：\n%s', ME.message), '错误');
                    end
                end
                armPanel.Visible  = 'off'; paramsPanel.Visible = 'off';
            case 'arm'
                homePanel.Visible = 'off';
                cmdPanel.Visible  = 'off';
                armPanel.Visible  = 'on';
                if ~armViewInitialized
                    try
                        integrated_robot_gui(armPanel);
                        armViewInitialized = true;
                    catch ME
                        uialert(fig, sprintf('加载机械臂控制界面失败：\n%s', ME.message), '错误');
                    end
                end
                paramsPanel.Visible = 'off';
            case 'params'
                homePanel.Visible = 'off';
                cmdPanel.Visible  = 'off';
                armPanel.Visible  = 'off';
                paramsPanel.Visible = 'on';
                if ~paramsViewInitialized
                    try
                        params_app(paramsPanel);
                        paramsViewInitialized = true;
                    catch ME
                        uialert(fig, sprintf('加载参数界面失败：\n%s', ME.message), '错误');
                    end
                end
        end
    end

    function cleanupOnClose()
        % 优雅断开：尝试调用全局共享的 CAN 连接断开，避免 Python 在析构时写串口失败
        try
            % 1. 清理所有定时器（避免回调继续执行）
            try
                allTimers = timerfindall;
                if ~isempty(allTimers)
                    stop(allTimers);
                    delete(allTimers);
                end
            catch ME
                warning('清理定时器失败: %s', ME.message);
            end
            
            % 2. 断开 CAN 连接
            can_connected = false;
            try
                conn_val = getappdata(0,'can_connected');
                if ~isempty(conn_val)
                    can_connected = logical(conn_val(1));
                end
            catch
            end
            
            if can_connected
                can_base = [];
                try
                    can_base = getappdata(0,'can_base');
                catch
                end
                try
                    if ~isempty(can_base)
                        % 调用底层断开
                        res = logical(can_base.disconnect()); %#ok<NASGU>
                        pause(0.2); % 稍作等待，确保底层写入完成
                    end
                catch ME
                    % 断开异常不再阻塞关闭
                    warning('断开 CAN 发生异常：%s', ME.message);
                end
                % 清理共享标志
                try
                    setappdata(0,'can_connected',false);
                    setappdata(0,'can_base',[]);
                catch
                end
            end
        catch ME
            warning('清理资源失败: %s', ME.message);
        end
        
        % 3. 删除窗口
        try
            if isvalid(fig)
                delete(fig);
            end
        catch
        end
    end

end