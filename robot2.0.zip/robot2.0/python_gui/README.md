# Python GUI 上位机软件

六轴机械臂上位机软件（Python + PyQt5版本）

## 功能模块

- **主界面** (`main_window.py`): 主窗口，包含功能切换栏和内容区域
- **指令控制界面** (`command_control_window.py`): CAN设备连接、指令发送、日志显示
- **机械臂控制界面** (`robot_control_window.py`): 3D显示、关节/笛卡尔控制
- **参数界面** (`params_window.py`): DH参数配置、URDF加载

## 安装依赖

```bash
pip install -r requirements.txt
```

## 运行

```bash
# 推荐方式：使用run.py启动
python run.py

# 或运行主界面
python -m python_gui.main_window
```

## 项目结构

```
python_gui/
├── __init__.py
├── main_window.py              # 主界面
├── command_control_window.py   # 指令控制界面
├── robot_control_window.py     # 机械臂控制界面
├── params_window.py            # 参数配置界面
├── run.py                      # 启动脚本
├── requirements.txt            # 依赖列表
└── README.md                  # 说明文档
```

## 机械臂控制界面说明

### 3D显示区域

- **左侧：实时模型**
  - 显示从CAN设备实时获取的机械臂状态
  - 需要连接CAN设备才能更新
  - 自动定期更新（100ms间隔）

- **右侧：理论模型**
  - 显示根据控制面板输入的理论位置
  - 无需CAN连接即可使用
  - 用于预览运动轨迹

### 控制模式

#### 关节模式
- 通过6个滑条或数值框直接控制各关节角度（-180° 至 +180°）
- 实时预览理论模型的姿态
- 点击"发送到电机"将当前角度发送到实际机械臂

#### 笛卡尔模式
- 输入目标位置（X, Y, Z）和姿态（Roll, Pitch, Yaw）
- 点击"逆运动学解算"自动计算各关节角度
- 解算成功后可发送到电机执行

### 使用流程

1. 在"指令控制"界面连接CAN设备（可选）
2. 切换到"机械臂控制"界面
3. 选择控制模式（关节/笛卡尔）
4. 调整参数，观察理论模型变化
5. 点击"发送到电机"执行运动

## 开发计划

- [x] 主界面框架
- [x] 指令控制界面
- [x] 机械臂控制界面（3D显示 + 控制面板）
- [x] 参数界面（DH参数配置）
- [ ] 实时读取电机位置并更新实时模型
- [ ] 从参数界面读取DH参数用于逆运动学
- [ ] 配置文件管理
- [ ] 轨迹规划功能

