"""
指令控制界面（PyQt5）
功能说明：
- 连接/断开 CAN 设备
- 选择电机/广播地址
- 选择指令类型并填写参数
- 发送指令并显示响应
- 右侧日志显示区域
参照 MATLAB 版本的 command_control_app.m
"""

import sys
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QTabWidget, QComboBox, QLineEdit, 
                             QCheckBox, QTextEdit, QGroupBox, QGridLayout,
                             QMessageBox, QSpinBox, QDoubleSpinBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont, QTextCursor, QIntValidator
import sys
import os

# 添加项目根目录到路径，以便导入 motor_can_lib
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from motor_can_lib import (
        MotorCANBase,
        EnableControlCommand, SpeedControlCommand, PositionControlCommand,
        StopControlCommand, SyncControlCommand, HomingControlCommand,
        DiagnosticCommand,
        EnableResponse, SpeedResponse, PositionResponse, StopResponse,
        SyncResponse, HomingResponse, DiagnosticResponse
    )
except ImportError as e:
    print(f'警告：无法导入 motor_can_lib: {e}')
    # 定义空类以避免运行时错误
    MotorCANBase = None


class CommandControlWindow(QWidget):
    """指令控制窗口"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        
        # 配置参数
        self.com_port = 'COM11'
        self.bitrate = 500000
        self.timeout = 2.0
        
        # CAN 连接状态
        self.can_base = None
        self.is_connected = False
        
        # 初始化UI
        self._init_ui()
    
    def _init_ui(self):
        """初始化用户界面"""
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # ========== 左侧主区域 ==========
        left_panel = QGroupBox('指令控制')
        left_layout = QVBoxLayout(left_panel)
        
        # 连接/断开按钮行
        conn_layout = QHBoxLayout()
        self.btn_connect = QPushButton('连接CAN设备')
        self.btn_disconnect = QPushButton('断开CAN设备')
        self.btn_disconnect.setEnabled(False)
        
        conn_layout.addWidget(self.btn_connect)
        conn_layout.addWidget(self.btn_disconnect)
        left_layout.addLayout(conn_layout)
        
        # 连接信号
        self.btn_connect.clicked.connect(self._on_connect)
        self.btn_disconnect.clicked.connect(self._on_disconnect)
        
        # Tab 标签页（广播 + 电机1-6）
        self.tab_widget = QTabWidget()
        self.tabs = {}
        
        # 创建各个Tab
        addresses = [0, 1, 2, 3, 4, 5, 6]
        tab_names = ['广播', '电机1', '电机2', '电机3', '电机4', '电机5', '电机6']
        
        for addr, name in zip(addresses, tab_names):
            tab = self._create_command_tab(addr)
            self.tab_widget.addTab(tab, name)
            self.tabs[addr] = tab
        
        left_layout.addWidget(self.tab_widget)
        
        # 状态标签
        self.status_label = QLabel('状态：未连接')
        self.status_label.setStyleSheet("color: red; font-weight: bold;")
        left_layout.addWidget(self.status_label)
        
        # ========== 右侧日志区域 ==========
        right_panel = QGroupBox('日志')
        right_layout = QVBoxLayout(right_panel)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont('Consolas', 9))
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        right_layout.addWidget(self.log_text)
        
        # 添加到主布局
        main_layout.addWidget(left_panel, stretch=2)
        main_layout.addWidget(right_panel, stretch=1)
    
    def _create_command_tab(self, address):
        """创建命令Tab页面"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # 地址显示
        addr_label = QLabel(f'当前地址：{address}')
        layout.addWidget(addr_label)
        
        # 指令选择
        cmd_layout = QHBoxLayout()
        cmd_layout.addWidget(QLabel('选择指令：'))
        cmd_combo = QComboBox()
        cmd_combo.addItems([
            '使能电机', '禁用电机', '设置速度', '位置控制', '角度控制',
            '停止电机', '同步触发', '原点设置零点', '原点触发回零',
            '原点强制中断', '原点读取参数', '原点修改参数', '原点读取状态',
            '诊断读取', '读取固件/硬件版本 (0x1F)', '读取相电阻/相电感 (0x20)',
            '读取位置环PID参数 (0x21)', '读取总线电压 (0x24)', '读取相电流 (0x27)',
            '读取电机实时转速 (0x35)', '读取电机实时位置 (0x36)',
            '读取电机位置误差 (0x37)', '读取电机状态标志位 (0x3A)',
            '读取驱动配置参数 (0x42 0x6C)', '读取系统状态参数 (0x43 0x7A)'
        ])
        cmd_layout.addWidget(cmd_combo)
        layout.addLayout(cmd_layout)
        
        # 参数面板（使用网格布局，参照MATLAB版本）
        param_group = QGroupBox('参数')
        param_group.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 2px solid #cccccc;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        param_layout = QGridLayout(param_group)
        param_layout.setSpacing(10)
        param_layout.setContentsMargins(15, 15, 15, 15)
        
        # 创建参数控件字典（存储标签和控件）
        param_widgets = {}
        param_rows = []  # 存储每行的所有控件，便于批量显示/隐藏
        
        # 速度控制参数（第0行）
        row0_widgets = []
        lbl_speed = QLabel('目标速度 (RPM)：')
        lbl_speed.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_speed, 0, 0)
        row0_widgets.append(lbl_speed)
        
        speed_spin = QSpinBox()
        speed_spin.setRange(0, 65535)
        speed_spin.setValue(1000)
        param_layout.addWidget(speed_spin, 0, 1)
        param_widgets['speed'] = speed_spin
        row0_widgets.append(speed_spin)
        
        lbl_dir = QLabel('方向 (0顺/1逆)：')
        lbl_dir.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_dir, 0, 2)
        row0_widgets.append(lbl_dir)
        
        dir_combo = QComboBox()
        dir_combo.addItems(['0', '1'])
        param_layout.addWidget(dir_combo, 0, 3)
        param_widgets['direction'] = dir_combo
        row0_widgets.append(dir_combo)
        param_rows.append(row0_widgets)
        
        # 加速度参数（第1行）
        row1_widgets = []
        lbl_accel = QLabel('加速度档位 (0-255)：')
        lbl_accel.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_accel, 1, 0)
        row1_widgets.append(lbl_accel)
        
        accel_spin = QSpinBox()
        accel_spin.setRange(0, 255)
        accel_spin.setValue(10)
        param_layout.addWidget(accel_spin, 1, 1)
        param_widgets['acceleration'] = accel_spin
        row1_widgets.append(accel_spin)
        param_rows.append(row1_widgets)
        
        # 位置控制参数（第2行）
        row2_widgets = []
        lbl_pulse = QLabel('目标脉冲数：')
        lbl_pulse.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_pulse, 2, 0)
        row2_widgets.append(lbl_pulse)
        
        pulse_edit = QLineEdit()
        pulse_edit.setText('1000')
        param_layout.addWidget(pulse_edit, 2, 1)
        param_widgets['pulse'] = pulse_edit
        row2_widgets.append(pulse_edit)
        
        lbl_pos_mode = QLabel('位置模式 (0绝对/1相对)：')
        lbl_pos_mode.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_pos_mode, 2, 2)
        row2_widgets.append(lbl_pos_mode)
        
        pos_mode_combo = QComboBox()
        pos_mode_combo.addItems(['0', '1'])
        param_layout.addWidget(pos_mode_combo, 2, 3)
        param_widgets['position_mode'] = pos_mode_combo
        row2_widgets.append(pos_mode_combo)
        param_rows.append(row2_widgets)
        
        # 角度控制参数（第3行）
        row3_widgets = []
        lbl_angle = QLabel('目标角度 (度)：')
        lbl_angle.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_angle, 3, 0)
        row3_widgets.append(lbl_angle)
        
        angle_spin = QDoubleSpinBox()
        angle_spin.setRange(-360, 360)
        angle_spin.setValue(90.0)
        angle_spin.setDecimals(2)
        param_layout.addWidget(angle_spin, 3, 1)
        param_widgets['angle'] = angle_spin
        row3_widgets.append(angle_spin)
        param_rows.append(row3_widgets)
        
        # 原点设置零点参数（第4行）
        row4_widgets = []
        lbl_save_flash = QLabel('保存到Flash：')
        lbl_save_flash.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_save_flash, 4, 0)
        row4_widgets.append(lbl_save_flash)
        
        save_flash_check = QCheckBox('是')
        save_flash_check.setChecked(True)
        param_layout.addWidget(save_flash_check, 4, 1)
        param_widgets['save_flash'] = save_flash_check
        row4_widgets.append(save_flash_check)
        
        lbl_homing_mode = QLabel('回零模式 (0/1/2/3)：')
        lbl_homing_mode.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_homing_mode, 4, 2)
        row4_widgets.append(lbl_homing_mode)
        
        homing_mode_combo = QComboBox()
        homing_mode_combo.addItems(['0', '1', '2', '3'])
        param_layout.addWidget(homing_mode_combo, 4, 3)
        param_widgets['homing_mode'] = homing_mode_combo
        row4_widgets.append(homing_mode_combo)
        param_rows.append(row4_widgets)
        
        # 原点修改参数：方向/速度（第5行）
        row5_widgets = []
        lbl_h_dir = QLabel('回零方向 (0顺/1逆)：')
        lbl_h_dir.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_dir, 5, 0)
        row5_widgets.append(lbl_h_dir)
        
        h_dir_combo = QComboBox()
        h_dir_combo.addItems(['0', '1'])
        param_layout.addWidget(h_dir_combo, 5, 1)
        param_widgets['homing_direction'] = h_dir_combo
        row5_widgets.append(h_dir_combo)
        
        lbl_h_speed = QLabel('回零速度 (RPM)：')
        lbl_h_speed.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_speed, 5, 2)
        row5_widgets.append(lbl_h_speed)
        
        h_speed_spin = QSpinBox()
        h_speed_spin.setRange(0, 65535)
        h_speed_spin.setValue(30)
        param_layout.addWidget(h_speed_spin, 5, 3)
        param_widgets['homing_speed'] = h_speed_spin
        row5_widgets.append(h_speed_spin)
        param_rows.append(row5_widgets)
        
        # 原点修改参数：超时/碰撞检测（第6行）
        row6_widgets = []
        lbl_h_timeout = QLabel('回零超时 (ms)：')
        lbl_h_timeout.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_timeout, 6, 0)
        row6_widgets.append(lbl_h_timeout)
        
        h_timeout_spin = QSpinBox()
        h_timeout_spin.setRange(0, 2147483647)
        h_timeout_spin.setValue(10000)
        param_layout.addWidget(h_timeout_spin, 6, 1)
        param_widgets['homing_timeout'] = h_timeout_spin
        row6_widgets.append(h_timeout_spin)
        
        lbl_h_col_speed = QLabel('碰撞检测转速 (RPM)：')
        lbl_h_col_speed.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_col_speed, 6, 2)
        row6_widgets.append(lbl_h_col_speed)
        
        h_col_speed_spin = QSpinBox()
        h_col_speed_spin.setRange(0, 65535)
        h_col_speed_spin.setValue(300)
        param_layout.addWidget(h_col_speed_spin, 6, 3)
        param_widgets['homing_collision_speed'] = h_col_speed_spin
        row6_widgets.append(h_col_speed_spin)
        param_rows.append(row6_widgets)
        
        # 原点修改参数：碰撞检测电流/时间（第7行）
        row7_widgets = []
        lbl_h_col_current = QLabel('碰撞检测电流 (mA)：')
        lbl_h_col_current.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_col_current, 7, 0)
        row7_widgets.append(lbl_h_col_current)
        
        h_col_current_spin = QSpinBox()
        h_col_current_spin.setRange(0, 2147483647)
        h_col_current_spin.setValue(800)
        param_layout.addWidget(h_col_current_spin, 7, 1)
        param_widgets['homing_collision_current'] = h_col_current_spin
        row7_widgets.append(h_col_current_spin)
        
        lbl_h_col_time = QLabel('碰撞检测时间 (ms)：')
        lbl_h_col_time.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_h_col_time, 7, 2)
        row7_widgets.append(lbl_h_col_time)
        
        h_col_time_spin = QSpinBox()
        h_col_time_spin.setRange(0, 2147483647)
        h_col_time_spin.setValue(60)
        param_layout.addWidget(h_col_time_spin, 7, 3)
        param_widgets['homing_collision_time'] = h_col_time_spin
        row7_widgets.append(h_col_time_spin)
        param_rows.append(row7_widgets)
        
        # 原点修改参数：自动回零（第8行，需要扩展网格）
        row8_widgets = []
        lbl_auto_homing = QLabel('上电自动回零：')
        lbl_auto_homing.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_auto_homing, 8, 0)
        row8_widgets.append(lbl_auto_homing)
        
        auto_homing_check = QCheckBox('启用')
        auto_homing_check.setChecked(False)
        param_layout.addWidget(auto_homing_check, 8, 1)
        param_widgets['auto_homing'] = auto_homing_check
        row8_widgets.append(auto_homing_check)
        param_rows.append(row8_widgets)
        
        # 诊断读取选择（第9行）
        row9_widgets = []
        lbl_diag = QLabel('诊断读取项：')
        lbl_diag.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        param_layout.addWidget(lbl_diag, 9, 0)
        row9_widgets.append(lbl_diag)
        
        diag_combo = QComboBox()
        diag_combo.addItems([
            '固件/硬件版本 (0x1F)',
            '相电阻/相电感 (0x20)',
            '位置环PID (0x21)',
            '总线电压 (0x24)',
            '相电流 (0x27)',
            '电机实时转速 (0x35)',
            '电机实时位置 (0x36)',
            '位置误差 (0x37)',
            '电机状态标志位 (0x3A)',
            '驱动配置 (0x42 0x6C)',
            '系统状态 (0x43 0x7A)'
        ])
        param_layout.addWidget(diag_combo, 9, 1, 1, 3)  # 跨3列
        param_widgets['diagnostic'] = diag_combo
        row9_widgets.append(diag_combo)
        param_rows.append(row9_widgets)
        
        # 存储行信息，用于批量显示/隐藏
        param_widgets['_rows'] = param_rows
        
        # 初始隐藏所有参数控件
        self._hide_all_params(param_rows)
        
        layout.addWidget(param_group)
        
        # 多机同步和发送按钮
        bottom_layout = QHBoxLayout()
        multi_sync_check = QCheckBox('启用多机同步')
        bottom_layout.addWidget(multi_sync_check)
        param_widgets['multi_sync'] = multi_sync_check
        
        send_btn = QPushButton('发送指令')
        send_btn.clicked.connect(lambda: self._on_send(address, cmd_combo, param_widgets))
        bottom_layout.addWidget(send_btn)
        layout.addLayout(bottom_layout)
        
        layout.addStretch()
        
        # 指令选择变化时更新参数显示
        cmd_combo.currentTextChanged.connect(
            lambda text: self._update_param_visibility(param_widgets, text)
        )
        
        # 初始更新一次
        self._update_param_visibility(param_widgets, cmd_combo.currentText())
        
        return tab
    
    def _hide_all_params(self, param_rows):
        """隐藏所有参数控件"""
        for row_widgets in param_rows:
            for widget in row_widgets:
                widget.setVisible(False)
    
    def _update_param_visibility(self, widgets, cmd_text):
        """根据指令类型更新参数控件的可见性（参照MATLAB版本）"""
        param_rows = widgets.get('_rows', [])
        
        # 先隐藏所有参数
        self._hide_all_params(param_rows)
        
        # 根据指令类型显示相应参数
        if cmd_text in ['使能电机', '禁用电机', '停止电机', '同步触发']:
            # 无参数，保持隐藏状态
            pass
            
        elif cmd_text == '设置速度':
            # 显示：目标速度、方向、加速度档位（第0行和第1行）
            for widget in param_rows[0]:  # 速度、方向
                widget.setVisible(True)
            for widget in param_rows[1]:  # 加速度
                widget.setVisible(True)
                
        elif cmd_text == '位置控制':
            # 显示：目标脉冲数、方向、目标速度、加速度档位、位置模式
            for widget in param_rows[0]:  # 速度、方向
                widget.setVisible(True)
            for widget in param_rows[1]:  # 加速度
                widget.setVisible(True)
            for widget in param_rows[2]:  # 脉冲数、位置模式
                widget.setVisible(True)
                
        elif cmd_text == '角度控制':
            # 显示：目标角度、方向、目标速度、加速度档位、位置模式
            # 第0行：速度、方向（全部显示）
            for widget in param_rows[0]:
                widget.setVisible(True)
            # 第1行：加速度（全部显示）
            for widget in param_rows[1]:
                widget.setVisible(True)
            # 第2行：只显示位置模式（隐藏脉冲数相关）
            for i, widget in enumerate(param_rows[2]):
                if i >= 2:  # 位置模式标签和下拉框（索引2和3）
                    widget.setVisible(True)
                else:  # 脉冲数标签和输入框（索引0和1）
                    widget.setVisible(False)
            # 第3行：角度（全部显示）
            for widget in param_rows[3]:
                widget.setVisible(True)
                
        elif cmd_text == '原点设置零点':
            # 显示：保存到Flash（第4行，只显示前两个控件）
            param_rows[4][0].setVisible(True)  # 标签
            param_rows[4][1].setVisible(True)  # 复选框
                
        elif cmd_text == '原点触发回零':
            # 显示：回零模式、目标速度、加速度档位
            # 第4行：只显示回零模式（隐藏保存到Flash）
            param_rows[4][2].setVisible(True)  # 回零模式标签
            param_rows[4][3].setVisible(True)  # 回零模式下拉框
            # 第0行：只显示速度（隐藏方向）
            param_rows[0][0].setVisible(True)  # 速度标签
            param_rows[0][1].setVisible(True)  # 速度输入框
            # 第1行：加速度（全部显示）
            for widget in param_rows[1]:
                widget.setVisible(True)
                    
        elif cmd_text == '原点强制中断':
            # 无参数
            pass
            
        elif cmd_text == '原点读取参数':
            # 无参数
            pass
            
        elif cmd_text == '原点修改参数':
            # 显示所有原点相关参数
            for widget in param_rows[4]:  # 保存到Flash、回零模式
                widget.setVisible(True)
            for widget in param_rows[5]:  # 回零方向、回零速度
                widget.setVisible(True)
            for widget in param_rows[6]:  # 回零超时、碰撞检测转速
                widget.setVisible(True)
            for widget in param_rows[7]:  # 碰撞检测电流、碰撞检测时间
                widget.setVisible(True)
            for widget in param_rows[8]:  # 自动回零
                widget.setVisible(True)
                
        elif cmd_text == '原点读取状态':
            # 无参数
            pass
            
        elif cmd_text == '诊断读取':
            # 显示诊断读取项（第9行）
            for widget in param_rows[9]:
                widget.setVisible(True)
                
        elif cmd_text in ['读取固件/硬件版本 (0x1F)', '读取相电阻/相电感 (0x20)', 
                          '读取位置环PID参数 (0x21)', '读取总线电压 (0x24)', 
                          '读取相电流 (0x27)', '读取电机实时转速 (0x35)',
                          '读取电机实时位置 (0x36)', '读取电机位置误差 (0x37)', 
                          '读取电机状态标志位 (0x3A)', '读取驱动配置参数 (0x42 0x6C)', 
                          '读取系统状态参数 (0x43 0x7A)']:
            # 无参数
            pass
    
    def _on_connect(self):
        """连接CAN设备"""
        try:
            self.append_log('--- 尝试连接 CAN 设备 ---')
            self.append_log(f'端口: {self.com_port}, 波特率: {self.bitrate}, 超时: {self.timeout}s')
            
            self.can_base = MotorCANBase(self.com_port, self.bitrate, self.timeout)
            ok = self.can_base.connect()
            
            if ok:
                self.is_connected = True
                self.status_label.setText('状态：已连接')
                self.status_label.setStyleSheet("color: green; font-weight: bold;")
                self.append_log('✓ CAN设备连接成功')
                self.btn_connect.setEnabled(False)
                self.btn_disconnect.setEnabled(True)
                
                # 同步CAN连接到机械臂控制界面
                if self.parent_window and hasattr(self.parent_window, 'arm_widget'):
                    if self.parent_window.arm_widget:
                        self.parent_window.arm_widget.update_can_connection(self.can_base, True)
            else:
                self.is_connected = False
                self.status_label.setText('状态：未连接')
                self.status_label.setStyleSheet("color: red; font-weight: bold;")
                self.append_log('✗ CAN设备连接失败')
        except Exception as e:
            self.is_connected = False
            self.status_label.setText('状态：未连接')
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
            self.append_log(f'✗ 连接过程中发生错误: {str(e)}')
    
    def _on_disconnect(self):
        """断开CAN设备"""
        try:
            if self.can_base is not None:
                self.can_base.disconnect()
                import time
                time.sleep(0.2)  # 等待底层关闭序列完成
            
            self.is_connected = False
            self.status_label.setText('状态：未连接')
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
            self.append_log('✓ CAN设备已断开')
            self.btn_connect.setEnabled(True)
            self.btn_disconnect.setEnabled(False)
            
            # 同步CAN断开到机械臂控制界面
            if self.parent_window and hasattr(self.parent_window, 'arm_widget'):
                if self.parent_window.arm_widget:
                    self.parent_window.arm_widget.update_can_connection(None, False)
        except Exception as e:
            self.append_log(f'✗ 断开连接时出现错误: {str(e)}')
    
    def _on_send(self, address, cmd_combo, param_widgets):
        """发送指令"""
        if not self.is_connected:
            self.append_log('✗ CAN设备未连接，请先点击"连接CAN设备"')
            return
        
        try:
            cmd_text = cmd_combo.currentText()
            multi_sync = param_widgets['multi_sync'].isChecked()
            addr = address
            
            self.append_log(f'→ 发送：{cmd_text} (地址={addr}, 多机同步={multi_sync})')
            
            # 根据指令类型发送
            if cmd_text == '使能电机':
                c = EnableControlCommand(addr)
                c.set_enable(True, multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_enable_response(resp)
                
            elif cmd_text == '禁用电机':
                c = EnableControlCommand(addr)
                c.set_enable(False, multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_enable_response(resp)
                
            elif cmd_text == '设置速度':
                speed = param_widgets['speed'].value()
                direction = int(param_widgets['direction'].currentText())
                accel = param_widgets['acceleration'].value()
                c = SpeedControlCommand(addr)
                c.set_direction(direction)
                c.set_speed(speed)
                c.set_acceleration(accel)
                c.set_multi_sync(multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_speed_response(resp)
                
            elif cmd_text == '位置控制':
                # 脉冲数从 QLineEdit 读取，支持大整数（uint32 范围）
                pulse_text = param_widgets['pulse'].text().strip()
                if not pulse_text:
                    self.append_log('✗ 请输入目标脉冲数')
                    return
                try:
                    pulse = int(pulse_text)
                    if pulse < 0:
                        self.append_log('✗ 脉冲数必须为非负整数')
                        return
                    if pulse > 4294967295:  # uint32 最大值
                        self.append_log('✗ 脉冲数超出范围（最大 4294967295）')
                        return
                except ValueError:
                    self.append_log('✗ 脉冲数格式错误，请输入整数')
                    return
                except OverflowError:
                    self.append_log('✗ 脉冲数值过大，请输入有效范围内的整数')
                    return
                
                direction = int(param_widgets['direction'].currentText())
                speed = param_widgets['speed'].value()
                accel = param_widgets['acceleration'].value()
                pos_mode = int(param_widgets['position_mode'].currentText())
                c = PositionControlCommand(addr)
                c.set_pulse_count(pulse)
                c.set_direction(direction)
                c.set_speed(speed)
                c.set_acceleration(accel)
                c.set_position_mode(pos_mode)
                c.set_multi_sync(multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_position_response(resp)
                
            elif cmd_text == '角度控制':
                angle = param_widgets['angle'].value()
                direction = int(param_widgets['direction'].currentText())
                speed = param_widgets['speed'].value()
                accel = param_widgets['acceleration'].value()
                pos_mode = int(param_widgets['position_mode'].currentText())
                c = PositionControlCommand(addr)
                c.set_angle_degrees(angle)
                c.set_direction(direction)
                c.set_speed(speed)
                c.set_acceleration(accel)
                c.set_position_mode(pos_mode)
                c.set_multi_sync(multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_position_response(resp)
                
            elif cmd_text == '停止电机':
                c = StopControlCommand(addr)
                c.set_multi_sync(multi_sync)
                resp = c.execute(self.can_base, self.timeout)
                self._dump_stop_response(resp)
                
            elif cmd_text == '同步触发':
                c = SyncControlCommand()
                resp = c.execute(self.can_base, self.timeout)
                self._dump_sync_response(resp)
                
            elif cmd_text == '原点设置零点':
                save_flash = param_widgets['save_flash'].isChecked()
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点设置零点 (地址={addr}, 保存到Flash={save_flash})')
                resp = h.execute_set_zero_position(self.can_base, save_flash, self.timeout)
                self._dump_homing_simple(resp, '设置零点')
                
            elif cmd_text == '原点触发回零':
                homing_mode = int(param_widgets['homing_mode'].currentText())
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点触发回零 (地址={addr}, 模式={homing_mode}, 多机同步={multi_sync})')
                resp = h.execute_trigger_homing(self.can_base, homing_mode, multi_sync, self.timeout)
                self._dump_homing_simple(resp, '触发回零')
                
            elif cmd_text == '原点强制中断':
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点强制中断 (地址={addr})')
                resp = h.execute_force_stop_homing(self.can_base, self.timeout)
                self._dump_homing_simple(resp, '强制中断')
                
            elif cmd_text == '原点读取参数':
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点读取参数 (地址={addr})')
                resp = h.execute_read_homing_params(self.can_base, self.timeout)
                self._dump_homing_params(resp, addr)
                
            elif cmd_text == '原点修改参数':
                # 创建参数字典（Python原生字典）
                params = {
                    'homing_mode': int(param_widgets['homing_mode'].currentText()),
                    'direction': int(param_widgets['homing_direction'].currentText()),
                    'speed_rpm': param_widgets['homing_speed'].value(),
                    'timeout_ms': param_widgets['homing_timeout'].value(),
                    'collision_speed_rpm': param_widgets['homing_collision_speed'].value(),
                    'collision_current_ma': param_widgets['homing_collision_current'].value(),
                    'collision_time_ms': param_widgets['homing_collision_time'].value(),
                    'auto_homing_enable': param_widgets['auto_homing'].isChecked()
                }
                save_flash = param_widgets['save_flash'].isChecked()
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点修改参数 (地址={addr}, 保存到Flash={save_flash})')
                resp = h.execute_modify_homing_params(self.can_base, params, save_flash, self.timeout)
                self._dump_homing_simple(resp, '修改参数')
                
            elif cmd_text == '原点读取状态':
                h = HomingControlCommand(addr)
                self.append_log(f'→ 发送：原点读取状态 (地址={addr})')
                resp = h.execute_read_homing_status(self.can_base, self.timeout)
                self._dump_homing_status(resp, addr)
                
            elif cmd_text == '诊断读取':
                diag_sel = param_widgets['diagnostic'].currentText()
                exec_code = self._map_diag_selection(diag_sel)
                d = DiagnosticCommand(addr)
                self.append_log(f'→ 发送：诊断读取 (地址={addr}, 项={diag_sel}, 码=0x{exec_code:02X})')
                resp = self._execute_diagnostic(d, exec_code)
                self._dump_diagnostic(resp, exec_code, addr)
                
            elif cmd_text in ['读取固件/硬件版本 (0x1F)', '读取相电阻/相电感 (0x20)', 
                             '读取位置环PID参数 (0x21)', '读取总线电压 (0x24)', 
                             '读取相电流 (0x27)', '读取电机实时转速 (0x35)',
                             '读取电机实时位置 (0x36)', '读取电机位置误差 (0x37)', 
                             '读取电机状态标志位 (0x3A)', '读取驱动配置参数 (0x42 0x6C)', 
                             '读取系统状态参数 (0x43 0x7A)']:
                # 直接诊断读取
                exec_code = int(cmd_text.split('(')[1].split(')')[0].replace('0x', ''), 16)
                d = DiagnosticCommand(addr)
                self.append_log(f'→ 发送：{cmd_text} (地址={addr})')
                resp = self._execute_diagnostic(d, exec_code)
                self._dump_diagnostic(resp, exec_code, addr)
                
            else:
                self.append_log(f'✗ 指令类型 "{cmd_text}" 尚未实现')
                
        except Exception as e:
            self.append_log(f'✗ 指令发送/解析失败: {str(e)}')
            import traceback
            self.append_log(traceback.format_exc())
    
    def _dump_enable_response(self, resp_data):
        """解析使能响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = EnableResponse(resp_data)
            ok = r.is_success()
            msg = r.get_status_meaning()
            self.append_log(f'← 使能/禁用响应：{msg}')
            if ok:
                self.append_log('✓ 操作成功')
            else:
                self.append_log('✗ 操作失败')
        except Exception as e:
            self.append_log(f'(原始) 响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_speed_response(self, resp_data):
        """解析速度响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = SpeedResponse(resp_data)
            ok = r.is_success()
            msg = r.get_status_meaning()
            self.append_log(f'← 速度响应：{msg}')
            if ok:
                self.append_log('✓ 速度设置成功')
            else:
                self.append_log('✗ 速度设置失败')
        except Exception as e:
            self.append_log(f'(原始) 响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_position_response(self, resp_data):
        """解析位置响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = PositionResponse(resp_data)
            ok = r.is_success()
            msg = r.get_status_meaning()
            self.append_log(f'← 位置响应：{msg}')
            if ok:
                self.append_log('✓ 位置控制命令发送成功')
            else:
                self.append_log('✗ 位置控制失败')
        except Exception as e:
            self.append_log(f'(原始) 响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_stop_response(self, resp_data):
        """解析停止响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = StopResponse(resp_data)
            ok = r.is_success()
            msg = r.get_status_meaning()
            self.append_log(f'← 停止响应：{msg}')
            if ok:
                self.append_log('✓ 停止成功')
            else:
                self.append_log('✗ 停止失败')
        except Exception as e:
            self.append_log(f'(原始) 响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_sync_response(self, resp_data):
        """解析同步响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = SyncResponse(resp_data)
            desc = r.get_status_description()
            self.append_log(f'← 同步响应：{desc}')
        except Exception as e:
            self.append_log(f'(原始) 响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_homing_simple(self, resp_data, action_name):
        """解析原点响应（简单状态类：设置/触发/强制/修改）"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = HomingResponse(resp_data)
            # 根据动作名选择解析方法
            if action_name == '设置零点':
                res = r.parse_set_zero_position_response()
            elif action_name == '触发回零':
                res = r.parse_trigger_homing_response()
            elif action_name == '强制中断':
                res = r.parse_force_stop_homing_response()
            elif action_name == '修改参数':
                res = r.parse_modify_homing_params_response()
            else:
                res = {}
            
            # 检查成功标志
            ok = res.get('success', False) if isinstance(res, dict) else False
            self.append_log(f'← 原点响应（{action_name}）：{"成功" if ok else "失败"}')
        except Exception as e:
            self.append_log(f'(原始) 原点响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_homing_params(self, resp_data, addr):
        """解析原点参数读取"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = HomingResponse(resp_data, addr)
            res = r.parse_read_homing_params_response()
            text = r.format_homing_params(res)
            self.append_log('← 原点参数读取成功：')
            self.append_log(str(text))
        except Exception as e:
            self.append_log(f'(原始) 原点参数响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _dump_homing_status(self, resp_data, addr):
        """解析原点状态读取"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            r = HomingResponse(resp_data, addr)
            res = r.parse_read_homing_status_response()
            text = r.format_homing_status(res)
            self.append_log('← 原点状态读取成功：')
            self.append_log(str(text))
        except Exception as e:
            self.append_log(f'(原始) 原点状态响应数据：{resp_data}')
            self.append_log(f'解析错误: {str(e)}')
    
    def _map_diag_selection(self, sel):
        """诊断选择映射：返回命令码"""
        mapping = {
            '固件/硬件版本 (0x1F)': 0x1F,
            '相电阻/相电感 (0x20)': 0x20,
            '位置环PID (0x21)': 0x21,
            '总线电压 (0x24)': 0x24,
            '相电流 (0x27)': 0x27,
            '电机实时转速 (0x35)': 0x35,
            '电机实时位置 (0x36)': 0x36,
            '位置误差 (0x37)': 0x37,
            '电机状态标志位 (0x3A)': 0x3A,
            '驱动配置 (0x42 0x6C)': 0x42,
            '系统状态 (0x43 0x7A)': 0x43
        }
        return mapping.get(sel, 0)
    
    def _execute_diagnostic(self, d, code):
        """执行诊断读取"""
        try:
            if code == 0x1F:
                return d.execute_read_fw_hw_version(self.can_base, self.timeout)
            elif code == 0x20:
                return d.execute_read_phase_res_ind(self.can_base, self.timeout)
            elif code == 0x21:
                return d.execute_read_position_pid(self.can_base, self.timeout)
            elif code == 0x24:
                return d.execute_read_bus_voltage(self.can_base, self.timeout)
            elif code == 0x27:
                return d.execute_read_phase_current(self.can_base, self.timeout)
            elif code == 0x35:
                return d.execute_read_motor_speed(self.can_base, self.timeout)
            elif code == 0x36:
                return d.execute_read_motor_position(self.can_base, self.timeout)
            elif code == 0x37:
                return d.execute_read_position_error(self.can_base, self.timeout)
            elif code == 0x3A:
                return d.execute_read_motor_state_flags(self.can_base, self.timeout)
            elif code == 0x42:
                return d.execute_read_driver_config(self.can_base, self.timeout)
            elif code == 0x43:
                return d.execute_read_system_status(self.can_base, self.timeout)
            else:
                return None
        except Exception as e:
            self.append_log(f'执行诊断读取失败: {str(e)}')
            return None
    
    def _dump_diagnostic(self, resp_data, code, addr):
        """解析诊断响应"""
        if resp_data is None:
            self.append_log('✗ 未收到响应数据')
            return
        try:
            dr = DiagnosticResponse(resp_data, addr)
            # 按命令码选择解析方法
            if code == 0x1F:
                parsed = dr.parse_fw_hw_version()
            elif code == 0x20:
                parsed = dr.parse_phase_res_ind()
            elif code == 0x21:
                parsed = dr.parse_position_pid()
            elif code == 0x24:
                parsed = dr.parse_bus_voltage()
            elif code == 0x27:
                parsed = dr.parse_phase_current()
            elif code == 0x35:
                parsed = dr.parse_motor_speed()
            elif code == 0x36:
                parsed = dr.parse_motor_position()
            elif code == 0x37:
                parsed = dr.parse_position_error()
            elif code == 0x3A:
                parsed = dr.parse_motor_state_flags()
            elif code == 0x42:
                parsed = dr.parse_driver_config()
            elif code == 0x43:
                parsed = dr.parse_system_status()
            else:
                parsed = {}
            
            # 打印解析结果
            self.append_log('--- 响应解析 ---')
            if isinstance(parsed, dict):
                for key, value in parsed.items():
                    if value is not None:
                        self.append_log(f'{key}: {value}')
            else:
                self.append_log(f'诊断内容：{parsed}')
            
            self.append_log('✓ 诊断读取完成')
        except Exception as e:
            self.append_log(f'✗ 诊断解析失败: {str(e)}')
            self.append_log(f'(原始) 诊断响应数据：{resp_data}')
    
    def append_log(self, text):
        """追加日志"""
        self.log_text.append(text)
        # 自动滚动到底部
        cursor = self.log_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.log_text.setTextCursor(cursor)


if __name__ == '__main__':
    from PyQt5.QtWidgets import QApplication
    import sys
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    window = CommandControlWindow()
    window.show()
    
    sys.exit(app.exec_())

