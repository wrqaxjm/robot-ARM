# Python GUI 模块
# 六轴机械臂上位机软件

__version__ = '1.0.0'

