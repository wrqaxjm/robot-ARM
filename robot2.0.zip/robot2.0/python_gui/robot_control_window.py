"""
机械臂控制界面（PyQt5 + urdfpy + pyrender）
功能说明：
- 上方：两个3D显示区域（使用pyrender渲染真实STL模型）
  - 左侧：实时模型（从CAN获取实际关节角度）
  - 右侧：理论模型（根据控制面板输入显示）
- 下方：控制面板，支持关节模式和笛卡尔模式切换
"""

import os
import sys
import numpy as np
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QSlider, QGroupBox, QGridLayout,
                             QMessageBox, QDoubleSpinBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QImage, QPixmap

# URDF和渲染库
try:
    # NumPy兼容性补丁（urdfpy使用了废弃的np.float）
    import numpy as np
    if not hasattr(np, 'float'):
        np.float = np.float64
    if not hasattr(np, 'int'):
        np.int = np.int_
    if not hasattr(np, 'bool'):
        np.bool = np.bool_
    if not hasattr(np, 'complex'):
        np.complex = np.complex128
    
    import urdfpy
    import pyrender
    import trimesh
    URDF_AVAILABLE = True
except ImportError as e:
    URDF_AVAILABLE = False
    print(f"警告: URDF显示库未安装 - {e}")

# 逆运动学库
try:
    from spatialmath import SE3
    import roboticstoolbox as rtb
    RTB_AVAILABLE = True
except ImportError:
    RTB_AVAILABLE = False


class URDFViewer(QWidget):
    """URDF模型3D显示器"""
    
    def __init__(self, parent=None, title="机器人模型"):
        super().__init__(parent)
        self.title = title
        self.robot = None
        self.scene = None
        self.viewer = None
        self.mesh_nodes = []
        
        # 当前关节角度
        self.joint_angles = np.zeros(6)
        
        # UI组件
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(400, 300)
        self.image_label.setStyleSheet("background-color: #2b2b2b; border: 1px solid #555;")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title_label = QLabel(title)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setFont(QFont('Arial', 10, QFont.Bold))
        layout.addWidget(title_label)
        layout.addWidget(self.image_label)
        
        # 渲染定时器
        self.render_timer = QTimer()
        self.render_timer.timeout.connect(self.render_frame)
    
    def load_urdf(self, urdf_path):
        """加载URDF模型"""
        if not URDF_AVAILABLE:
            return False
        
        try:
            # 预处理URDF文件，替换package://路径
            urdf_path = self._preprocess_urdf(urdf_path)
            
            # 加载URDF
            self.robot = urdfpy.URDF.load(urdf_path)
            print(f"{self.title}: 成功加载URDF - {self.robot.name}")
            print(f"  可活动关节数: {len([j for j in self.robot.joints if j.joint_type in ['revolute', 'prismatic']])}")
            
            # 创建渲染场景
            self._create_scene()
            
            # 启动渲染
            self.render_timer.start(33)  # 30 FPS
            return True
            
        except Exception as e:
            print(f"{self.title}: 加载URDF失败 - {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _preprocess_urdf(self, urdf_path):
        """预处理URDF文件，替换package://路径为实际路径"""
        import tempfile
        import re
        
        try:
            # 读取原始URDF文件
            with open(urdf_path, 'r', encoding='utf-8') as f:
                urdf_content = f.read()
            
            # 获取URDF文件所在目录的父目录
            urdf_dir = os.path.dirname(os.path.abspath(urdf_path))
            package_dir = os.path.dirname(urdf_dir)  # 上一级目录
            
            # 替换package://路径为绝对路径
            # 格式: package://六轴机械臂/meshes/xxx.STL
            # 替换为: E:/traeproject/robot2.0/python_viewer/六轴机械臂/meshes/xxx.STL
            def replace_package_path(match):
                # 提取package名称后的路径部分
                path_after_package = match.group(1)
                # 构建绝对路径（使用正斜杠）
                absolute_path = os.path.join(package_dir, path_after_package).replace('\\', '/')
                return f'filename="{absolute_path}"'
            
            # 匹配 filename="package://包名/路径"
            pattern = r'filename="package://[^/]+/([^"]+)"'
            urdf_content = re.sub(pattern, replace_package_path, urdf_content)
            
            # 创建临时文件
            temp_fd, temp_path = tempfile.mkstemp(suffix='.urdf', text=True)
            with os.fdopen(temp_fd, 'w', encoding='utf-8') as f:
                f.write(urdf_content)
            
            print(f"{self.title}: URDF预处理完成，临时文件: {temp_path}")
            print(f"{self.title}: Package目录: {package_dir}")
            return temp_path
            
        except Exception as e:
            print(f"{self.title}: URDF预处理失败 - {e}")
            import traceback
            traceback.print_exc()
            return urdf_path  # 返回原路径
    
    def _create_scene(self):
        """创建pyrender场景"""
        try:
            # 创建场景
            self.scene = pyrender.Scene(ambient_light=[0.3, 0.3, 0.3])
            
            # 添加光源
            light = pyrender.DirectionalLight(color=[1.0, 1.0, 1.0], intensity=3.0)
            self.scene.add(light, pose=np.eye(4))
            
            # 添加相机
            camera = pyrender.PerspectiveCamera(yfov=np.pi / 3.0)
            camera_pose = np.array([
                [0.7071, -0.4082, 0.5774, 0.8],
                [0.7071, 0.4082, -0.5774, -0.8],
                [0, 0.8165, 0.5774, 0.8],
                [0, 0, 0, 1]
            ])
            self.scene.add(camera, pose=camera_pose)
            
            # 添加地平面
            ground_mesh = trimesh.creation.box([2.0, 2.0, 0.01])
            ground_mesh.visual.vertex_colors = [200, 200, 200, 100]
            ground = pyrender.Mesh.from_trimesh(ground_mesh)
            ground_pose = np.eye(4)
            ground_pose[2, 3] = -0.005
            self.scene.add(ground, pose=ground_pose)
            
            # 添加机器人模型
            self._add_robot_to_scene()
            
        except Exception as e:
            print(f"创建场景失败: {e}")
            import traceback
            traceback.print_exc()
    
    def _add_robot_to_scene(self):
        """将机器人添加到场景"""
        try:
            # 清除旧的网格节点
            for node in self.mesh_nodes:
                self.scene.remove_node(node)
            self.mesh_nodes = []
            
            # 创建基座旋转矩阵：绕X轴旋转-90度
            import numpy as np
            angle = -np.pi / 2  # -90度
            base_rotation = np.array([
                [1, 0, 0, 0],
                [0, np.cos(angle), -np.sin(angle), 0],
                [0, np.sin(angle), np.cos(angle), 0],
                [0, 0, 0, 1]
            ])
            
            # 获取当前配置的FK结果
            cfg = {}
            joint_idx = 0
            for joint in self.robot.joints:
                if joint.joint_type in ['revolute', 'prismatic']:
                    if joint_idx < len(self.joint_angles):
                        cfg[joint.name] = self.joint_angles[joint_idx]
                        joint_idx += 1
            
            # 获取所有连杆的变换矩阵
            fk = self.robot.link_fk(cfg=cfg)
            
            # 添加每个连杆的网格
            for link in self.robot.links:
                if link.visuals:
                    # 应用基座旋转
                    link_pose = base_rotation @ fk[link]
                    for visual in link.visuals:
                        if visual.geometry and visual.geometry.mesh:
                            try:
                                # 从urdfpy的Mesh对象获取trimesh
                                urdf_mesh = visual.geometry.mesh
                                
                                # urdfpy的mesh可能是Trimesh对象列表或单个Trimesh
                                if hasattr(urdf_mesh, 'meshes'):
                                    # 多个mesh
                                    trimesh_list = urdf_mesh.meshes
                                elif isinstance(urdf_mesh, list):
                                    trimesh_list = urdf_mesh
                                else:
                                    # 单个mesh
                                    trimesh_list = [urdf_mesh]
                                
                                # 应用visual的origin变换
                                mesh_pose = link_pose @ visual.origin
                                
                                # 添加所有mesh
                                for tm in trimesh_list:
                                    if tm is not None:
                                        # 创建pyrender mesh
                                        pr_mesh = pyrender.Mesh.from_trimesh(tm, smooth=True)
                                        node = self.scene.add(pr_mesh, pose=mesh_pose)
                                        self.mesh_nodes.append(node)
                            except Exception as e:
                                print(f"添加网格失败: {e}")
        
        except Exception as e:
            print(f"添加机器人到场景失败: {e}")
            import traceback
            traceback.print_exc()
    
    def set_joint_angles(self, angles_deg):
        """设置关节角度（度）"""
        try:
            self.joint_angles = np.radians(angles_deg[:6])
            if self.scene:
                self._add_robot_to_scene()
        except Exception as e:
            print(f"设置关节角度失败: {e}")
    
    def render_frame(self):
        """渲染当前帧"""
        if not self.scene:
            return
        
        try:
            # 使用离屏渲染
            r = pyrender.OffscreenRenderer(640, 480)
            color, depth = r.render(self.scene)
            r.delete()
            
            # 转换为QImage
            height, width, channels = color.shape
            bytes_per_line = channels * width
            # 将numpy数组转换为bytes（确保数据连续）
            color_bytes = np.ascontiguousarray(color).tobytes()
            qimage = QImage(color_bytes, width, height, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qimage)
            
            # 缩放显示
            scaled_pixmap = pixmap.scaled(
                self.image_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.image_label.setPixmap(scaled_pixmap)
            
        except Exception as e:
            print(f"{self.title}: 渲染失败 - {e}")


class RobotControlWindow(QWidget):
    """机械臂控制窗口"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        
        # 当前关节角度（度）
        self.current_joint_angles_deg = [0.0] * 6  # 理论模型
        self.real_joint_angles_deg = [0.0] * 6     # 实时模型
        
        # 控制模式
        self.control_mode = 'joint'
        
        # CAN连接状态
        self.is_connected = False
        self.can_base = None
        
        # 机器人模型（用于逆运动学）
        self.robot_model = None
        self.urdf_path = None
        
        # 定时器
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self._update_real_model)
        
        # 检查依赖
        if not URDF_AVAILABLE:
            QMessageBox.critical(self, '错误', 
                               'URDF显示库未安装\n'
                               '请运行: pip install urdfpy pyrender trimesh')
            return
        
        # 初始化UI
        self._init_ui()
        
        # 加载机器人模型
        self._load_robot_model()
    
    def _init_ui(self):
        """初始化用户界面"""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        
        # ========== 顶部：3D显示区域 ==========
        display_group = QGroupBox('3D 显示')
        display_layout = QHBoxLayout(display_group)
        
        # 左侧：实时模型
        self.real_viewer = URDFViewer(title="实时模型（从CAN获取）")
        
        # 右侧：理论模型
        self.theory_viewer = URDFViewer(title="理论模型（控制面板输入）")
        
        display_layout.addWidget(self.real_viewer)
        display_layout.addWidget(self.theory_viewer)
        
        main_layout.addWidget(display_group, stretch=2)
        
        # ========== 底部：控制面板 ==========
        control_group = QGroupBox('控制面板')
        control_main_layout = QVBoxLayout(control_group)
        
        # 模式切换按钮
        mode_layout = QHBoxLayout()
        self.btn_joint_mode = QPushButton('关节模式')
        self.btn_cartesian_mode = QPushButton('笛卡尔模式')
        self.btn_joint_mode.setCheckable(True)
        self.btn_cartesian_mode.setCheckable(True)
        self.btn_joint_mode.setChecked(True)
        self.btn_joint_mode.clicked.connect(lambda: self._switch_mode('joint'))
        self.btn_cartesian_mode.clicked.connect(lambda: self._switch_mode('cartesian'))
        
        button_style = """
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:checked {
                background-color: #0D47A1;
                font-weight: bold;
            }
        """
        self.btn_joint_mode.setStyleSheet(button_style)
        self.btn_cartesian_mode.setStyleSheet(button_style)
        
        mode_layout.addWidget(QLabel('控制模式：'))
        mode_layout.addWidget(self.btn_joint_mode)
        mode_layout.addWidget(self.btn_cartesian_mode)
        mode_layout.addStretch()
        
        control_main_layout.addLayout(mode_layout)
        
        # 控制面板容器
        self.control_stack = QWidget()
        self.control_stack_layout = QVBoxLayout(self.control_stack)
        self.control_stack_layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建关节控制面板
        self.joint_panel = self._create_joint_panel()
        self.control_stack_layout.addWidget(self.joint_panel)
        
        # 创建笛卡尔控制面板
        self.cartesian_panel = self._create_cartesian_panel()
        self.cartesian_panel.setVisible(False)
        self.control_stack_layout.addWidget(self.cartesian_panel)
        
        control_main_layout.addWidget(self.control_stack)
        
        main_layout.addWidget(control_group, stretch=1)
    
    def _create_joint_panel(self):
        """创建关节控制面板"""
        panel = QWidget()
        layout = QGridLayout(panel)
        layout.setSpacing(10)
        
        self.joint_sliders = []
        self.joint_spin_boxes = []
        
        for i in range(6):
            # 标签
            label = QLabel(f'关节 {i+1}:')
            layout.addWidget(label, i, 0)
            
            # 滑条
            slider = QSlider(Qt.Horizontal)
            slider.setMinimum(-180)
            slider.setMaximum(180)
            slider.setValue(0)
            slider.setTickPosition(QSlider.TicksBelow)
            slider.setTickInterval(30)
            slider.valueChanged.connect(self._on_joint_slider_changed)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            
            # 数值输入框
            spin = QDoubleSpinBox()
            spin.setMinimum(-180)
            spin.setMaximum(180)
            spin.setValue(0)
            spin.setSuffix(' °')
            spin.setDecimals(1)
            spin.valueChanged.connect(self._on_joint_spin_changed)
            layout.addWidget(spin, i, 2)
            self.joint_spin_boxes.append(spin)
        
        # 发送按钮
        send_btn = QPushButton('发送到电机')
        send_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        send_btn.clicked.connect(self._send_joint_to_motors)
        layout.addWidget(send_btn, 6, 0, 1, 3)
        
        return panel
    
    def _create_cartesian_panel(self):
        """创建笛卡尔控制面板"""
        panel = QWidget()
        layout = QGridLayout(panel)
        layout.setSpacing(10)
        
        # 位置输入
        layout.addWidget(QLabel('位置 (m):'), 0, 0)
        
        self.x_input = QDoubleSpinBox()
        self.x_input.setRange(-1.0, 1.0)
        self.x_input.setValue(0.3)
        self.x_input.setDecimals(3)
        self.x_input.setPrefix('X: ')
        layout.addWidget(self.x_input, 0, 1)
        
        self.y_input = QDoubleSpinBox()
        self.y_input.setRange(-1.0, 1.0)
        self.y_input.setValue(0.0)
        self.y_input.setDecimals(3)
        self.y_input.setPrefix('Y: ')
        layout.addWidget(self.y_input, 0, 2)
        
        self.z_input = QDoubleSpinBox()
        self.z_input.setRange(-1.0, 1.0)
        self.z_input.setValue(0.5)
        self.z_input.setDecimals(3)
        self.z_input.setPrefix('Z: ')
        layout.addWidget(self.z_input, 0, 3)
        
        # 姿态输入
        layout.addWidget(QLabel('姿态 (°):'), 1, 0)
        
        self.roll_input = QDoubleSpinBox()
        self.roll_input.setRange(-180, 180)
        self.roll_input.setValue(0)
        self.roll_input.setPrefix('Roll: ')
        layout.addWidget(self.roll_input, 1, 1)
        
        self.pitch_input = QDoubleSpinBox()
        self.pitch_input.setRange(-180, 180)
        self.pitch_input.setValue(0)
        self.pitch_input.setPrefix('Pitch: ')
        layout.addWidget(self.pitch_input, 1, 2)
        
        self.yaw_input = QDoubleSpinBox()
        self.yaw_input.setRange(-180, 180)
        self.yaw_input.setValue(0)
        self.yaw_input.setPrefix('Yaw: ')
        layout.addWidget(self.yaw_input, 1, 3)
        
        # 解算结果
        layout.addWidget(QLabel('解算结果:'), 2, 0)
        self.ik_result_label = QLabel('未解算')
        self.ik_result_label.setWordWrap(True)
        layout.addWidget(self.ik_result_label, 2, 1, 1, 3)
        
        # 按钮
        btn_layout = QHBoxLayout()
        
        solve_btn = QPushButton('逆运动学解算')
        solve_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        solve_btn.clicked.connect(self._solve_ik)
        btn_layout.addWidget(solve_btn)
        
        send_btn = QPushButton('发送到电机')
        send_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        send_btn.clicked.connect(self._send_cartesian_to_motors)
        btn_layout.addWidget(send_btn)
        
        layout.addLayout(btn_layout, 3, 0, 1, 4)
        
        return panel
    
    def _load_robot_model(self):
        """加载机器人URDF模型"""
        # 查找URDF文件
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        urdf_path = os.path.join(project_root, 'python_viewer', '六轴机械臂', 'urdf', '六轴机械臂.urdf')
        
        if not os.path.exists(urdf_path):
            QMessageBox.warning(self, '警告', f'未找到URDF文件:\n{urdf_path}')
            return
        
        self.urdf_path = urdf_path
        
        # 加载到两个显示窗口
        success1 = self.real_viewer.load_urdf(urdf_path)
        success2 = self.theory_viewer.load_urdf(urdf_path)
        
        if not (success1 and success2):
            QMessageBox.warning(self, '警告', '加载URDF模型失败，请查看控制台输出')
            return
        
        # 创建机器人模型用于逆运动学
        if RTB_AVAILABLE:
            try:
                from roboticstoolbox import DHRobot, RevoluteDH
                # 使用DH参数创建机器人模型
                dh_params = [
                    RevoluteDH(d=0.100, a=0, alpha=np.pi/2, offset=0),
                    RevoluteDH(d=0, a=0.250, alpha=0, offset=0),
                    RevoluteDH(d=0, a=0.250, alpha=0, offset=0),
                    RevoluteDH(d=0, a=0, alpha=np.pi/2, offset=0),
                    RevoluteDH(d=0.100, a=0, alpha=-np.pi/2, offset=0),
                    RevoluteDH(d=0.080, a=0, alpha=0, offset=0),
                ]
                self.robot_model = DHRobot(dh_params, name='六轴机械臂')
                print("逆运动学模型创建成功")
            except Exception as e:
                print(f'创建IK模型失败: {e}')
        
        # 初始化显示
        self._update_theory_model()
    
    def _switch_mode(self, mode):
        """切换控制模式"""
        self.control_mode = mode
        
        if mode == 'joint':
            self.btn_joint_mode.setChecked(True)
            self.btn_cartesian_mode.setChecked(False)
            self.joint_panel.setVisible(True)
            self.cartesian_panel.setVisible(False)
        else:
            self.btn_joint_mode.setChecked(False)
            self.btn_cartesian_mode.setChecked(True)
            self.joint_panel.setVisible(False)
            self.cartesian_panel.setVisible(True)
    
    def _on_joint_slider_changed(self):
        """关节滑条改变"""
        for i, slider in enumerate(self.joint_sliders):
            value = slider.value()
            self.joint_spin_boxes[i].blockSignals(True)
            self.joint_spin_boxes[i].setValue(value)
            self.joint_spin_boxes[i].blockSignals(False)
            self.current_joint_angles_deg[i] = value
        
        self._update_theory_model()
    
    def _on_joint_spin_changed(self):
        """关节数值框改变"""
        for i, spin in enumerate(self.joint_spin_boxes):
            value = spin.value()
            self.joint_sliders[i].blockSignals(True)
            self.joint_sliders[i].setValue(int(value))
            self.joint_sliders[i].blockSignals(False)
            self.current_joint_angles_deg[i] = value
        
        self._update_theory_model()
    
    def _solve_ik(self):
        """逆运动学解算"""
        if not RTB_AVAILABLE or self.robot_model is None:
            QMessageBox.warning(self, '警告', '逆运动学功能不可用')
            return
        
        try:
            x = self.x_input.value()
            y = self.y_input.value()
            z = self.z_input.value()
            roll = np.radians(self.roll_input.value())
            pitch = np.radians(self.pitch_input.value())
            yaw = np.radians(self.yaw_input.value())
            
            T_target = SE3.Trans(x, y, z) * SE3.RPY([roll, pitch, yaw])
            q0 = np.radians(self.current_joint_angles_deg)
            sol = self.robot_model.ikine_LM(T_target, q0=q0)
            
            if sol.success:
                q_deg = np.degrees(sol.q)
                self.current_joint_angles_deg = q_deg.tolist()
                
                for i in range(min(6, len(q_deg))):
                    self.joint_spin_boxes[i].blockSignals(True)
                    self.joint_sliders[i].blockSignals(True)
                    self.joint_spin_boxes[i].setValue(q_deg[i])
                    self.joint_sliders[i].setValue(int(q_deg[i]))
                    self.joint_spin_boxes[i].blockSignals(False)
                    self.joint_sliders[i].blockSignals(False)
                
                result_text = '解算成功:\n'
                for i, angle in enumerate(q_deg[:6]):
                    result_text += f'关节{i+1}: {angle:.2f}°  '
                self.ik_result_label.setText(result_text)
                self.ik_result_label.setStyleSheet('color: green;')
                
                self._update_theory_model()
            else:
                self.ik_result_label.setText('解算失败：无法到达目标位姿')
                self.ik_result_label.setStyleSheet('color: red;')
        
        except Exception as e:
            self.ik_result_label.setText(f'解算错误: {str(e)}')
            self.ik_result_label.setStyleSheet('color: red;')
    
    def _update_theory_model(self):
        """更新理论模型显示"""
        self.theory_viewer.set_joint_angles(self.current_joint_angles_deg)
    
    def _update_real_model(self):
        """更新实时模型（从CAN读取）"""
        if not self.is_connected or self.can_base is None:
            return
        
        try:
            from motor_can_lib import DiagnosticCommand
            from motor_can_lib.responses import DiagnosticResponse
            
            # 读取每个关节的实际位置
            for i in range(6):
                motor_addr = i + 1
                try:
                    cmd = DiagnosticCommand(motor_addr)
                    resp_data = cmd.execute_read_motor_position(self.can_base, timeout=0.1)
                    
                    if resp_data:
                        # 解析响应
                        resp = DiagnosticResponse(motor_addr, resp_data)
                        result = resp.parse_motor_position()
                        
                        if result:
                            # 获取位置（度）
                            position_deg = result.get('position_deg', 0)
                            self.real_joint_angles_deg[i] = position_deg
                except Exception as e:
                    # 单个电机读取失败不影响其他
                    pass
            
            # 更新显示
            self.real_viewer.set_joint_angles(self.real_joint_angles_deg)
        except Exception as e:
            print(f'更新实时模型失败: {e}')
    
    def _send_joint_to_motors(self):
        """发送关节角度到电机"""
        if not self.is_connected or self.can_base is None:
            QMessageBox.warning(self, '警告', '未连接CAN设备')
            return
        
        try:
            from motor_can_lib import PositionControlCommand
            
            angles = self.current_joint_angles_deg
            
            # 确认对话框
            reply = QMessageBox.question(
                self, '确认', 
                f'即将发送以下角度到电机:\n' +
                '\n'.join([f'关节{i+1}: {angle:.1f}°' for i, angle in enumerate(angles)]) +
                '\n\n是否继续？',
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            
            if reply != QMessageBox.Yes:
                return
            
            # 发送到每个电机
            # 注意：这里假设角度直接对应电机目标位置
            # 实际应用中可能需要根据电机配置进行转换
            success_count = 0
            for i in range(6):
                motor_addr = i + 1
                target_angle = angles[i]
                
                try:
                    cmd = PositionControlCommand(motor_addr)
                    # 使用角度控制模式
                    cmd.set_target_angle(target_angle)
                    cmd.set_direction(0 if target_angle >= 0 else 1)
                    cmd.set_max_speed(100)  # RPM
                    cmd.set_acceleration(2)  # 档位
                    cmd.set_position_mode(0)  # 绝对位置
                    
                    resp = cmd.execute(self.can_base, timeout=1.0)
                    
                    if resp:
                        success_count += 1
                        print(f'关节{i+1}命令发送成功')
                    else:
                        print(f'关节{i+1}命令发送失败：无响应')
                except Exception as e:
                    print(f'关节{i+1}命令发送失败: {e}')
            
            if success_count == 6:
                QMessageBox.information(self, '成功', f'成功发送命令到所有{success_count}个关节')
            elif success_count > 0:
                QMessageBox.warning(self, '部分成功', f'成功发送命令到{success_count}/6个关节')
            else:
                QMessageBox.critical(self, '失败', '所有关节命令发送失败')
                
        except Exception as e:
            QMessageBox.critical(self, '错误', f'发送命令失败:\n{str(e)}')
    
    def _send_cartesian_to_motors(self):
        """发送笛卡尔坐标到电机"""
        self._solve_ik()
        if '成功' in self.ik_result_label.text():
            self._send_joint_to_motors()
    
    def update_can_connection(self, can_base, is_connected):
        """更新CAN连接状态"""
        self.can_base = can_base
        self.is_connected = is_connected
        
        if is_connected:
            self.update_timer.start(100)
        else:
            self.update_timer.stop()
