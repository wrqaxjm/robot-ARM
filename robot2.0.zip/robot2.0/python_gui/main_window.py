"""
主界面（PyQt5）
功能说明：
- 左侧为切换按钮栏，右侧为内容区域
- 包含"主页"、"指令控制"、"机械臂控制"、"参数界面"等模块
- 支持懒加载子界面，避免重复创建
- 关闭时优雅断开 CAN 连接
"""

import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QStackedWidget, QLabel)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

# 导入子界面（延迟导入，避免循环依赖）
# from .command_control_window import CommandControlWindow


class MainWindow(QMainWindow):
    """主窗口类"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle('六轴机械臂上位机软件')
        self.setGeometry(100, 100, 1024, 720)
        
        # 应用状态
        self.can_base = None
        self.is_connected = False
        
        # 子界面引用
        self.cmd_widget = None
        self.arm_widget = None
        self.params_widget = None
        
        # 子界面初始化标志
        self.cmd_view_initialized = False
        self.arm_view_initialized = False
        self.params_view_initialized = False
        
        # 创建UI
        self._init_ui()
        
        # 设置关闭事件
        self.closeEvent = self._cleanup_on_close
    
    def _init_ui(self):
        """初始化用户界面"""
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局：左右分栏
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # ========== 左侧切换栏 ==========
        left_panel = QWidget()
        left_panel.setFixedWidth(180)
        left_panel.setStyleSheet("""
            QWidget {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
        """)
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)
        left_layout.setSpacing(10)
        
        # 标题
        title_label = QLabel('功能切换')
        title_label.setFont(QFont('Arial', 12, QFont.Bold))
        left_layout.addWidget(title_label)
        
        # 切换按钮
        self.btn_home = QPushButton('主页')
        self.btn_cmd = QPushButton('指令控制')
        self.btn_params = QPushButton('参数界面')
        self.btn_arm = QPushButton('机械臂控制')
        
        # 设置按钮样式
        button_style = """
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """
        for btn in [self.btn_home, self.btn_cmd, self.btn_params, self.btn_arm]:
            btn.setStyleSheet(button_style)
            btn.setFixedHeight(40)
        
        # 添加到布局
        left_layout.addWidget(self.btn_home)
        left_layout.addWidget(self.btn_cmd)
        left_layout.addWidget(self.btn_params)
        left_layout.addWidget(self.btn_arm)
        left_layout.addStretch()  # 添加弹性空间
        
        # ========== 右侧内容区域 ==========
        # 使用 QStackedWidget 实现页面切换
        self.stacked_widget = QStackedWidget()
        
        # 创建各个页面
        self.home_page = QWidget()
        self.home_page.setStyleSheet("background-color: white;")
        home_label = QLabel('欢迎使用六轴机械臂上位机软件\n\n请从左侧选择功能模块')
        home_label.setAlignment(Qt.AlignCenter)
        home_label.setFont(QFont('Arial', 14))
        home_layout = QVBoxLayout(self.home_page)
        home_layout.addWidget(home_label)
        
        self.cmd_page = QWidget()
        self.cmd_page.setStyleSheet("background-color: white;")
        
        self.params_page = QWidget()
        self.params_page.setStyleSheet("background-color: white;")
        
        self.arm_page = QWidget()
        self.arm_page.setStyleSheet("background-color: white;")
        
        # 添加到堆叠窗口
        self.stacked_widget.addWidget(self.home_page)      # 索引 0
        self.stacked_widget.addWidget(self.cmd_page)       # 索引 1
        self.stacked_widget.addWidget(self.params_page)   # 索引 2
        self.stacked_widget.addWidget(self.arm_page)       # 索引 3
        
        # 默认显示主页
        self.stacked_widget.setCurrentIndex(0)
        
        # 添加到主布局
        main_layout.addWidget(left_panel)
        main_layout.addWidget(self.stacked_widget, stretch=1)
        
        # 连接信号
        self.btn_home.clicked.connect(lambda: self._show_panel('home'))
        self.btn_cmd.clicked.connect(lambda: self._show_panel('cmd'))
        self.btn_params.clicked.connect(lambda: self._show_panel('params'))
        self.btn_arm.clicked.connect(lambda: self._show_panel('arm'))
    
    def _show_panel(self, which):
        """切换显示的面板"""
        if which == 'home':
            self.stacked_widget.setCurrentIndex(0)
        elif which == 'cmd':
            self.stacked_widget.setCurrentIndex(1)
            # 懒加载指令控制界面
            if not self.cmd_view_initialized:
                try:
                    from .command_control_window import CommandControlWindow
                    self.cmd_widget = CommandControlWindow(self)
                    cmd_layout = QVBoxLayout(self.cmd_page)
                    cmd_layout.setContentsMargins(0, 0, 0, 0)
                    cmd_layout.addWidget(self.cmd_widget)
                    self.cmd_view_initialized = True
                except Exception as e:
                    from PyQt5.QtWidgets import QMessageBox
                    QMessageBox.critical(self, '错误', f'加载指令控制界面失败：\n{str(e)}')
        elif which == 'params':
            self.stacked_widget.setCurrentIndex(2)
            # 懒加载参数界面
            if not self.params_view_initialized:
                try:
                    from .params_window import ParamsWindow
                    params_widget = ParamsWindow(self)
                    params_layout = QVBoxLayout(self.params_page)
                    params_layout.setContentsMargins(0, 0, 0, 0)
                    params_layout.addWidget(params_widget)
                    self.params_view_initialized = True
                except Exception as e:
                    from PyQt5.QtWidgets import QMessageBox
                    QMessageBox.critical(self, '错误', f'加载参数界面失败：\n{str(e)}')
        elif which == 'arm':
            self.stacked_widget.setCurrentIndex(3)
            # 懒加载机械臂控制界面
            if not self.arm_view_initialized:
                try:
                    from .robot_control_window import RobotControlWindow
                    self.arm_widget = RobotControlWindow(self)
                    arm_layout = QVBoxLayout(self.arm_page)
                    arm_layout.setContentsMargins(0, 0, 0, 0)
                    arm_layout.addWidget(self.arm_widget)
                    self.arm_view_initialized = True
                    
                    # 如果已经有CAN连接，同步到机械臂控制界面
                    if self.cmd_widget and self.cmd_widget.is_connected:
                        self.arm_widget.update_can_connection(
                            self.cmd_widget.can_base,
                            True
                        )
                except Exception as e:
                    from PyQt5.QtWidgets import QMessageBox
                    QMessageBox.critical(self, '错误', f'加载机械臂控制界面失败：\n{str(e)}')
    
    def _cleanup_on_close(self, event):
        """关闭事件：优雅断开 CAN 连接"""
        try:
            # 尝试从全局获取连接状态（如果使用全局变量存储）
            # 这里假设使用实例变量
            if self.is_connected and self.can_base is not None:
                try:
                    self.can_base.disconnect()
                    import time
                    time.sleep(0.2)  # 等待底层关闭序列完成
                except Exception as e:
                    print(f'断开 CAN 时出现警告: {e}')
        except Exception as e:
            print(f'清理连接时出错: {e}')
        
        # 接受关闭事件
        event.accept()


def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用样式
    app.setStyle('Fusion')
    
    # 创建主窗口
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

