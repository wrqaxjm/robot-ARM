"""
参数界面（DH 参数配置）
功能说明：
- 提供 6 轴机械臂的改进 DH 参数配置（a, alpha, d, theta_offset）
- 支持从 URDF 文件自动加载默认参数
- 支持从全局变量加载/保存参数
- 保存后可供 3D 显示与逆解使用
"""

import os
import sys
import xml.etree.ElementTree as ET
import math
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QTableWidget, QTableWidgetItem, QHeaderView,
                             QMessageBox, QDoubleSpinBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

# 全局变量存储DH参数（模拟MATLAB的appdata）
_global_dh_params = None


def get_global_dh_params():
    """获取全局DH参数"""
    global _global_dh_params
    return _global_dh_params


def set_global_dh_params(params):
    """设置全局DH参数"""
    global _global_dh_params
    _global_dh_params = params


class ParamsWindow(QWidget):
    """参数配置窗口"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # URDF 路径配置
        self.urdf_path = r'e:\traeproject\robot2.0\python_viewer\六轴机械臂\urdf\六轴机械臂.urdf'
        
        # 初始化UI
        self._init_ui()
        
        # 初始化：尝试从 URDF 加载默认参数
        self._load_from_urdf()
    
    def _init_ui(self):
        """初始化用户界面"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # ========== 顶部标题与按钮 ==========
        header_layout = QHBoxLayout()
        
        title_label = QLabel('DH 参数配置（改进DH）')
        title_label.setFont(QFont('Arial', 12, QFont.Bold))
        header_layout.addWidget(title_label)
        
        header_layout.addStretch()
        
        btn_load_urdf = QPushButton('从URDF加载')
        btn_load_urdf.clicked.connect(self._load_from_urdf)
        header_layout.addWidget(btn_load_urdf)
        
        btn_load = QPushButton('从全局加载')
        btn_load.clicked.connect(self._load_from_global)
        header_layout.addWidget(btn_load)
        
        layout.addLayout(header_layout)
        
        # ========== 参数表格 ==========
        self.table = QTableWidget(6, 5)  # 6行（J1-J6），5列（关节名 + 4个参数）
        self.table.setHorizontalHeaderLabels([
            '关节',
            'a (连杆长度, mm)',
            'alpha (连杆扭角, 度)',
            'd (连杆偏距, mm)',
            'theta₀ (零位偏置, 度)'
        ])
        
        # 设置表格样式
        self.table.setStyleSheet("""
            QTableWidget {
                border: 2px solid #cccccc;
                border-radius: 5px;
                background-color: white;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QHeaderView::section {
                background-color: #f0f0f0;
                padding: 8px;
                border: 1px solid #cccccc;
                font-weight: bold;
            }
        """)
        
        # 设置列宽
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # 关节名列自适应
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        
        # 设置行高
        self.table.verticalHeader().setVisible(False)
        for i in range(6):
            self.table.setRowHeight(i, 35)
        
        # 填充表格
        self._populate_table()
        
        layout.addWidget(self.table)
        
        # ========== 底部操作区 ==========
        footer_layout = QHBoxLayout()
        
        btn_save = QPushButton('保存到全局')
        btn_save.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        btn_save.clicked.connect(self._save_to_global)
        footer_layout.addWidget(btn_save)
        
        footer_layout.addStretch()
        
        hint_label = QLabel('提示：alpha/theta₀ 以"度"输入并保存；a/d 建议使用 mm。保存后 3D 与逆解会读取。')
        hint_label.setStyleSheet("color: #666; font-size: 10px;")
        footer_layout.addWidget(hint_label)
        
        layout.addLayout(footer_layout)
    
    def _populate_table(self):
        """填充表格内容"""
        for i in range(6):
            # 关节名（只读）
            joint_item = QTableWidgetItem(f'J{i+1}')
            joint_item.setFlags(Qt.ItemIsEnabled)  # 只读
            joint_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 0, joint_item)
            
            # a (连杆长度, mm)
            a_spin = QDoubleSpinBox()
            a_spin.setRange(-10000, 10000)
            a_spin.setValue(0.0)
            a_spin.setDecimals(3)
            a_spin.setSuffix(' mm')
            self.table.setCellWidget(i, 1, a_spin)
            
            # alpha (连杆扭角, 度)
            alpha_spin = QDoubleSpinBox()
            alpha_spin.setRange(-360, 360)
            alpha_spin.setValue(0.0)
            alpha_spin.setDecimals(2)
            alpha_spin.setSuffix(' °')
            self.table.setCellWidget(i, 2, alpha_spin)
            
            # d (连杆偏距, mm)
            d_spin = QDoubleSpinBox()
            d_spin.setRange(-10000, 10000)
            d_spin.setValue(0.0)
            d_spin.setDecimals(3)
            d_spin.setSuffix(' mm')
            self.table.setCellWidget(i, 3, d_spin)
            
            # theta0 (零位偏置, 度)
            theta0_spin = QDoubleSpinBox()
            theta0_spin.setRange(-360, 360)
            theta0_spin.setValue(0.0)
            theta0_spin.setDecimals(2)
            theta0_spin.setSuffix(' °')
            self.table.setCellWidget(i, 4, theta0_spin)
    
    def _get_table_values(self):
        """从表格获取所有参数值"""
        params = {
            'a': [],
            'alpha': [],
            'd': [],
            'theta0': []
        }
        
        for i in range(6):
            a_widget = self.table.cellWidget(i, 1)
            alpha_widget = self.table.cellWidget(i, 2)
            d_widget = self.table.cellWidget(i, 3)
            theta0_widget = self.table.cellWidget(i, 4)
            
            params['a'].append(a_widget.value())
            params['alpha'].append(alpha_widget.value())
            params['d'].append(d_widget.value())
            params['theta0'].append(theta0_widget.value())
        
        return params
    
    def _set_table_values(self, params):
        """设置表格参数值"""
        for i in range(6):
            a_widget = self.table.cellWidget(i, 1)
            alpha_widget = self.table.cellWidget(i, 2)
            d_widget = self.table.cellWidget(i, 3)
            theta0_widget = self.table.cellWidget(i, 4)
            
            a_widget.setValue(params['a'][i] if i < len(params['a']) else 0.0)
            alpha_widget.setValue(params['alpha'][i] if i < len(params['alpha']) else 0.0)
            d_widget.setValue(params['d'][i] if i < len(params['d']) else 0.0)
            theta0_widget.setValue(params['theta0'][i] if i < len(params['theta0']) else 0.0)
    
    def _load_from_urdf(self):
        """从 URDF 文件加载 DH 参数"""
        try:
            if not os.path.isfile(self.urdf_path):
                QMessageBox.warning(self, '错误', f'未找到 URDF 文件:\n{self.urdf_path}')
                return
            
            # 解析 URDF 文件
            tree = ET.parse(self.urdf_path)
            root = tree.getroot()
            
            # 提取 DH 参数
            dh_params = self._extract_dh_from_urdf(root)
            
            if not dh_params or len(dh_params['a']) == 0:
                QMessageBox.warning(self, '提示', '无法从 URDF 提取 DH 参数，使用默认值')
                return
            
            # 将参数写入表格（alpha 和 theta0 转为度）
            params = {
                'a': dh_params['a'],
                'alpha': [math.degrees(a) for a in dh_params['alpha']],
                'd': dh_params['d'],
                'theta0': [math.degrees(t) for t in dh_params['theta0']]
            }
            
            self._set_table_values(params)
            QMessageBox.information(self, '成功', '已从 URDF 文件加载 DH 参数')
            
        except Exception as e:
            QMessageBox.critical(self, '错误', f'从 URDF 加载失败：\n{str(e)}')
    
    def _extract_dh_from_urdf(self, root):
        """从 URDF XML 根节点提取 DH 参数（改进DH）"""
        dh_params = {
            'a': [],
            'alpha': [],
            'd': [],
            'theta0': []
        }
        
        try:
            # 查找所有非固定关节（按顺序）
            joints = root.findall('.//joint')
            non_fixed_joints = []
            
            for joint in joints:
                joint_type = joint.get('type', '')
                if joint_type.lower() != 'fixed':
                    non_fixed_joints.append(joint)
            
            # 只处理前6个非固定关节
            for i, joint in enumerate(non_fixed_joints[:6]):
                # 获取关节的 origin 和 axis
                origin = joint.find('origin')
                axis = joint.find('axis')
                limit = joint.find('limit')
                
                # 提取平移和旋转（URDF中单位是米和弧度）
                xyz = [0.0, 0.0, 0.0]
                rpy = [0.0, 0.0, 0.0]
                
                if origin is not None:
                    xyz_str = origin.get('xyz', '0 0 0')
                    rpy_str = origin.get('rpy', '0 0 0')
                    try:
                        xyz = [float(x) for x in xyz_str.split()]
                        rpy = [float(x) for x in rpy_str.split()]
                    except:
                        pass
                
                # 提取关节轴方向
                axis_xyz = [0.0, 0.0, 1.0]
                if axis is not None:
                    axis_xyz_str = axis.get('xyz', '0 0 1')
                    try:
                        axis_xyz = [float(x) for x in axis_xyz_str.split()]
                        # 归一化
                        norm = math.sqrt(sum(x*x for x in axis_xyz))
                        if norm > 1e-6:
                            axis_xyz = [x/norm for x in axis_xyz]
                    except:
                        pass
                
                # 计算改进 DH 参数
                # 注意：URDF 的 origin 是相对于父连杆的变换
                # 改进 DH 参数需要从变换矩阵中提取
                
                # a: 沿 x_{i-1} 轴的距离（从 xyz 的 x 分量提取，转换为 mm）
                a_val = xyz[0] * 1000.0
                
                # alpha: 绕 x_{i-1} 轴的旋转（从 rpy 的 roll 分量提取，弧度）
                alpha_val = rpy[0]
                
                # d: 沿 z_i 轴的距离（从 xyz 的 z 分量提取，转换为 mm）
                d_val = xyz[2] * 1000.0
                
                # theta0: 关节零位（从 limit 获取，或默认为 0）
                theta0_val = 0.0
                if limit is not None:
                    lower = limit.get('lower')
                    upper = limit.get('upper')
                    if lower is not None and upper is not None:
                        try:
                            lower_val = float(lower)
                            upper_val = float(upper)
                            # 使用中点作为零位
                            theta0_val = (lower_val + upper_val) / 2.0
                        except:
                            pass
                
                dh_params['a'].append(a_val)
                dh_params['alpha'].append(alpha_val)
                dh_params['d'].append(d_val)
                dh_params['theta0'].append(theta0_val)
            
            # 确保至少有 6 个参数（补零）
            while len(dh_params['a']) < 6:
                dh_params['a'].append(0.0)
                dh_params['alpha'].append(0.0)
                dh_params['d'].append(0.0)
                dh_params['theta0'].append(0.0)
            
        except Exception as e:
            import traceback
            print(f'提取 DH 参数失败: {e}')
            print(traceback.format_exc())
            return None
        
        return dh_params
    
    def _load_from_global(self):
        """从全局变量加载 DH 参数"""
        try:
            params = get_global_dh_params()
            
            if params is None or not isinstance(params, dict) or 'a' not in params:
                QMessageBox.warning(self, '提示', '未检测到已保存的 DH 参数，使用默认值（0）')
                return
            
            # 读取数组并写入控件
            safe_params = {
                'a': [params['a'][i] if i < len(params['a']) else 0.0 for i in range(6)],
                'alpha': [params['alpha'][i] if i < len(params['alpha']) else 0.0 for i in range(6)],
                'd': [params['d'][i] if i < len(params['d']) else 0.0 for i in range(6)],
                'theta0': [params['theta0'][i] if i < len(params['theta0']) else 0.0 for i in range(6)]
            }
            
            self._set_table_values(safe_params)
            QMessageBox.information(self, '成功', '已从全局加载 DH 参数')
            
        except Exception as e:
            QMessageBox.critical(self, '错误', f'加载失败：\n{str(e)}')
    
    def _save_to_global(self):
        """保存 DH 参数到全局变量"""
        try:
            params = self._get_table_values()
            
            # 将 alpha 和 theta0 转为弧度（内部存储使用弧度）
            params_rad = {
                'a': params['a'],
                'alpha': [math.radians(a) for a in params['alpha']],
                'd': params['d'],
                'theta0': [math.radians(t) for t in params['theta0']]
            }
            
            # 保存到全局
            set_global_dh_params(params_rad)
            
            QMessageBox.information(self, '成功', 'DH 参数已保存到全局')
            
        except Exception as e:
            QMessageBox.critical(self, '错误', f'保存失败：\n{str(e)}')


if __name__ == '__main__':
    from PyQt5.QtWidgets import QApplication
    import sys
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    window = ParamsWindow()
    window.show()
    
    sys.exit(app.exec_())

