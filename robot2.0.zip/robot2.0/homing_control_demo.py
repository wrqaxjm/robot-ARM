#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
原点回零控制演示程序

演示如何使用motor_can_lib库中的原点回零功能，包括：
- 设置单圈回零的零点位置
- 触发回零
- 强制中断并退出回零操作
- 读取原点回零参数
- 修改原点回零参数
- 读取回零状态标志位
"""

import sys
import time
from typing import Optional

# 导入motor_can_lib库
from motor_can_lib import (
    MotorCANBase, CANError, CANTimeoutError,
    HomingControlCommand, HomingResponse
)


class HomingControlDemo:
    """原点回零控制演示类"""
    
    def __init__(self):
        """初始化演示程序"""
        # 默认配置参数
        self.com_port = "COM11"
        self.bitrate = 500000
        self.timeout = 2.0
        self.current_address = 1  # 当前操作的电机地址
        
        # 创建CAN通信基础实例
        self.can_base = MotorCANBase(
            com_port=self.com_port,
            bitrate=self.bitrate,
            timeout=self.timeout
        )
        
    def show_main_menu(self):
        """显示主菜单"""
        print("\n" + "="*60)
        print("                原点回零控制演示程序")
        print("="*60)
        print(f"配置信息:")
        print(f"  端口: {self.com_port}")
        print(f"  波特率: {self.bitrate} bps")
        print(f"  超时时间: {self.timeout}s")
        print(f"  当前电机地址: {self.current_address}")
        print(f"  连接状态: {'已连接' if self.can_base.is_connected else '未连接'}")
        print("-"*60)
        print("请选择操作:")
        print("  1. 连接CAN设备")
        print("  2. 设置单圈回零的零点位置")
        print("  3. 触发回零")
        print("  4. 强制中断并退出回零操作")
        print("  5. 读取原点回零参数")
        print("  6. 修改原点回零参数")
        print("  7. 读取回零状态标志位")
        print("  8. 显示回零使用说明")
        print("  9. 设置电机地址")
        print("  10. 断开连接")
        print("  0. 退出程序")
        print("-"*60)
    
    def connect_device(self):
        """连接CAN设备"""
        print(f"\n正在连接到 {self.com_port}...")
        
        if self.can_base.connect():
            print("✓ CAN设备连接成功!")
            print("✓ 可以开始进行原点回零操作")
        else:
            print("✗ CAN设备连接失败")
            print("请检查:")
            print("  - CANable设备是否正确连接")
            print("  - COM端口是否正确")
            print("  - 设备是否被其他程序占用")
    
    def disconnect_device(self):
        """断开设备连接"""
        if self.can_base.disconnect():
            print("✓ CAN设备已断开连接")
        else:
            print("✗ 断开连接时出现问题")
    
    def set_zero_position_demo(self):
        """设置单圈回零的零点位置演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 设置单圈回零的零点位置演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            save_choice = input("是否保存到Flash? (Y/n): ").strip().lower()
            save_to_flash = save_choice != 'n'
            
            print(f"正在设置零点位置 (保存到Flash: {'是' if save_to_flash else '否'})...")
            response_data = homing_cmd.execute_set_zero_position(
                self.can_base, save_to_flash, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_set_zero_position_response()
                if result['success']:
                    print("✓ 零点位置设置成功")
                else:
                    print("✗ 零点位置设置失败")
            else:
                print("✗ 未收到响应，设置可能失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def trigger_homing_demo(self):
        """触发回零演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 触发回零演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            print("回零模式:")
            print("  0. 单圈就近回零")
            print("  1. 单圈方向回零")
            print("  2. 多圈无限位碰撞回零")
            print("  3. 多圈有限位开关回零")
            
            mode_input = input("请选择回零模式 (0-3): ").strip()
            if not mode_input.isdigit() or int(mode_input) not in [0, 1, 2, 3]:
                print("✗ 无效的回零模式")
                return
            
            homing_mode = int(mode_input)
            sync_choice = input("是否启用多机同步? (y/N): ").strip().lower()
            multi_sync = sync_choice == 'y'
            
            print(f"正在触发回零 (模式: {homing_mode}, 多机同步: {'是' if multi_sync else '否'})...")
            response_data = homing_cmd.execute_trigger_homing(
                self.can_base, homing_mode, multi_sync, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_trigger_homing_response()
                if result['success']:
                    print("✓ 回零命令发送成功")
                    print("注意：回零过程可能需要一些时间，请使用'读取回零状态'查看进度")
                else:
                    print("✗ 回零命令发送失败")
            else:
                print("✗ 未收到响应，命令可能失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def force_stop_homing_demo(self):
        """强制中断并退出回零操作演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 强制中断并退出回零操作演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            confirm = input("确认要强制停止回零操作吗? (y/N): ").strip().lower()
            if confirm != 'y':
                print("操作已取消")
                return
            
            print("正在强制停止回零操作...")
            response_data = homing_cmd.execute_force_stop_homing(
                self.can_base, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_force_stop_homing_response()
                if result['success']:
                    print("✓ 回零操作已强制停止")
                else:
                    print("✗ 强制停止失败")
            else:
                print("✗ 未收到响应，操作可能失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def read_homing_params_demo(self):
        """读取原点回零参数演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 读取原点回零参数演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            print("正在读取回零参数...")
            response_data = homing_cmd.execute_read_homing_params(
                self.can_base, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示（新格式数据不含地址）
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_read_homing_params_response()
                print("✓ 回零参数读取成功:")
                print(response.format_homing_params(result))
            else:
                print("✗ 未收到响应，读取失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def modify_homing_params_demo(self):
        """修改原点回零参数演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 修改原点回零参数演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            print("请输入新的回零参数 (直接回车使用默认值):")
            
            # 收集参数
            params = {}
            
            # 回零模式
            mode_input = input("回零模式 (0:就近 1:方向 2:碰撞 3:限位) [0]: ").strip()
            params['homing_mode'] = int(mode_input) if mode_input.isdigit() and int(mode_input) in [0,1,2,3] else 0
            
            # 回零方向
            dir_input = input("回零方向 (0:顺时针 1:逆时针) [0]: ").strip()
            params['direction'] = int(dir_input) if dir_input.isdigit() and int(dir_input) in [0,1] else 0
            
            # 回零速度
            speed_input = input("回零速度 (RPM) [30]: ").strip()
            params['speed_rpm'] = int(speed_input) if speed_input.isdigit() and int(speed_input) > 0 else 30
            
            # 回零超时时间
            timeout_input = input("回零超时时间 (ms) [10000]: ").strip()
            params['timeout_ms'] = int(timeout_input) if timeout_input.isdigit() and int(timeout_input) > 0 else 10000
            
            # 碰撞检测转速
            collision_speed_input = input("碰撞检测转速 (RPM) [300]: ").strip()
            params['collision_speed_rpm'] = int(collision_speed_input) if collision_speed_input.isdigit() and int(collision_speed_input) > 0 else 300
            
            # 碰撞检测电流
            collision_current_input = input("碰撞检测电流 (mA) [800]: ").strip()
            params['collision_current_ma'] = int(collision_current_input) if collision_current_input.isdigit() and int(collision_current_input) > 0 else 800
            
            # 碰撞检测时间
            collision_time_input = input("碰撞检测时间 (ms) [60]: ").strip()
            params['collision_time_ms'] = int(collision_time_input) if collision_time_input.isdigit() and int(collision_time_input) > 0 else 60
            
            # 自动回零使能
            auto_input = input("上电自动回零 (y/N) [N]: ").strip().lower()
            params['auto_homing_enable'] = auto_input == 'y'
            
            # 是否保存到Flash
            save_choice = input("是否保存到Flash? (Y/n): ").strip().lower()
            save_to_flash = save_choice != 'n'
            
            print("正在修改回零参数...")
            response_data = homing_cmd.execute_modify_homing_params(
                self.can_base, params, save_to_flash, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示（新格式数据不含地址）
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_modify_homing_params_response()
                if result['success']:
                    print("✓ 回零参数修改成功")
                else:
                    print("✗ 回零参数修改失败")
            else:
                print("✗ 未收到响应，修改可能失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def read_homing_status_demo(self):
        """读取回零状态标志位演示"""
        if not self.can_base.is_connected:
            print("✗ CAN设备未连接，请先连接设备")
            return
        
        print(f"\n=== 读取回零状态标志位演示 (地址: {self.current_address}) ===")
        
        try:
            # 创建原点回零控制命令实例
            homing_cmd = HomingControlCommand.create_homing_command(self.current_address)
            
            print("正在读取回零状态...")
            response_data = homing_cmd.execute_read_homing_status(
                self.can_base, self.timeout
            )
            
            if response_data:
                # 传入当前设备地址用于显示（新格式数据不含地址）
                response = HomingResponse(response_data, address=self.current_address)
                result = response.parse_read_homing_status_response()
                print("✓ 回零状态读取成功:")
                print(response.format_homing_status(result))
            else:
                print("✗ 未收到响应，读取失败")
                
        except (CANError, CANTimeoutError) as e:
            print(f"✗ 命令执行失败: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def show_homing_usage_guide(self):
        """显示回零使用说明"""
        print(f"\n=== 原点回零使用说明 ===")
        print()
        print("【回零模式说明】")
        print("0. 单圈就近回零：电机转动到最近的零点位置")
        print("1. 单圈方向回零：电机按指定方向转动到零点位置")
        print("2. 多圈无限位碰撞回零：电机转动直到检测到碰撞")
        print("3. 多圈有限位开关回零：电机转动直到触发限位开关")
        print()
        print("【操作流程建议】")
        print("1. 首先读取当前回零参数，了解电机配置")
        print("2. 根据需要修改回零参数（速度、超时时间等）")
        print("3. 设置单圈回零的零点位置（如果需要）")
        print("4. 触发回零操作")
        print("5. 定期读取回零状态，监控回零进度")
        print("6. 如果需要，可以强制中断回零操作")
        print()
        print("【注意事项】")
        print("- 回零过程中电机会运动，请确保安全")
        print("- 碰撞回零模式需要合理设置检测参数")
        print("- 限位开关回零需要硬件支持")
        print("- 回零超时时间应根据实际情况设置")
        print("- 多机同步回零需要先发送同步命令，再发送同步触发")
        print()
        print("【状态说明】")
        print("- 未回零(0)：电机尚未进行回零操作")
        print("- 回零中(1)：电机正在执行回零操作")
        print("- 回零成功(2)：电机已成功完成回零")
        print("- 回零失败(3)：回零操作失败（超时或其他错误）")
        
        input("\n按回车键返回...")
    
    def set_motor_address(self):
        """设置电机地址"""
        print(f"\n=== 设置电机地址 ===")
        print(f"当前电机地址: {self.current_address}")
        
        try:
            # 允许设置0地址，表示广播地址
            address_input = input("请输入新的电机地址 (0-255，0为广播): ").strip()
            if not address_input:
                print("✗ 地址不能为空")
                return
            
            address = int(address_input)
            if address < 0 or address > 255:
                print("✗ 地址必须在0-255范围内")
                return
            
            self.current_address = address
            if self.current_address == 0:
                print(f"✓ 电机地址已设置为: 0 (广播地址)")
                print("提示: 使用广播地址发送的命令将被所有设备接收")
            else:
                print(f"✓ 电机地址已设置为: {self.current_address}")
            
        except ValueError:
            print("✗ 请输入有效的数字")
        except Exception as e:
            print(f"✗ 设置地址时发生错误: {e}")
    
    def run(self):
        """运行主程序循环"""
        print("欢迎使用原点回零控制演示程序!")
        print("基于motor_can_lib库，演示原点回零相关功能")
        
        while True:
            try:
                self.show_main_menu()
                choice = input("请输入选择 (0-10): ").strip()
                
                if choice == "0":
                    print("\n正在退出程序...")
                    if self.can_base.is_connected:
                        self.disconnect_device()
                    print("再见!")
                    break
                elif choice == "1":
                    self.connect_device()
                elif choice == "2":
                    self.set_zero_position_demo()
                elif choice == "3":
                    self.trigger_homing_demo()
                elif choice == "4":
                    self.force_stop_homing_demo()
                elif choice == "5":
                    self.read_homing_params_demo()
                elif choice == "6":
                    self.modify_homing_params_demo()
                elif choice == "7":
                    self.read_homing_status_demo()
                elif choice == "8":
                    self.show_homing_usage_guide()
                elif choice == "9":
                    self.set_motor_address()
                elif choice == "10":
                    self.disconnect_device()
                else:
                    print("✗ 无效选择，请输入 0-10")
                
                # 等待用户按键继续
                if choice != "0":
                    input("\n按回车键继续...")
                    
            except KeyboardInterrupt:
                print("\n\n检测到 Ctrl+C，正在退出...")
                if self.can_base.is_connected:
                    self.disconnect_device()
                break
            except Exception as e:
                print(f"\n✗ 发生未知错误: {e}")
                input("按回车键继续...")


def main():
    """主函数"""
    try:
        demo = HomingControlDemo()
        demo.run()
    except Exception as e:
        print(f"程序启动失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()