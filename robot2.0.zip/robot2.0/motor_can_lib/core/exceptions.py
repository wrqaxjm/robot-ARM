"""
CAN通信异常类定义
"""
from typing import Optional


class CANError(Exception):
    """CAN通信基础异常类"""
    
    def __init__(self, message: str, can_id: Optional[int] = None, data: Optional[bytes] = None):
        self.can_id = can_id
        self.data = data
        super().__init__(message)


class CANTimeoutError(CANError):
    """CAN通信超时异常"""
    
    def __init__(self, message: str = "CAN通信超时", can_id: Optional[int] = None):
        super().__init__(message, can_id)


class CANResponseError(CANError):
    """CAN响应错误异常"""
    
    def __init__(self, message: str, response_data: bytes, can_id: Optional[int] = None):
        self.response_data = response_data
        super().__init__(message, can_id, response_data)


class CANChecksumError(CANError):
    """CAN校验和错误异常"""
    
    def __init__(self, expected: int, actual: int, can_id: Optional[int] = None):
        message = f"校验和错误: 期望 {expected:02X}, 实际 {actual:02X}"
        super().__init__(message, can_id)


class CANCommandError(CANError):
    """CAN指令错误异常"""
    
    def __init__(self, command_code: int, error_code: int, can_id: Optional[int] = None):
        message = f"指令错误: 命令码 0x{command_code:02X}, 错误码 0x{error_code:02X}"
        super().__init__(message, can_id)