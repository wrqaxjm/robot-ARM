"""
CAN通信基础类
提供与CANable设备通信的基础功能
"""

import can
import time
from typing import Optional, List, Callable
from ..core.exceptions import CANError, CANTimeoutError


class MotorCANBase:
    """电机CAN通信基础类"""
    
    def __init__(self, com_port: str = "COM11", bitrate: int = 500000, 
                 sample_point: float = 0.875, timeout: float = 1.0):
        """
        初始化CAN通信基础类
        
        Args:
            com_port: COM端口，默认COM11
            bitrate: 波特率，默认500K bps
            sample_point: 采样率，默认87.5%
            timeout: 通信超时时间，默认1秒
        """
        self.com_port = com_port
        self.bitrate = bitrate
        self.sample_point = sample_point
        self.timeout = timeout
        
        self.bus: Optional[can.BusABC] = None
        self.is_connected = False
        
        # 默认校验字节
        self.checksum_byte = 0x6B
    
    def connect(self) -> bool:
        """连接CANable设备"""
        try:
            self.bus = can.Bus(
                bustype='slcan',
                channel=self.com_port,
                bitrate=self.bitrate,
                timeout=0.1,
                sleep_after_open=2
            )
            self.is_connected = True
            print(f"✓ 设备连接成功: {self.com_port}")
            return True
            
        except Exception as e:
            print(f"✗ 连接失败: {e}")
            self.is_connected = False
            return False
    
    def disconnect(self) -> bool:
        """断开设备连接"""
        if self.bus and self.is_connected:
            try:
                self.bus.shutdown()
                self.bus = None
                self.is_connected = False
                print("✓ 设备已断开连接")
                return True
            except Exception as e:
                print(f"✗ 断开连接时出错: {e}")
                return False
        return True
    
    def calculate_checksum(self, data: bytes) -> int:
        """计算校验和（简单实现，可根据实际协议调整）"""
        # 这里使用固定的0x6B作为校验字节
        # 实际协议可能需要计算所有字节的和或其他算法
        return self.checksum_byte
    
    def build_can_id(self, address: int, packet_num: int = 0) -> int:
        """
        构建CAN ID
        
        Args:
            address: 设备地址
            packet_num: 包序号（低8位），0表示单包或第一包
            
        Returns:
            int: 完整的CAN ID
        """
        # 地址左移8位，低8位为包序号
        return (address << 8) | packet_num
    
    def send_message(self, can_id: int, data: bytes, timeout: Optional[float] = None) -> bool:
        """发送CAN消息"""
        if not self.is_connected or not self.bus:
            raise CANError("设备未连接")
        
        timeout = timeout or self.timeout
        
        try:
            message = can.Message(
                arbitration_id=can_id,
                data=data,
                is_extended_id=True
            )
            
            self.bus.send(message, timeout=timeout)
            return True
            
        except Exception as e:
            raise CANError(f"发送失败: {e}", can_id)
    
    def receive_message(self, timeout: Optional[float] = None) -> Optional[can.Message]:
        """接收CAN消息"""
        if not self.is_connected or not self.bus:
            raise CANError("设备未连接")
        
        timeout = timeout or self.timeout
        
        try:
            return self.bus.recv(timeout=timeout)
        except Exception as e:
            raise CANError(f"接收失败: {e}")
    
    def send_and_receive(self, can_id: int, data: bytes, 
                        response_timeout: float = 2.0,
                        filter_func: Optional[Callable[[can.Message], bool]] = None) -> Optional[can.Message]:
        """
        发送消息并等待响应
        
        Args:
            can_id: 发送的CAN ID
            data: 发送的数据
            response_timeout: 响应超时时间
            filter_func: 响应过滤函数
            
        Returns:
            Optional[can.Message]: 接收到的响应消息
        """
        # 发送消息
        if not self.send_message(can_id, data):
            return None
        
        # 等待响应
        start_time = time.time()
        while time.time() - start_time < response_timeout:
            response = self.receive_message(timeout=0.1)
            if response is not None:
                # 如果没有过滤函数，或者过滤函数返回True，则返回响应
                if filter_func is None or filter_func(response):
                    return response
        
        raise CANTimeoutError(f"响应超时: CAN ID 0x{can_id:08X}", can_id)

    def send_and_receive_multi(self, can_id: int, data: bytes,
                               expected_command_code: int,
                               response_timeout: float = 2.0) -> Optional[bytes]:
        """
        发送消息并聚合分包响应（适用于设备返回数据超过8字节的场景）

        参数说明：
        - can_id: 发送使用的CAN ID（高8位为地址，低8位为包序号，一般为0）
        - data: 发送的数据字节
        - expected_command_code: 期望的响应功能码（例如读取回零参数为0x22）
        - response_timeout: 总体接收超时时间

        返回：
        - 聚合后的完整响应数据（以功能码开头）
        - 如果超时或未收到有效数据，返回None
        """
        # 先发送原始请求
        if not self.send_message(can_id, data):
            return None

        if not self.is_connected or not self.bus:
            raise CANError("设备未连接")

        base_prefix = can_id & 0xFF00  # 地址前缀 (地址 << 8)
        segments: dict[int, bytes] = {}
        last_receive_time: Optional[float] = None
        idle_gap = 0.3  # 分包接收空闲窗口，单位秒

        start_time = time.time()
        while time.time() - start_time < response_timeout:
            try:
                msg = self.bus.recv(timeout=0.1)
            except Exception as e:
                raise CANError(f"接收失败: {e}")

            if msg is None:
                # 如果已有分段，且在空闲窗口内没有新消息，则认为接收完成
                if last_receive_time is not None and (time.time() - last_receive_time) >= idle_gap:
                    break
                continue

            # 仅聚合来自相同地址前缀的扩展帧
            if (msg.arbitration_id & 0xFF00) != base_prefix:
                continue

            if not msg.data or len(msg.data) == 0:
                continue

            # 每包首字节应为功能码，过滤无关包
            if msg.data[0] != expected_command_code:
                continue

            seq = msg.arbitration_id & 0x00FF  # 低8位包序号
            # 如果该序号尚未记录，存入分段
            if seq not in segments:
                segments[seq] = bytes(msg.data)
                last_receive_time = time.time()

        if not segments:
            return None

        # 根据包序号升序拼接：首包完整保留，其余包去掉首字节功能码避免重复
        assembled: Optional[bytes] = None
        for seq in sorted(segments.keys()):
            part = segments[seq]
            if assembled is None:
                assembled = part
            else:
                assembled += part[1:]

        return assembled
    
    def __enter__(self):
        """上下文管理器入口"""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.disconnect()


# 工具函数
def format_hex_data(data: bytes) -> str:
    """格式化十六进制数据为字符串"""
    return ' '.join(f'{b:02X}' for b in data) if data else "无数据"

def parse_hex_input(hex_str: str) -> bytes:
    """解析十六进制字符串为字节数据"""
    if not hex_str:
        return b''
    
    data_bytes = []
    parts = hex_str.split()
    
    for part in parts:
        if part.lower().startswith('0x'):
            byte_val = int(part, 16)
        else:
            byte_val = int(part, 16)
        
        if byte_val < 0 or byte_val > 255:
            raise ValueError(f"字节值 {part} 超出范围 (0x00-0xFF)")
        
        data_bytes.append(byte_val)
    
    return bytes(data_bytes)