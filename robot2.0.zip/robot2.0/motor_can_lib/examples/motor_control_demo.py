"""
电机控制演示

此示例展示如何使用motor_can_lib库进行完整的电机控制流程
"""

import sys
import os
import time

# 添加库路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from motor_can_lib import MotorCANBase, EnableControlCommand, SpeedControlCommand, StopControlCommand
from motor_can_lib import EnableResponse, SpeedResponse, StopResponse


class MotorController:
    """电机控制器类"""
    
    def __init__(self, com_port: str = "COM3", baud_rate: int = 115200):
        """
        初始化电机控制器
        
        Args:
            com_port: CAN设备串口号
            baud_rate: 波特率
        """
        self.can_base = MotorCANBase()
        self.com_port = com_port
        self.baud_rate = baud_rate
        self.is_connected = False
    
    def connect(self) -> bool:
        """连接到CAN设备"""
        try:
            print(f"正在连接到CAN设备 {self.com_port}...")
            self.can_base.connect()
            self.is_connected = self.can_base.is_connected
            
            if self.is_connected:
                print("✓ CAN设备连接成功")
            else:
                print("✗ CAN设备连接失败")
                
            return self.is_connected
            
        except Exception as e:
            print(f"✗ 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开CAN设备连接"""
        if self.is_connected:
            self.can_base.disconnect()
            self.is_connected = False
            print("✓ CAN设备已断开")
    
    def enable_motor(self, address: int = 1, enable: bool = True) -> bool:
        """启用或禁用电机"""
        if not self.is_connected:
            print("✗ 设备未连接")
            return False
        
        try:
            print(f"\n--- {'启用' if enable else '禁用'}电机 (地址: {address}) ---")
            
            # 创建使能命令
            enable_cmd = EnableControlCommand(address)
            enable_cmd.set_enable(enable, multi_sync=False)
            
            # 执行命令
            response = enable_cmd.execute(self.can_base, timeout=2.0)
            
            if response:
                # 解析响应
                enable_response = EnableResponse.analyze_response(response)
                return enable_response.is_success()
            else:
                print("✗ 未收到响应")
                return False
                
        except Exception as e:
            print(f"✗ 使能控制失败: {e}")
            return False
    
    def set_speed(self, address: int = 1, direction: int = 1, 
                 speed: int = 1000, acceleration: int = 500) -> bool:
        """设置电机速度"""
        if not self.is_connected:
            print("✗ 设备未连接")
            return False
        
        try:
            print(f"\n--- 设置电机速度 (地址: {address}) ---")
            print(f"  方向: {'正向' if direction == 1 else '反向'}")
            print(f"  速度: {speed} RPM")
            print(f"  加速度: {acceleration}")
            
            # 创建速度命令
            speed_cmd = SpeedControlCommand(address)
            speed_cmd.set_direction(direction)
            speed_cmd.set_speed(speed)
            speed_cmd.set_acceleration(acceleration)
            speed_cmd.set_multi_sync(False)
            
            # 执行命令
            response = speed_cmd.execute(self.can_base, timeout=2.0)
            
            if response:
                # 解析响应
                speed_response = SpeedResponse.analyze_response(response)
                return speed_response.is_success()
            else:
                print("✗ 未收到响应")
                return False
                
        except Exception as e:
            print(f"✗ 速度控制失败: {e}")
            return False
    
    def stop_motor(self, address: int = 1) -> bool:
        """立即停止电机"""
        if not self.is_connected:
            print("✗ 设备未连接")
            return False
        
        try:
            print(f"\n--- 立即停止电机 (地址: {address}) ---")
            
            # 创建停止命令
            stop_cmd = StopControlCommand(address)
            stop_cmd.set_multi_sync(False)
            
            # 执行命令
            response = stop_cmd.execute(self.can_base, timeout=2.0)
            
            if response:
                # 解析响应
                stop_response = StopResponse.analyze_response(response)
                return stop_response.is_success()
            else:
                print("✗ 未收到响应")
                return False
                
        except Exception as e:
            print(f"✗ 停止控制失败: {e}")
            return False
    
    def demo_control_sequence(self, address: int = 1):
        """演示控制序列"""
        if not self.connect():
            return
        
        try:
            print("\n" + "="*50)
            print("开始电机控制演示")
            print("="*50)
            
            # 1. 启用电机
            if self.enable_motor(address, True):
                print("✓ 电机启用成功")
                time.sleep(1)  # 等待1秒
            else:
                print("✗ 电机启用失败")
                return
            
            # 2. 设置正向速度
            if self.set_speed(address, 1, 1500, 800):
                print("✓ 正向速度设置成功")
                time.sleep(3)  # 运行3秒
            else:
                print("✗ 正向速度设置失败")
                return
            
            # 3. 设置反向速度
            if self.set_speed(address, 0, 1000, 600):
                print("✓ 反向速度设置成功")
                time.sleep(2)  # 运行2秒
            else:
                print("✗ 反向速度设置失败")
                return
            
            # 4. 停止电机
            if self.stop_motor(address):
                print("✓ 电机停止成功")
                time.sleep(1)  # 等待1秒
            else:
                print("✗ 电机停止失败")
            
            # 5. 禁用电机
            if self.enable_motor(address, False):
                print("✓ 电机禁用成功")
            else:
                print("✗ 电机禁用失败")
            
            print("\n" + "="*50)
            print("电机控制演示完成")
            print("="*50)
            
        finally:
            # 确保断开连接
            self.disconnect()


def main():
    """主函数"""
    print("电机驱动板CAN指令库 - 控制演示")
    print("="*50)
    
    # 创建电机控制器
    controller = MotorController("COM3", 115200)  # 根据实际情况修改串口参数
    
    # 执行控制演示
    controller.demo_control_sequence(address=1)
    
    print("\n演示结束。如需实际运行，请修改串口参数并连接CAN设备。")


if __name__ == "__main__":
    main()