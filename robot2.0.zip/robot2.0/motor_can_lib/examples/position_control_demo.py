"""
位置控制示例程序

演示如何使用位置控制命令进行电机的精确位置控制
支持角度控制、转数控制和脉冲控制三种方式
"""

import sys
import os
import time

# 添加库路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from motor_can_lib import (
    MotorCANBase, 
    EnableControlCommand, 
    PositionControlCommand, 
    StopControlCommand,
    EnableResponse,
    PositionResponse,
    StopResponse,
    CANError
)


def position_control_demo():
    """位置控制演示"""
    print("=== 电机位置控制演示 ===")
    
    # 初始化CAN通信
    can_base = MotorCANBase()
    
    try:
        # 连接CAN设备
        if not can_base.connect():
            print("❌ CAN设备连接失败")
            return
        
        print("✅ CAN设备连接成功")
        
        # 1. 使能电机
        print("\n--- 步骤1: 使能电机 ---")
        enable_cmd = EnableControlCommand(address=1)
        enable_response_data = enable_cmd.execute(can_base)
        
        if enable_response_data:
            enable_response = EnableResponse(enable_response_data)
            if enable_response.is_success():
                print("✅ 电机使能成功")
            else:
                print(f"❌ 电机使能失败: {enable_response.get_status_meaning()}")
                return
        else:
            print("❌ 电机使能命令无响应")
            return
        
        # 等待电机稳定
        time.sleep(1)
        
        # 2. 角度控制示例 - 转90度
        print("\n--- 步骤2: 角度控制 (转90度) ---")
        angle_cmd = PositionControlCommand.create_angle_command(
            angle_degrees=90.0,      # 转90度
            speed_rpm=1000,          # 速度1000RPM
            acceleration=5,          # 加速度档位5
            position_mode=PositionControlCommand.MODE_RELATIVE,  # 相对位置
            address=1,
            subdivision=16           # 16细分
        )
        
        print(f"发送角度控制命令: 90度, 速度1000RPM")
        position_response_data = angle_cmd.execute(can_base)
        
        if position_response_data:
            position_response = PositionResponse(position_response_data)
            if position_response.is_success():
                print("✅ 角度控制命令发送成功")
            else:
                print(f"❌ 角度控制失败: {position_response.get_status_meaning()}")
        else:
            print("❌ 角度控制命令无响应")
        
        # 等待运动完成
        print("等待运动完成...")
        time.sleep(3)
        
        # 3. 转数控制示例 - 转2圈
        print("\n--- 步骤3: 转数控制 (转2圈) ---")
        rev_cmd = PositionControlCommand(address=1, subdivision=16)
        rev_cmd.set_revolutions(2.0)\
               .set_speed(1500)\
               .set_acceleration(10)\
               .set_position_mode(PositionControlCommand.MODE_RELATIVE)
        
        print(f"发送转数控制命令: 2圈, 速度1500RPM")
        position_response_data = rev_cmd.execute(can_base)
        
        if position_response_data:
            position_response = PositionResponse(position_response_data)
            if position_response.is_success():
                print("✅ 转数控制命令发送成功")
            else:
                print(f"❌ 转数控制失败: {position_response.get_status_meaning()}")
        else:
            print("❌ 转数控制命令无响应")
        
        # 等待运动完成
        print("等待运动完成...")
        time.sleep(4)
        
        # 4. 脉冲控制示例 - 精确脉冲数
        print("\n--- 步骤4: 脉冲控制 (32000脉冲 = 10圈) ---")
        pulse_cmd = PositionControlCommand.create_position_command(
            pulse_count=32000,       # 32000脉冲 = 10圈 (16细分)
            direction=PositionControlCommand.DIRECTION_CCW,  # 逆时针
            speed_rpm=2000,          # 速度2000RPM
            acceleration=15,         # 加速度档位15
            position_mode=PositionControlCommand.MODE_RELATIVE,
            address=1,
            subdivision=16
        )
        
        print(f"发送脉冲控制命令: 32000脉冲(10圈), 速度2000RPM")
        position_response_data = pulse_cmd.execute(can_base)
        
        if position_response_data:
            position_response = PositionResponse(position_response_data)
            if position_response.is_success():
                print("✅ 脉冲控制命令发送成功")
            else:
                print(f"❌ 脉冲控制失败: {position_response.get_status_meaning()}")
        else:
            print("❌ 脉冲控制命令无响应")
        
        # 等待运动完成
        print("等待运动完成...")
        time.sleep(6)
        
        # 5. 停止电机
        print("\n--- 步骤5: 停止电机 ---")
        stop_cmd = StopControlCommand(address=1)
        stop_response_data = stop_cmd.execute(can_base)
        
        if stop_response_data:
            stop_response = StopResponse(stop_response_data)
            if stop_response.is_success():
                print("✅ 电机停止成功")
            else:
                print(f"❌ 电机停止失败: {stop_response.get_status_meaning()}")
        else:
            print("❌ 电机停止命令无响应")
        
        print("\n=== 位置控制演示完成 ===")
        
    except CANError as e:
        print(f"❌ CAN通信错误: {e}")
    except Exception as e:
        print(f"❌ 程序执行错误: {e}")
    finally:
        # 断开连接
        can_base.disconnect()
        print("CAN设备已断开连接")


def interactive_position_control():
    """交互式位置控制"""
    print("=== 交互式位置控制 ===")
    
    can_base = MotorCANBase()
    
    try:
        if not can_base.connect():
            print("❌ CAN设备连接失败")
            return
        
        print("✅ CAN设备连接成功")
        print("请先使能电机，然后选择控制方式:")
        
        while True:
            print("\n控制选项:")
            print("1. 使能电机")
            print("2. 角度控制")
            print("3. 转数控制") 
            print("4. 脉冲控制")
            print("5. 停止电机")
            print("0. 退出")
            
            choice = input("请选择操作 (0-5): ").strip()
            
            if choice == '0':
                break
            elif choice == '1':
                # 使能电机
                enable_cmd = EnableControlCommand(address=1)
                response_data = enable_cmd.execute(can_base)
                if response_data:
                    response = EnableResponse(response_data)
                    print(f"使能结果: {response.get_status_meaning()}")
                
            elif choice == '2':
                # 角度控制
                try:
                    angle = float(input("请输入角度 (度, 正数逆时针, 负数顺时针): "))
                    speed = int(input("请输入速度 (RPM, 1-3000): "))
                    subdivision = int(input("请输入细分数 (默认16): ") or "16")
                    
                    cmd = PositionControlCommand.create_angle_command(
                        angle_degrees=angle,
                        speed_rpm=speed,
                        address=1,
                        subdivision=subdivision
                    )
                    
                    response_data = cmd.execute(can_base)
                    if response_data:
                        response = PositionResponse(response_data)
                        print(f"角度控制结果: {response.get_status_meaning()}")
                        
                except ValueError:
                    print("❌ 输入格式错误")
                
            elif choice == '3':
                # 转数控制
                try:
                    revolutions = float(input("请输入转数 (正数逆时针, 负数顺时针): "))
                    speed = int(input("请输入速度 (RPM, 1-3000): "))
                    subdivision = int(input("请输入细分数 (默认16): ") or "16")
                    
                    cmd = PositionControlCommand(address=1, subdivision=subdivision)
                    cmd.set_revolutions(revolutions).set_speed(speed)
                    
                    response_data = cmd.execute(can_base)
                    if response_data:
                        response = PositionResponse(response_data)
                        print(f"转数控制结果: {response.get_status_meaning()}")
                        
                except ValueError:
                    print("❌ 输入格式错误")
                
            elif choice == '4':
                # 脉冲控制
                try:
                    pulse_count = int(input("请输入脉冲数: "))
                    direction = int(input("请输入方向 (0=顺时针, 1=逆时针): "))
                    speed = int(input("请输入速度 (RPM, 1-3000): "))
                    
                    cmd = PositionControlCommand.create_position_command(
                        pulse_count=pulse_count,
                        direction=direction,
                        speed_rpm=speed,
                        address=1
                    )
                    
                    response_data = cmd.execute(can_base)
                    if response_data:
                        response = PositionResponse(response_data)
                        print(f"脉冲控制结果: {response.get_status_meaning()}")
                        
                except ValueError:
                    print("❌ 输入格式错误")
                
            elif choice == '5':
                # 停止电机
                stop_cmd = StopControlCommand(address=1)
                response_data = stop_cmd.execute(can_base)
                if response_data:
                    response = StopResponse(response_data)
                    print(f"停止结果: {response.get_status_meaning()}")
            
            else:
                print("❌ 无效选择")
    
    except Exception as e:
        print(f"❌ 程序执行错误: {e}")
    finally:
        can_base.disconnect()
        print("CAN设备已断开连接")


if __name__ == "__main__":
    print("位置控制示例程序")
    print("1. 自动演示")
    print("2. 交互式控制")
    
    mode = input("请选择模式 (1/2): ").strip()
    
    if mode == '1':
        position_control_demo()
    elif mode == '2':
        interactive_position_control()
    else:
        print("无效选择")