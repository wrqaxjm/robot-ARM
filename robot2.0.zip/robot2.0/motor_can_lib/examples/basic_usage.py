"""
电机驱动板CAN指令库基本使用示例

此示例演示如何使用motor_can_lib库来控制电机驱动板
"""

import sys
import os

# 添加库路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from motor_can_lib import MotorCANBase, EnableControlCommand, SpeedControlCommand, StopControlCommand
from motor_can_lib import EnableResponse, SpeedResponse, StopResponse


def demo_basic_usage():
    """演示基本使用"""
    print("=== 电机驱动板CAN指令库使用示例 ===\n")
    
    # 1. 创建CAN通信基础实例
    print("1. 创建CAN通信基础实例")
    can_base = MotorCANBase()
    print("   ✓ CAN通信基础实例创建成功\n")
    
    # 2. 演示使能控制命令构建
    print("2. 演示使能控制命令构建")
    enable_cmd = EnableControlCommand(address=1)
    enable_cmd.set_enable(True, multi_sync=False)  # 启用电机，不启用多机同步
    
    enable_data = enable_cmd.build_command_data()
    print(f"   使能命令数据: {' '.join(f'{b:02X}' for b in enable_data)}")
    print(f"   CAN ID: 0x{enable_cmd.get_can_id():04X}")
    print("   ✓ 使能控制命令构建成功\n")
    
    # 3. 演示速度控制命令构建
    print("3. 演示速度控制命令构建")
    speed_cmd = SpeedControlCommand(address=1)
    speed_cmd.set_direction(1)  # 正向
    speed_cmd.set_speed(1000)   # 速度值
    speed_cmd.set_acceleration(500)  # 加速度
    speed_cmd.set_multi_sync(False)  # 不启用多机同步
    
    speed_data = speed_cmd.build_command_data()
    print(f"   速度命令数据: {' '.join(f'{b:02X}' for b in speed_data)}")
    print(f"   CAN ID: 0x{speed_cmd.get_can_id():04X}")
    print("   ✓ 速度控制命令构建成功\n")
    
    # 4. 演示停止控制命令构建
    print("4. 演示停止控制命令构建")
    stop_cmd = StopControlCommand(address=1)
    stop_cmd.set_multi_sync(False)  # 不启用多机同步
    
    stop_data = stop_cmd.build_command_data()
    print(f"   停止命令数据: {' '.join(f'{b:02X}' for b in stop_data)}")
    print(f"   CAN ID: 0x{stop_cmd.get_can_id():04X}")
    print("   ✓ 停止控制命令构建成功\n")
    
    # 5. 演示响应解析
    print("5. 演示响应解析")
    
    # 模拟成功响应
    enable_response_data = bytes([0x01, 0xF3, 0x02, 0x6B])
    print(f"   模拟使能响应: {' '.join(f'{b:02X}' for b in enable_response_data)}")
    
    try:
        enable_response = EnableResponse.analyze_response(enable_response_data)
        print("   ✓ 使能响应解析成功")
    except Exception as e:
        print(f"   ✗ 使能响应解析失败: {e}")
    
    print("\n=== 示例演示完成 ===")


def demo_advanced_usage():
    """演示高级使用（需要实际CAN设备连接）"""
    print("\n=== 高级使用示例（需要实际设备） ===\n")
    
    print("1. 连接到CAN设备")
    print("   can_base = MotorCANBase()")
    print("   can_base.connect()  # 连接到CAN设备")
    print("   if can_base.is_connected:")
    print("       print('✓ CAN设备连接成功')")
    print("   else:")
    print("       print('✗ CAN设备连接失败')")
    print()
    
    print("2. 执行使能控制命令")
    print("   enable_cmd = EnableControlCommand(address=1)")
    print("   enable_cmd.set_enable(True)")
    print("   response = enable_cmd.execute(can_base, timeout=2.0)")
    print("   if response:")
    print("       EnableResponse.analyze_response(response)")
    print("   else:")
    print("       print('未收到响应')")
    print()
    
    print("3. 执行速度控制命令")
    print("   speed_cmd = SpeedControlCommand(address=1)")
    print("   speed_cmd.set_direction(1).set_speed(1500).set_acceleration(800)")
    print("   response = speed_cmd.execute(can_base, timeout=2.0)")
    print("   if response:")
    print("       SpeedResponse.analyze_response(response)")
    print("   else:")
    print("       print('未收到响应')")
    print()
    
    print("4. 执行停止控制命令")
    print("   stop_cmd = StopControlCommand(address=1)")
    print("   response = stop_cmd.execute(can_base, timeout=2.0)")
    print("   if response:")
    print("       StopResponse.analyze_response(response)")
    print("   else:")
    print("       print('未收到响应')")
    print()
    
    print("5. 断开连接")
    print("   can_base.disconnect()")
    print("   print('✓ CAN设备已断开')")
    print("\n=== 高级示例演示完成 ===")


if __name__ == "__main__":
    # 演示基本使用
    demo_basic_usage()
    
    # 演示高级使用（需要实际设备）
    demo_advanced_usage()