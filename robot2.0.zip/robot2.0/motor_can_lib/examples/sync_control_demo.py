#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多机同步运动控制演示

演示如何使用SyncControlCommand进行多机同步运动控制。

同步运动有两种模式：
1. 广播模式：帧ID为00，直接发送运动指令，所有电机立即运动
2. 指定地址同步：先发送带同步标志的指令，再发送固定同步触发命令

本演示主要展示指定地址同步运动的使用方法。
"""

import sys
import time
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from motor_can_lib import (
    MotorCANBase, CANError, CANTimeoutError,
    PositionControlCommand, SyncControlCommand,
    PositionResponse, SyncResponse
)


def demo_sync_control():
    """演示多机同步运动控制"""
    print("=== 多机同步运动控制演示 ===")
    print()
    
    # 创建CAN通信实例
    can_base = MotorCANBase(com_port="COM11", bitrate=500000, timeout=2.0)
    
    try:
        # 连接CAN设备
        print("1. 连接CAN设备...")
        if not can_base.connect():
            print("✗ CAN设备连接失败")
            return
        print("✓ CAN设备连接成功")
        
        # 演示指定地址同步运动
        print("\n2. 演示指定地址同步运动")
        print("步骤：")
        print("  a) 给地址1电机发送位置命令（启用多机同步）")
        print("  b) 给地址2电机发送位置命令（启用多机同步）")
        print("  c) 发送同步触发命令，让两个电机同时开始运动")
        
        # 步骤a：给地址1电机发送带同步标志的位置命令
        print("\n--- 步骤a：设置地址1电机位置命令（多机同步模式）---")
        motor1_cmd = PositionControlCommand.create_position_command(
            pulse_count=10000,      # 10000脉冲
            direction=0,            # 顺时针
            speed_rpm=1000,         # 1000 RPM
            acceleration=10,        # 加速度档位10
            position_mode=1,        # 相对位置模式
            address=1,              # 地址1
            multi_sync=True         # 启用多机同步
        )
        
        print("发送地址1电机位置命令...")
        response1_data = motor1_cmd.execute(can_base, timeout=2.0)
        if response1_data:
            response1 = PositionResponse(response1_data)
            print(f"地址1响应: {response1.get_status_meaning()}")
        else:
            print("地址1未响应")
        
        time.sleep(0.5)  # 短暂延时
        
        # 步骤b：给地址2电机发送带同步标志的位置命令
        print("\n--- 步骤b：设置地址2电机位置命令（多机同步模式）---")
        motor2_cmd = PositionControlCommand.create_position_command(
            pulse_count=8000,       # 8000脉冲
            direction=1,            # 逆时针
            speed_rpm=800,          # 800 RPM
            acceleration=8,         # 加速度档位8
            position_mode=1,        # 相对位置模式
            address=2,              # 地址2
            multi_sync=True         # 启用多机同步
        )
        
        print("发送地址2电机位置命令...")
        response2_data = motor2_cmd.execute(can_base, timeout=2.0)
        if response2_data:
            response2 = PositionResponse(response2_data)
            print(f"地址2响应: {response2.get_status_meaning()}")
        else:
            print("地址2未响应")
        
        time.sleep(0.5)  # 短暂延时
        
        # 步骤c：发送同步触发命令
        print("\n--- 步骤c：发送同步触发命令 ---")
        print("即将发送固定的同步触发命令：00 FF 66 6B")
        
        sync_cmd = SyncControlCommand.create_sync_command()
        
        print("发送同步触发命令...")
        sync_response_data = sync_cmd.execute(can_base, timeout=2.0)
        
        if sync_response_data:
            sync_response = SyncResponse(sync_response_data)
            print(f"同步触发响应: {sync_response.get_status_description()}")
            
            if sync_response.is_success():
                print("✓ 同步触发成功！地址1和2的电机应该同时开始运动")
            else:
                print(f"✗ 同步触发失败: {sync_response.get_status_description()}")
        else:
            print("✗ 同步触发未收到响应")
        
        print("\n演示完成！")
        
    except (CANError, CANTimeoutError) as e:
        print(f"✗ 演示过程中发生错误: {e}")
    except Exception as e:
        print(f"✗ 发生未知错误: {e}")
    finally:
        # 断开连接
        can_base.disconnect()
        print("CAN设备已断开连接")


def demo_command_data():
    """演示同步控制命令数据格式"""
    print("\n=== 同步控制命令数据格式演示 ===")
    
    # 创建同步触发命令
    sync_cmd = SyncControlCommand.create_sync_command()
    command_data = sync_cmd.build_command_data()
    
    print(f"同步触发命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
    print(f"预期数据: 00 FF 66 6B")
    print(f"CAN ID: 0x{sync_cmd.get_can_id():04X}")
    
    # 验证数据正确性
    expected = bytes([0x00, 0xFF, 0x66, 0x6B])
    if command_data == expected:
        print("✓ 命令数据格式正确")
    else:
        print("✗ 命令数据格式错误")
        print(f"  实际: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  预期: {' '.join(f'{b:02X}' for b in expected)}")


if __name__ == "__main__":
    print("多机同步运动控制演示程序")
    print("=" * 50)
    
    # 演示命令数据格式
    demo_command_data()
    
    print("\n" + "=" * 50)
    
    # 询问是否进行实际演示
    choice = input("是否进行实际的多机同步运动演示? (需要连接CAN设备) (y/N): ").strip().lower()
    if choice in ['y', 'yes', '是']:
        demo_sync_control()
    else:
        print("演示结束")