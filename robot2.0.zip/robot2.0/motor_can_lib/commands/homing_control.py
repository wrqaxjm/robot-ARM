#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
原点回零控制命令

实现电机原点回零相关的控制命令，包括：
- 设置单圈回零的零点位置
- 触发回零
- 强制中断并退出回零操作
- 读取原点回零参数
- 修改原点回零参数
- 读取回零状态标志位
"""

import struct
from typing import Optional, Dict, Any
from ..core.can_base import MotorCANBase
from ..core.exceptions import CANError


class HomingControlCommand:
    """原点回零控制命令类"""
    
    # 命令码定义
    SET_ZERO_POSITION = 0x93        # 设置单圈回零的零点位置
    TRIGGER_HOMING = 0x9A           # 触发回零
    FORCE_STOP_HOMING = 0x9C        # 强制中断并退出回零操作
    READ_HOMING_PARAMS = 0x22       # 读取原点回零参数
    MODIFY_HOMING_PARAMS = 0x4C     # 修改原点回零参数
    READ_HOMING_STATUS = 0x3B       # 读取回零状态标志位
    
    # 回零模式定义
    HOMING_MODE_NEAREST = 0x00      # 单圈就近回零
    HOMING_MODE_DIRECTION = 0x01    # 单圈方向回零
    HOMING_MODE_MULTI_COLLISION = 0x02  # 多圈无限位碰撞回零
    HOMING_MODE_MULTI_LIMIT = 0x03  # 多圈有限位开关回零
    
    # 回零方向定义
    DIRECTION_CW = 0x00             # 顺时针
    DIRECTION_CCW = 0x01            # 逆时针
    
    # 固定校验字节
    CHECKSUM = 0x6B
    
    def __init__(self, address: int = 1):
        """
        初始化原点回零控制命令
        
        Args:
            address: 设备地址，默认为1
        """
        self.address = address
    
    def set_address(self, address: int):
        """设置设备地址"""
        self.address = address
    
    def get_can_id(self) -> int:
        """获取CAN ID
        
        规则：与速度/位置模式保持一致，使用 `(地址 << 8) | 包序号`
        原点回零命令为单包发送，包序号固定为 0，因此：
        - 地址为 0x05 时，CAN ID = 0x0500
        - 广播地址 0x00 时，CAN ID = 0x0000
        """
        return (self.address << 8) | 0
    
    def build_set_zero_position_command(self, save_to_flash: bool = True) -> bytes:
        """
        构建设置单圈回零的零点位置命令
        
        Args:
            save_to_flash: 是否保存到Flash，默认True
            
        Returns:
            命令数据字节
        """
        save_flag = 0x01 if save_to_flash else 0x00
        # 与速度/位置模式一致：地址只在 CAN ID，数据不包含地址
        return bytes([
            self.SET_ZERO_POSITION,  # 命令码 0x93
            0x88,                    # 固定子码/功能位
            save_flag,               # 是否保存到Flash
            self.CHECKSUM            # 固定校验字节 0x6B
        ])
    
    def build_trigger_homing_command(self, homing_mode: int = HOMING_MODE_NEAREST, 
                                   multi_sync: bool = False) -> bytes:
        """
        构建触发回零命令
        
        Args:
            homing_mode: 回零模式
                - 0x00: 单圈就近回零
                - 0x01: 单圈方向回零
                - 0x02: 多圈无限位碰撞回零
                - 0x03: 多圈有限位开关回零
            multi_sync: 多机同步标志，默认False
            
        Returns:
            命令数据字节
        """
        sync_flag = 0x01 if multi_sync else 0x00
        # 地址只在 CAN ID，数据不包含地址
        return bytes([
            self.TRIGGER_HOMING,     # 命令码 0x9A
            homing_mode,             # 回零模式
            sync_flag,               # 多机同步标志
            self.CHECKSUM            # 校验字节
        ])
    
    def build_force_stop_homing_command(self) -> bytes:
        """
        构建强制中断并退出回零操作命令
        
        Returns:
            命令数据字节
        """
        # 地址只在 CAN ID，数据不包含地址
        return bytes([
            self.FORCE_STOP_HOMING,  # 命令码 0x9C
            0x48,                    # 固定子码/功能位
            self.CHECKSUM            # 校验字节
        ])
    
    def build_read_homing_params_command(self) -> bytes:
        """
        构建读取原点回零参数命令
        
        Returns:
            命令数据字节
        """
        # 地址只在 CAN ID，数据不包含地址
        return bytes([
            self.READ_HOMING_PARAMS, # 命令码 0x22
            self.CHECKSUM            # 校验字节
        ])
    
    def build_modify_homing_params_command(self, params: Dict[str, Any], 
                                         save_to_flash: bool = True) -> bytes:
        """
        构建修改原点回零参数命令
        
        Args:
            params: 原点回零参数字典，包含：
                - homing_mode: 回零模式 (0-3)
                - direction: 回零方向 (0: CW, 1: CCW)
                - speed_rpm: 回零速度 (RPM)
                - timeout_ms: 回零超时时间 (ms)
                - collision_speed_rpm: 无限位碰撞回零检测转速 (RPM)
                - collision_current_ma: 无限位碰撞回零检测电流 (mA)
                - collision_time_ms: 无限位碰撞回零检测时间 (ms)
                - auto_homing_enable: 是否使能上电自动触发回零功能
            save_to_flash: 是否保存到Flash，默认True
            
        Returns:
            命令数据字节
        """
        save_flag = 0x01 if save_to_flash else 0x00
        
        # 提取参数，设置默认值
        homing_mode = params.get('homing_mode', self.HOMING_MODE_NEAREST)
        direction = params.get('direction', self.DIRECTION_CW)
        speed_rpm = params.get('speed_rpm', 30)
        timeout_ms = params.get('timeout_ms', 10000)
        collision_speed_rpm = params.get('collision_speed_rpm', 300)
        collision_current_ma = params.get('collision_current_ma', 800)
        collision_time_ms = params.get('collision_time_ms', 60)
        auto_homing_enable = params.get('auto_homing_enable', False)
        
        # 构建参数数据
        param_data = struct.pack('<BBHIHHHB',
            homing_mode,                    # 回零模式 (1字节)
            direction,                      # 回零方向 (1字节)
            speed_rpm,                      # 回零速度 (2字节，小端)
            timeout_ms,                     # 回零超时时间 (4字节，小端)
            collision_speed_rpm,            # 碰撞检测转速 (2字节，小端)
            collision_current_ma,           # 碰撞检测电流 (2字节，小端)
            collision_time_ms,              # 碰撞检测时间 (2字节，小端)
            0x01 if auto_homing_enable else 0x00  # 自动回零使能 (1字节)
        )
        
        # 构建完整命令（注意：该命令长度可能超过8字节，原点模式通常不采用分包，请按设备支持情况使用）
        command = bytes([
            self.MODIFY_HOMING_PARAMS,  # 命令码 0x4C
            0xAE,                       # 固定子码/参数标识
            save_flag                   # 是否保存到Flash
        ]) + param_data + bytes([self.CHECKSUM])
        
        return command
    
    def build_read_homing_status_command(self) -> bytes:
        """
        构建读取回零状态标志位命令
        
        Returns:
            命令数据字节
        """
        # 地址只在 CAN ID，数据不包含地址
        return bytes([
            self.READ_HOMING_STATUS, # 命令码 0x3B
            self.CHECKSUM            # 校验字节
        ])
    
    def execute_set_zero_position(self, can_base: MotorCANBase, save_to_flash: bool = True,
                                timeout: float = 2.0) -> Optional[bytes]:
        """
        执行设置单圈回零的零点位置命令
        
        Args:
            can_base: CAN通信基础类实例
            save_to_flash: 是否保存到Flash
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_set_zero_position_command(save_to_flash)
        
        print(f"发送设置零点位置命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        response_message = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=command_data,
            response_timeout=timeout
        )
        
        # 将返回的bytearray转换为bytes，满足类型注解要求
        response_data = bytes(response_message.data) if response_message else None
        
        if response_data:
            print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        else:
            print("  未收到响应")
        
        return response_data
    
    def execute_trigger_homing(self, can_base: MotorCANBase, 
                             homing_mode: int = HOMING_MODE_NEAREST,
                             multi_sync: bool = False, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行触发回零命令
        
        Args:
            can_base: CAN通信基础类实例
            homing_mode: 回零模式
            multi_sync: 多机同步标志
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_trigger_homing_command(homing_mode, multi_sync)
        
        print(f"发送触发回零命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        response_message = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=command_data,
            response_timeout=timeout
        )
        
        # 将返回的bytearray转换为bytes，满足类型注解要求
        response_data = bytes(response_message.data) if response_message else None
        
        if response_data:
            print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        else:
            print("  未收到响应")
        
        return response_data
    
    def execute_force_stop_homing(self, can_base: MotorCANBase, 
                                timeout: float = 2.0) -> Optional[bytes]:
        """
        执行强制中断并退出回零操作命令
        
        Args:
            can_base: CAN通信基础类实例
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_force_stop_homing_command()
        
        print(f"发送强制停止回零命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        response_message = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=command_data,
            response_timeout=timeout
        )
        
        # 将返回的bytearray转换为bytes，满足类型注解要求
        response_data = bytes(response_message.data) if response_message else None
        
        if response_data:
            print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        else:
            print("  未收到响应")
        
        return response_data
    
    def execute_read_homing_params(self, can_base: MotorCANBase, 
                                 timeout: float = 2.0) -> Optional[bytes]:
        """
        执行读取原点回零参数命令
        
        Args:
            can_base: CAN通信基础类实例
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_read_homing_params_command()
        
        print(f"发送读取回零参数命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        # 读取参数响应可能超过8字节，使用分包接收聚合
        aggregated = can_base.send_and_receive_multi(
            can_id=self.get_can_id(),
            data=command_data,
            expected_command_code=self.READ_HOMING_PARAMS,
            response_timeout=timeout
        )

        if aggregated:
            print(f"  响应数据(聚合): {' '.join(f'{b:02X}' for b in aggregated)}")
        else:
            print("  未收到响应或分包聚合失败")

        return aggregated
    
    def execute_modify_homing_params(self, can_base: MotorCANBase, params: Dict[str, Any],
                                   save_to_flash: bool = True, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行修改原点回零参数命令
        
        Args:
            can_base: CAN通信基础类实例
            params: 原点回零参数字典
            save_to_flash: 是否保存到Flash
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_modify_homing_params_command(params, save_to_flash)
        
        print(f"发送修改回零参数命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        response_message = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=command_data,
            response_timeout=timeout
        )
        
        # 将返回的bytearray转换为bytes，满足类型注解要求
        response_data = bytes(response_message.data) if response_message else None
        
        if response_data:
            print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        else:
            print("  未收到响应")
        
        return response_data
    
    def execute_read_homing_status(self, can_base: MotorCANBase, 
                                 timeout: float = 2.0) -> Optional[bytes]:
        """
        执行读取回零状态标志位命令
        
        Args:
            can_base: CAN通信基础类实例
            timeout: 超时时间
            
        Returns:
            响应数据，如果超时则返回None
        """
        command_data = self.build_read_homing_status_command()
        
        print(f"发送读取回零状态命令:")
        print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  CAN ID: 0x{self.get_can_id():04X}")
        
        response_message = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=command_data,
            response_timeout=timeout
        )
        
        # 将返回的bytearray转换为bytes，满足类型注解要求
        response_data = bytes(response_message.data) if response_message else None
        
        if response_data:
            print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        else:
            print("  未收到响应")
        
        return response_data
    
    @classmethod
    def create_homing_command(cls, address: int = 1) -> 'HomingControlCommand':
        """
        创建原点回零控制命令实例
        
        Args:
            address: 设备地址
            
        Returns:
            HomingControlCommand实例
        """
        return cls(address)


if __name__ == "__main__":
    # 测试代码
    print("=== 原点回零控制命令测试 ===")
    
    # 创建命令实例
    homing_cmd = HomingControlCommand.create_homing_command(address=1)
    
    # 测试各种命令数据构建
    print("\n1. 设置零点位置命令:")
    set_zero_data = homing_cmd.build_set_zero_position_command(save_to_flash=True)
    print(f"   数据: {' '.join(f'{b:02X}' for b in set_zero_data)}")
    print(f"   预期: 93 88 01 6B")
    
    print("\n2. 触发回零命令:")
    trigger_data = homing_cmd.build_trigger_homing_command(
        homing_mode=HomingControlCommand.HOMING_MODE_NEAREST, 
        multi_sync=False
    )
    print(f"   数据: {' '.join(f'{b:02X}' for b in trigger_data)}")
    print(f"   预期: 9A 00 00 6B")
    
    print("\n3. 强制停止回零命令:")
    stop_data = homing_cmd.build_force_stop_homing_command()
    print(f"   数据: {' '.join(f'{b:02X}' for b in stop_data)}")
    print(f"   预期: 9C 48 6B")
    
    print("\n4. 读取回零参数命令:")
    read_params_data = homing_cmd.build_read_homing_params_command()
    print(f"   数据: {' '.join(f'{b:02X}' for b in read_params_data)}")
    print(f"   预期: 22 6B")
    
    print("\n5. 读取回零状态命令:")
    read_status_data = homing_cmd.build_read_homing_status_command()
    print(f"   数据: {' '.join(f'{b:02X}' for b in read_status_data)}")
    print(f"   预期: 3B 6B")
    
    print("\n6. 修改回零参数命令:")
    params = {
        'homing_mode': HomingControlCommand.HOMING_MODE_NEAREST,
        'direction': HomingControlCommand.DIRECTION_CW,
        'speed_rpm': 30,
        'timeout_ms': 10000,
        'collision_speed_rpm': 300,
        'collision_current_ma': 800,
        'collision_time_ms': 60,
        'auto_homing_enable': False
    }
    modify_data = homing_cmd.build_modify_homing_params_command(params, save_to_flash=True)
    print(f"   数据: {' '.join(f'{b:02X}' for b in modify_data)}")
    print(f"   预期: 4C AE 01 00 00 1E 00 00 00 27 10 01 2C 03 20 00 3C 00 6B")