#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
诊断与状态查询命令

根据 `xaxa.md` 文档加入以下读取类命令：
- 0x1F 读取固件版本和硬件版本
- 0x20 读取相电阻与相电感
- 0x21 读取位置环 PID 参数
- 0x24 读取总线电压
- 0x27 读取相电流
- 0x35 读取电机实时转速
- 0x36 读取电机实时位置
- 0x37 读取电机位置误差
- 0x3A 读取电机状态标志位
- 0x42 读取驱动配置参数（带子码 0x6C）
- 0x43 读取系统状态参数（带子码 0x7A）

命令数据不包含地址，地址仅在 CAN ID 中：`CAN ID = (address << 8) | 0`。
校验字节固定为 `0x6B`。
"""

from typing import Optional
from ..core.can_base import MotorCANBase


class DiagnosticCommand:
    """诊断与状态查询命令封装类"""

    CHECKSUM = 0x6B

    # 命令码常量
    READ_FW_HW_VERSION = 0x1F
    READ_PHASE_RES_IND = 0x20
    READ_POSITION_PID = 0x21
    READ_BUS_VOLTAGE = 0x24
    READ_PHASE_CURRENT = 0x27
    READ_MOTOR_SPEED = 0x35
    READ_MOTOR_POSITION = 0x36
    READ_POSITION_ERROR = 0x37
    READ_MOTOR_STATE_FLAGS = 0x3A
    READ_DRIVER_CONFIG = 0x42
    READ_SYSTEM_STATUS = 0x43

    # 子码常量
    SUBCODE_DRIVER_CONFIG = 0x6C
    SUBCODE_SYSTEM_STATUS = 0x7A

    def __init__(self, address: int) -> None:
        """初始化命令实例

        Args:
            address: 设备地址（0-255，0 表示广播地址）
        """
        self.address = address & 0xFF

    @classmethod
    def create(cls, address: int) -> 'DiagnosticCommand':
        """工厂方法，便于创建命令实例"""
        return cls(address)

    def get_can_id(self) -> int:
        """计算 CAN ID：高 8 位为地址，低 8 位为包序号（此类命令固定为 0）"""
        return (self.address << 8) | 0x00

    # ========= 构建各读取命令 =========
    def _simple_cmd(self, code: int) -> bytes:
        """构建简单读取命令：命令码 + 校验"""
        return bytes([code, self.CHECKSUM])

    def build_read_fw_hw_version(self) -> bytes:
        return self._simple_cmd(self.READ_FW_HW_VERSION)

    def build_read_phase_res_ind(self) -> bytes:
        return self._simple_cmd(self.READ_PHASE_RES_IND)

    def build_read_position_pid(self) -> bytes:
        return self._simple_cmd(self.READ_POSITION_PID)

    def build_read_bus_voltage(self) -> bytes:
        return self._simple_cmd(self.READ_BUS_VOLTAGE)

    def build_read_phase_current(self) -> bytes:
        return self._simple_cmd(self.READ_PHASE_CURRENT)

    def build_read_motor_speed(self) -> bytes:
        return self._simple_cmd(self.READ_MOTOR_SPEED)

    def build_read_motor_position(self) -> bytes:
        return self._simple_cmd(self.READ_MOTOR_POSITION)

    def build_read_position_error(self) -> bytes:
        return self._simple_cmd(self.READ_POSITION_ERROR)

    def build_read_motor_state_flags(self) -> bytes:
        return self._simple_cmd(self.READ_MOTOR_STATE_FLAGS)

    def build_read_driver_config(self) -> bytes:
        # 命令码 + 子码 + 校验
        return bytes([self.READ_DRIVER_CONFIG, self.SUBCODE_DRIVER_CONFIG, self.CHECKSUM])

    def build_read_system_status(self) -> bytes:
        # 命令码 + 子码 + 校验
        return bytes([self.READ_SYSTEM_STATUS, self.SUBCODE_SYSTEM_STATUS, self.CHECKSUM])

    # ========= 执行各读取命令 =========
    def _exec_simple(self, can_base: MotorCANBase, data: bytes, timeout: float = 2.0) -> Optional[bytes]:
        """
        通用执行：兼容单包响应；为统一分包逻辑建议优先使用 _exec_multi。
        仍保留以备特殊情况下快速调用。
        """
        resp = can_base.send_and_receive(
            can_id=self.get_can_id(),
            data=data,
            response_timeout=timeout
        )
        return bytes(resp.data) if resp else None

    def _exec_multi(self, can_base: MotorCANBase, data: bytes, expect_code: int, timeout: float = 2.0) -> Optional[bytes]:
        """通用执行：分包响应场景，使用聚合接收返回 bytes 或 None"""
        aggregated = can_base.send_and_receive_multi(
            can_id=self.get_can_id(),
            data=data,
            expected_command_code=expect_code,
            response_timeout=timeout
        )
        return aggregated

    # 单包读取
    def execute_read_fw_hw_version(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        # 统一使用分包聚合，单包也可正确返回
        return self._exec_multi(can_base, self.build_read_fw_hw_version(), self.READ_FW_HW_VERSION, timeout)

    def execute_read_phase_res_ind(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_phase_res_ind(), self.READ_PHASE_RES_IND, timeout)

    def execute_read_position_pid(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        # PID 参数 12 字节 + 校验，超过 8 字节，使用分包聚合接收
        return self._exec_multi(can_base, self.build_read_position_pid(), self.READ_POSITION_PID, timeout)

    def execute_read_bus_voltage(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_bus_voltage(), self.READ_BUS_VOLTAGE, timeout)

    def execute_read_phase_current(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_phase_current(), self.READ_PHASE_CURRENT, timeout)

    def execute_read_motor_speed(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_motor_speed(), self.READ_MOTOR_SPEED, timeout)

    def execute_read_motor_position(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_motor_position(), self.READ_MOTOR_POSITION, timeout)

    def execute_read_position_error(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_position_error(), self.READ_POSITION_ERROR, timeout)

    def execute_read_motor_state_flags(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_motor_state_flags(), self.READ_MOTOR_STATE_FLAGS, timeout)

    # 分包读取（大于8字节）
    def execute_read_driver_config(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_driver_config(), self.READ_DRIVER_CONFIG, timeout)

    def execute_read_system_status(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        return self._exec_multi(can_base, self.build_read_system_status(), self.READ_SYSTEM_STATUS, timeout)


if __name__ == "__main__":
    # 简单自测示例（不与设备通信，仅展示构建数据），请在交互工具中实际执行
    cmd = DiagnosticCommand.create(address=1)
    print("=== 诊断命令构建示例 ===")
    print("读取固件/硬件版本:", ' '.join(f'{b:02X}' for b in cmd.build_read_fw_hw_version()))
    print("读取相电阻/相电感:", ' '.join(f'{b:02X}' for b in cmd.build_read_phase_res_ind()))
    print("读取位置环PID:", ' '.join(f'{b:02X}' for b in cmd.build_read_position_pid()))
    print("读取总线电压:", ' '.join(f'{b:02X}' for b in cmd.build_read_bus_voltage()))
    print("读取相电流:", ' '.join(f'{b:02X}' for b in cmd.build_read_phase_current()))
    print("读取电机转速:", ' '.join(f'{b:02X}' for b in cmd.build_read_motor_speed()))
    print("读取电机位置:", ' '.join(f'{b:02X}' for b in cmd.build_read_motor_position()))
    print("读取位置误差:", ' '.join(f'{b:02X}' for b in cmd.build_read_position_error()))
    print("读取电机状态标志:", ' '.join(f'{b:02X}' for b in cmd.build_read_motor_state_flags()))
    print("读取驱动配置:", ' '.join(f'{b:02X}' for b in cmd.build_read_driver_config()))
    print("读取系统状态:", ' '.join(f'{b:02X}' for b in cmd.build_read_system_status()))