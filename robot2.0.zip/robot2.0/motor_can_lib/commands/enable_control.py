"""
电机使能控制指令

命令格式：地址 + 0xF3 + 0xAB + 使能状态 + 多机同步标志 + 校验字节
"""

from typing import Optional
from ..core.can_base import MotorCANBase
from ..core.exceptions import CANError


class EnableControlCommand:
    """电机使能控制指令类"""
    
    # 指令常量
    COMMAND_CODE = 0xF3  # 使能控制命令码
    COMMAND_SUBCODE = 0xAB  # 使能控制子命令码
    
    def __init__(self, address: int = 1):
        """
        初始化使能控制指令
        
        Args:
            address: 设备地址，默认1
        """
        self.address = address
        self.enable_state = 0  # 默认不使能
        self.multi_machine_sync = 0  # 默认不启用多机同步
    
    def set_enable(self, enable: bool = True, multi_sync: bool = False) -> 'EnableControlCommand':
        """
        设置使能状态
        
        Args:
            enable: 是否使能，True为使能，False为不使能
            multi_sync: 是否启用多机同步
            
        Returns:
            self: 返回自身以支持链式调用
        """
        self.enable_state = 1 if enable else 0
        self.multi_machine_sync = 1 if multi_sync else 0
        return self
    
    def build_command_data(self) -> bytes:
        """构建命令数据字节"""
        # 命令格式: F3 + AB + 使能状态 + 多机同步 + 校验 (地址在CAN ID中，不在数据中)
        data = [
            self.COMMAND_CODE,     # 命令码 F3
            self.COMMAND_SUBCODE,  # 子命令码 AB
            self.enable_state,     # 使能状态 (0/1)
            self.multi_machine_sync,  # 多机同步标志 (0/1)
            0x6B                   # 校验字节
        ]
        
        return bytes(data)
    
    def get_can_id(self) -> int:
        """获取CAN ID"""
        # 单包命令，包序号为0
        return (self.address << 8) | 0
    
    def execute(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行使能控制命令
        
        Args:
            can_base: CAN通信基础实例
            timeout: 超时时间
            
        Returns:
            Optional[bytes]: 响应数据
        """
        if not can_base.is_connected:
            raise CANError("CAN设备未连接")
        
        # 构建命令数据
        command_data = self.build_command_data()
        can_id = self.get_can_id()
        
        print(f"准备发送使能控制命令:")
        print(f"  CAN ID: 0x{can_id:04X}")
        print(f"  数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  功能: {'使能' if self.enable_state else '不使能'}电机")
        print(f"  多机同步: {'启用' if self.multi_machine_sync else '不启用'}")
        
        # 发送命令并等待响应
        try:
            response = can_base.send_and_receive(
                can_id=can_id,
                data=command_data,
                response_timeout=timeout,
                filter_func=lambda msg: msg.arbitration_id == can_id
            )
            
            if response and response.data:
                print(f"✓ 收到响应: {' '.join(f'{b:02X}' for b in response.data)}")
                return bytes(response.data)
            else:
                print("✗ 未收到有效响应")
                return None
                
        except Exception as e:
            print(f"✗ 执行失败: {e}")
            raise
    
    @classmethod
    def create_enable_command(cls, address: int = 1, multi_sync: bool = False) -> 'EnableControlCommand':
        """创建使能命令"""
        return cls(address).set_enable(True, multi_sync)
    
    @classmethod
    def create_disable_command(cls, address: int = 1, multi_sync: bool = False) -> 'EnableControlCommand':
        """创建不使能命令"""
        return cls(address).set_enable(False, multi_sync)


# 示例使用
if __name__ == "__main__":
    # 创建使能控制命令
    enable_cmd = EnableControlCommand(address=1)
    enable_cmd.set_enable(True)  # 使能电机
    
    # 构建命令数据
    command_data = enable_cmd.build_command_data()
    print(f"使能命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
    
    # 创建不使能命令
    disable_cmd = EnableControlCommand.create_disable_command(address=1)
    disable_data = disable_cmd.build_command_data()
    print(f"不使能命令数据: {' '.join(f'{b:02X}' for b in disable_data)}")