"""
速度模式控制指令

命令格式：地址 + 0xF6 + 方向 + 速度 + 加速度 + 多机同步标志 + 校验字节
"""

from typing import Optional, Tuple
from ..core.can_base import MotorCANBase
from ..core.exceptions import CANError


class SpeedControlCommand:
    """速度模式控制指令类"""
    
    # 指令常量
    COMMAND_CODE = 0xF6  # 速度控制命令码
    
    # 方向常量
    DIRECTION_CW = 0x00   # 顺时针方向
    DIRECTION_CCW = 0x01  # 逆时针方向
    
    def __init__(self, address: int = 1):
        """
        初始化速度控制指令
        
        Args:
            address: 设备地址，默认1
        """
        self.address = address
        self.direction = self.DIRECTION_CCW  # 默认逆时针
        self.speed_rpm = 0      # 速度，单位RPM
        self.acceleration = 0   # 加速度档位
        self.multi_machine_sync = 0  # 默认不启用多机同步
    
    def set_direction(self, direction: int) -> 'SpeedControlCommand':
        """
        设置旋转方向
        
        Args:
            direction: 方向 (0=顺时针, 1=逆时针)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if direction not in [self.DIRECTION_CW, self.DIRECTION_CCW]:
            raise ValueError("方向必须是 0(顺时针) 或 1(逆时针)")
        
        self.direction = direction
        return self
    
    def set_speed(self, speed_rpm: int) -> 'SpeedControlCommand':
        """
        设置速度
        
        Args:
            speed_rpm: 速度值，单位RPM
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if speed_rpm < 0:
            raise ValueError("速度不能为负数")
        
        self.speed_rpm = speed_rpm
        return self
    
    def set_acceleration(self, acceleration: int) -> 'SpeedControlCommand':
        """
        设置加速度档位
        
        Args:
            acceleration: 加速度档位 (0-255)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if acceleration < 0 or acceleration > 255:
            raise ValueError("加速度档位必须在 0-255 范围内")
        
        self.acceleration = acceleration
        return self
    
    def set_multi_sync(self, multi_sync: bool = False) -> 'SpeedControlCommand':
        """
        设置多机同步
        
        Args:
            multi_sync: 是否启用多机同步
            
        Returns:
            self: 返回自身以支持链式调用
        """
        self.multi_machine_sync = 1 if multi_sync else 0
        return self
    
    def build_command_data(self) -> bytes:
        """构建命令数据字节"""
        # 将速度值转换为2字节（大端序）
        speed_high = (self.speed_rpm >> 8) & 0xFF
        speed_low = self.speed_rpm & 0xFF
        
        # 命令格式: F6 + 方向 + 速度高 + 速度低 + 加速度 + 多机同步 + 校验 (地址在CAN ID中，不在数据中)
        data = [
            self.COMMAND_CODE,     # 命令码 F6
            self.direction,        # 旋转方向
            speed_high,           # 速度高字节
            speed_low,            # 速度低字节
            self.acceleration,    # 加速度档位
            self.multi_machine_sync,  # 多机同步标志
            0x6B                  # 校验字节
        ]
        
        return bytes(data)
    
    def get_can_id(self) -> int:
        """获取CAN ID"""
        # 单包命令，包序号为0
        return (self.address << 8) | 0
    
    def execute(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行速度控制命令
        
        Args:
            can_base: CAN通信基础实例
            timeout: 超时时间
            
        Returns:
            Optional[bytes]: 响应数据
        """
        if not can_base.is_connected:
            raise CANError("CAN设备未连接")
        
        # 构建命令数据
        command_data = self.build_command_data()
        can_id = self.get_can_id()
        
        print(f"准备发送速度控制命令:")
        print(f"  CAN ID: 0x{can_id:04X}")
        print(f"  数据: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  速度: {self.speed_rpm} RPM")
        print(f"  方向: {'逆时针(CCW)' if self.direction else '顺时针(CW)'}")
        print(f"  加速度档位: {self.acceleration}")
        print(f"  多机同步: {'启用' if self.multi_machine_sync else '不启用'}")
        
        # 发送命令并等待响应
        try:
            response = can_base.send_and_receive(
                can_id=can_id,
                data=command_data,
                response_timeout=timeout,
                filter_func=lambda msg: msg.arbitration_id == can_id
            )
            
            if response and response.data:
                print(f"✓ 收到响应: {' '.join(f'{b:02X}' for b in response.data)}")
                return bytes(response.data)
            else:
                print("✗ 未收到有效响应")
                return None
                
        except Exception as e:
            print(f"✗ 执行失败: {e}")
            raise
    
    @classmethod
    def create_speed_command(cls, speed_rpm: int, direction: int = DIRECTION_CCW, 
                           acceleration: int = 10, address: int = 1, 
                           multi_sync: bool = False) -> 'SpeedControlCommand':
        """
        创建速度控制命令
        
        Args:
            speed_rpm: 速度值 (RPM)
            direction: 方向 (0=顺时针, 1=逆时针)
            acceleration: 加速度档位
            address: 设备地址
            multi_sync: 是否多机同步
            
        Returns:
            SpeedControlCommand: 速度控制命令实例
        """
        return cls(address).set_direction(direction)\
                           .set_speed(speed_rpm)\
                           .set_acceleration(acceleration)\
                           .set_multi_sync(multi_sync)


# 示例使用
if __name__ == "__main__":
    # 创建速度控制命令 - 1500 RPM，逆时针，加速度10
    speed_cmd = SpeedControlCommand(address=1)
    speed_cmd.set_direction(SpeedControlCommand.DIRECTION_CCW)\
             .set_speed(1500)\
             .set_acceleration(10)
    
    # 构建命令数据
    command_data = speed_cmd.build_command_data()
    print(f"速度控制命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
    
    # 使用工厂方法创建命令
    speed_cmd2 = SpeedControlCommand.create_speed_command(
        speed_rpm=2000, 
        direction=SpeedControlCommand.DIRECTION_CW,
        acceleration=5,
        address=2
    )
    command_data2 = speed_cmd2.build_command_data()
    print(f"速度控制命令2数据: {' '.join(f'{b:02X}' for b in command_data2)}")