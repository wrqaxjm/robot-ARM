"""
指令定义模块 - 所有CAN指令的定义

每个指令类负责构建特定功能的CAN消息数据
"""

from .enable_control import EnableControlCommand
from .speed_control import SpeedControlCommand
from .stop_control import StopControlCommand
from .position_control import PositionControlCommand
from .sync_control import SyncControlCommand
from .diagnostic_control import DiagnosticCommand