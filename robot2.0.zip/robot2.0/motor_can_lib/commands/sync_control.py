"""
多机同步运动控制指令

同步运动有两种模式：
1. 广播模式：帧ID为00，直接发送运动指令，所有电机立即运动，只有地址1反馈
2. 指定地址同步：先发送带同步标志的指令到各电机，再发送固定同步命令触发运动

同步触发命令格式：固定为 00 FF 66 6B
命令返回：地址 + 0xFF + 命令状态 + 校验字节
功能说明：触发所有设置了同步标志的电机同时开始运动
"""

from typing import Optional
from ..core.can_base import MotorCANBase
from ..core.exceptions import CANError


class SyncControlCommand:
    """多机同步运动控制指令类"""
    
    # 指令常量 - 固定值，不可更改
    COMMAND_CODE = 0xFF      # 同步控制命令码
    SYNC_TRIGGER = 0x66      # 同步触发字节
    CHECKSUM = 0x6B          # 固定校验字节
    BROADCAST_ADDRESS = 0x00 # 广播地址，固定为0
    
    def __init__(self):
        """
        初始化多机同步运动控制指令
        
        注意：同步触发命令是固定的 00 FF 66 6B，不需要设置地址
        """
        # 同步命令地址固定为0（广播地址）
        self.address = self.BROADCAST_ADDRESS
    
    
    def build_command_data(self) -> bytes:
        """
        构建同步控制命令数据
        
        Returns:
            bytes: 固定的命令数据字节序列 00 FF 66 6B
        """
        # 同步触发命令是固定的：00 FF 66 6B
        return bytes([
            self.BROADCAST_ADDRESS,  # 0x00 - 广播地址
            self.COMMAND_CODE,       # 0xFF - 同步控制命令码
            self.SYNC_TRIGGER,       # 0x66 - 同步触发字节
            self.CHECKSUM            # 0x6B - 固定校验字节
        ])
    
    def get_can_id(self) -> int:
        """
        获取CAN ID
        
        Returns:
            int: CAN ID，固定为0（广播地址）
        """
        return self.BROADCAST_ADDRESS << 8  # 固定为0x0000
    
    def execute(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行多机同步运动命令
        
        Args:
            can_base: CAN通信基础类实例
            timeout: 超时时间，默认2秒
            
        Returns:
            Optional[bytes]: 响应数据，如果失败返回None
            
        Note:
            - 同步触发命令固定为 00 FF 66 6B
            - 只有地址为1的电机会回复响应
            - 所有设置了同步标志的电机会同时开始运动
        """
        try:
            # 构建固定的同步触发命令
            command_data = self.build_command_data()
            
            print(f"发送多机同步运动命令:")
            print(f"  命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
            print(f"  CAN ID: 0x{self.get_can_id():04X}")
            
            # 发送命令并接收响应
            response_message = can_base.send_and_receive(
                can_id=self.get_can_id(),
                data=command_data,
                response_timeout=timeout
            )
            
            # 提取响应数据
            response_data = response_message.data if response_message else None
            
            if response_data:
                print(f"  响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
            else:
                print("  未收到响应")
            
            return bytes(response_data) if response_data else None
            
        except Exception as e:
            print(f"同步运动命令执行失败: {e}")
            raise CANError(f"同步运动命令执行失败: {e}")
    
    @classmethod
    def create_sync_command(cls) -> 'SyncControlCommand':
        """
        创建同步运动触发命令
        
        Returns:
            SyncControlCommand: 同步控制命令实例
            
        Note:
            同步触发命令是固定的，不需要参数
        """
        return cls()


if __name__ == "__main__":
    # 测试同步控制命令
    print("=== 多机同步运动命令测试 ===")
    
    # 创建同步触发命令
    sync_cmd = SyncControlCommand.create_sync_command()
    command_data = sync_cmd.build_command_data()
    print(f"同步触发命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
    print(f"预期数据: 00 FF 66 6B")
    print(f"CAN ID: 0x{sync_cmd.get_can_id():04X}")
    
    # 验证命令数据
    expected = bytes([0x00, 0xFF, 0x66, 0x6B])
    if command_data == expected:
        print("✓ 命令数据正确")
    else:
        print("✗ 命令数据错误")
        print(f"  实际: {' '.join(f'{b:02X}' for b in command_data)}")
        print(f"  预期: {' '.join(f'{b:02X}' for b in expected)}")