"""
位置模式控制指令

命令格式：地址 + 0xFD + 方向 + 速度 + 加速度 + 脉冲数 + 相对/绝对模式标志 + 多机同步标志 + 校验字节
"""

from typing import Optional, Tuple
from ..core.can_base import MotorCANBase
from ..core.exceptions import CANError


class PositionControlCommand:
    """位置模式控制指令类"""
    
    # 指令常量
    COMMAND_CODE = 0xFD  # 位置控制命令码
    
    # 方向常量
    DIRECTION_CW = 0x00   # 顺时针方向
    DIRECTION_CCW = 0x01  # 逆时针方向
    
    # 位置模式常量
    MODE_RELATIVE = 0x00  # 相对位置模式
    MODE_ABSOLUTE = 0x01  # 绝对位置模式
    
    def __init__(self, address: int = 1, subdivision: int = 16):
        """
        初始化位置控制指令
        
        Args:
            address: 设备地址，默认1
            subdivision: 细分数，默认16（可配置，不写死）
        """
        self.address = address
        self.subdivision = subdivision  # 细分数，用于角度到脉冲的转换
        self.direction = self.DIRECTION_CCW  # 默认逆时针
        self.speed_rpm = 1500    # 速度，单位RPM，默认1500
        self.acceleration = 0    # 加速度档位，默认0
        self.pulse_count = 0     # 脉冲数
        self.position_mode = self.MODE_RELATIVE  # 默认相对位置模式
        self.multi_machine_sync = 0  # 默认不启用多机同步
    
    def set_direction(self, direction: int) -> 'PositionControlCommand':
        """
        设置旋转方向
        
        Args:
            direction: 方向 (0=顺时针, 1=逆时针)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if direction not in [self.DIRECTION_CW, self.DIRECTION_CCW]:
            raise ValueError("方向必须是 0(顺时针) 或 1(逆时针)")
        
        self.direction = direction
        return self
    
    def set_speed(self, speed_rpm: int) -> 'PositionControlCommand':
        """
        设置运动速度
        
        Args:
            speed_rpm: 速度，单位RPM (1-3000)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if not (1 <= speed_rpm <= 3000):
            raise ValueError("速度必须在 1-3000 RPM 范围内")
        
        self.speed_rpm = speed_rpm
        return self
    
    def set_acceleration(self, acceleration: int) -> 'PositionControlCommand':
        """
        设置加速度档位
        
        Args:
            acceleration: 加速度档位 (0-255)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if not (0 <= acceleration <= 255):
            raise ValueError("加速度档位必须在 0-255 范围内")
        
        self.acceleration = acceleration
        return self
    
    def set_pulse_count(self, pulse_count: int) -> 'PositionControlCommand':
        """
        设置脉冲数
        
        Args:
            pulse_count: 脉冲数 (0-4294967295，32位无符号整数)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if not (0 <= pulse_count <= 0xFFFFFFFF):
            raise ValueError("脉冲数必须在 0-4294967295 范围内")
        
        self.pulse_count = pulse_count
        return self
    
    def set_angle_degrees(self, angle_degrees: float) -> 'PositionControlCommand':
        """
        通过角度设置脉冲数（1.8度步进电机）
        
        Args:
            angle_degrees: 角度，单位度
            
        Returns:
            self: 返回自身以支持链式调用
        """
        # 1.8度步进电机，一圈200步
        # 考虑细分：一圈的脉冲数 = 200 * subdivision
        steps_per_revolution = 200 * self.subdivision
        pulse_count = int(abs(angle_degrees) / 360.0 * steps_per_revolution)
        
        # 根据角度正负设置方向
        if angle_degrees < 0:
            self.direction = self.DIRECTION_CW  # 负角度为顺时针
        else:
            self.direction = self.DIRECTION_CCW  # 正角度为逆时针
        
        return self.set_pulse_count(pulse_count)
    
    def set_revolutions(self, revolutions: float) -> 'PositionControlCommand':
        """
        通过转数设置脉冲数
        
        Args:
            revolutions: 转数
            
        Returns:
            self: 返回自身以支持链式调用
        """
        # 一圈的脉冲数 = 200 * subdivision
        steps_per_revolution = 200 * self.subdivision
        pulse_count = int(abs(revolutions) * steps_per_revolution)
        
        # 根据转数正负设置方向
        if revolutions < 0:
            self.direction = self.DIRECTION_CW  # 负转数为顺时针
        else:
            self.direction = self.DIRECTION_CCW  # 正转数为逆时针
        
        return self.set_pulse_count(pulse_count)
    
    def set_position_mode(self, mode: int) -> 'PositionControlCommand':
        """
        设置位置模式
        
        Args:
            mode: 位置模式 (0=相对位置, 1=绝对位置)
            
        Returns:
            self: 返回自身以支持链式调用
        """
        if mode not in [self.MODE_RELATIVE, self.MODE_ABSOLUTE]:
            raise ValueError("位置模式必须是 0(相对位置) 或 1(绝对位置)")
        
        self.position_mode = mode
        return self
    
    def set_multi_sync(self, multi_sync: bool = False) -> 'PositionControlCommand':
        """
        设置多机同步标志
        
        Args:
            multi_sync: 是否启用多机同步
            
        Returns:
            self: 返回自身以支持链式调用
        """
        self.multi_machine_sync = 1 if multi_sync else 0
        return self
    
    def build_command_data(self) -> bytes:
        """
        构建位置控制命令数据
        
        Returns:
            bytes: 命令数据字节
        """
        # 命令格式：地址 + 0xFD + 方向 + 速度 + 加速度 + 脉冲数 + 相对/绝对模式标志 + 多机同步标志 + 校验字节
        
        # 速度转换为2字节（大端序）
        speed_bytes = self.speed_rpm.to_bytes(2, byteorder='big')
        
        # 脉冲数转换为4字节（大端序）
        pulse_bytes = self.pulse_count.to_bytes(4, byteorder='big')
        
        # 构建数据部分（不包含地址和校验）
        data = bytearray([
            self.COMMAND_CODE,      # 命令码 0xFD
            self.direction,         # 方向
            speed_bytes[0],         # 速度高字节
            speed_bytes[1],         # 速度低字节
            self.acceleration,      # 加速度
            pulse_bytes[0],         # 脉冲数字节3（最高位）
            pulse_bytes[1],         # 脉冲数字节2
            pulse_bytes[2],         # 脉冲数字节1
            pulse_bytes[3],         # 脉冲数字节0（最低位）
            self.position_mode,     # 相对/绝对模式标志
            self.multi_machine_sync # 多机同步标志
        ])
        
        # 计算校验字节：地址 + 数据的累加和的低字节
        checksum = (self.address + sum(data)) & 0xFF
        
        # 完整命令：地址 + 数据 + 校验
        command = bytearray([self.address]) + data + bytearray([checksum])
        
        return bytes(command)
    
    def get_can_id(self) -> int:
        """
        获取CAN ID
        
        Returns:
            int: CAN ID
        """
        return 0x0500  # 使用标准的CAN ID
    
    def execute(self, can_base: MotorCANBase, timeout: float = 2.0) -> Optional[bytes]:
        """
        执行位置控制命令（支持分包发送）
        
        Args:
            can_base: CAN通信基础类实例
            timeout: 超时时间，默认2秒
            
        Returns:
            Optional[bytes]: 响应数据，如果失败返回None
        """
        try:
            # 构建命令数据
            command_data = self.build_command_data()
            
            # 检查数据长度是否超过8字节
            if len(command_data) <= 8:
                # 单包发送
                response = can_base.send_and_receive(
                    can_id=self.get_can_id(),
                    data=command_data,
                    response_timeout=timeout,
                    filter_func=lambda msg: msg.arbitration_id == self.get_can_id()
                )
                
                if response is not None:
                    return bytes(response.data)
                else:
                    return None
            else:
                # 分包发送（大于8字节的位置控制命令）
                return self._execute_multi_packet(can_base, command_data, timeout)
                
        except Exception as e:
            print(f"位置控制命令执行失败: {e}")
            return None
    
    def _execute_multi_packet(self, can_base: MotorCANBase, command_data: bytes, timeout: float) -> Optional[bytes]:
        """
        执行分包发送的位置控制命令
        
        Args:
            can_base: CAN通信基础类实例
            command_data: 完整的命令数据
            timeout: 超时时间
            
        Returns:
            Optional[bytes]: 响应数据，如果失败返回None
        """
        try:
            # 按照调试文档的分包方式
            # 包1: 从命令码开始的8字节，CAN ID为(地址 << 8) + 0x00
            # 包2: 剩余数据 + 固定校验字节0x6B，CAN ID为(地址 << 8) + 0x01
            
            # 包1: 从命令码开始的8字节（不包含地址）
            packet1 = command_data[1:9]   # FD 01 05 DC 00 00 00 7D
            
            # 包2: 剩余数据字节 + 固定校验字节0x6B
            remaining_data = command_data[9:12]  # 位置模式、多机同步等
            packet2 = bytes([command_data[1]]) + remaining_data + bytes([0x6B])  # FD + 剩余数据 + 0x6B
            
            # 根据设备地址计算CAN ID：(地址 << 8) + 包序号
            base_can_id = (self.address << 8)  # 使用实际的设备地址
            
            print(f"分包发送位置控制命令:")
            print(f"  包1 (CAN ID: 0x{base_can_id:04X}): {' '.join(f'{b:02X}' for b in packet1)}")
            print(f"  包2 (CAN ID: 0x{base_can_id + 1:04X}): {' '.join(f'{b:02X}' for b in packet2)}")
            
            # 发送第一包
            import can
            message1 = can.Message(
                arbitration_id=base_can_id,
                data=packet1,
                is_extended_id=True
            )
            if can_base.bus is not None:
                can_base.bus.send(message1, timeout=1.0)
            else:
                raise CANError("CAN总线未连接")
            
            # 发送第二包
            message2 = can.Message(
                arbitration_id=base_can_id + 1,
                data=packet2,
                is_extended_id=True
            )
            if can_base.bus is not None:
                can_base.bus.send(message2, timeout=1.0)
            else:
                raise CANError("CAN总线未连接")
            
            # 等待响应（使用标准的位置控制响应CAN ID）
            if can_base.bus is not None:
                response = can_base.bus.recv(timeout=timeout)
            else:
                raise CANError("CAN总线未连接")
            
            if response is not None:
                print(f"收到响应: CAN ID=0x{response.arbitration_id:08X}, 数据={' '.join(f'{b:02X}' for b in response.data)}")
                return bytes(response.data)
            else:
                print("未收到响应")
                return None
                
        except Exception as e:
            print(f"分包发送失败: {e}")
            return None
    
    @classmethod
    def create_position_command(cls, pulse_count: int, direction: int = DIRECTION_CCW, 
                              speed_rpm: int = 1500, acceleration: int = 0, 
                              position_mode: int = MODE_RELATIVE, address: int = 1, 
                              subdivision: int = 16, multi_sync: bool = False) -> 'PositionControlCommand':
        """
        创建位置控制命令的便捷方法
        
        Args:
            pulse_count: 脉冲数
            direction: 方向 (0=顺时针, 1=逆时针)
            speed_rpm: 速度，单位RPM
            acceleration: 加速度档位
            position_mode: 位置模式 (0=相对位置, 1=绝对位置)
            address: 设备地址
            subdivision: 细分数
            multi_sync: 是否启用多机同步
            
        Returns:
            PositionControlCommand: 配置好的位置控制命令实例
        """
        cmd = cls(address=address, subdivision=subdivision)
        cmd.set_direction(direction)\
           .set_speed(speed_rpm)\
           .set_acceleration(acceleration)\
           .set_pulse_count(pulse_count)\
           .set_position_mode(position_mode)\
           .set_multi_sync(multi_sync)
        
        return cmd
    
    @classmethod
    def create_angle_command(cls, angle_degrees: float, speed_rpm: int = 1500, 
                           acceleration: int = 0, position_mode: int = MODE_RELATIVE, 
                           address: int = 1, subdivision: int = 16, 
                           multi_sync: bool = False) -> 'PositionControlCommand':
        """
        创建基于角度的位置控制命令
        
        Args:
            angle_degrees: 角度，单位度（正数逆时针，负数顺时针）
            speed_rpm: 速度，单位RPM
            acceleration: 加速度档位
            position_mode: 位置模式 (0=相对位置, 1=绝对位置)
            address: 设备地址
            subdivision: 细分数
            multi_sync: 是否启用多机同步
            
        Returns:
            PositionControlCommand: 配置好的位置控制命令实例
        """
        cmd = cls(address=address, subdivision=subdivision)
        cmd.set_angle_degrees(angle_degrees)\
           .set_speed(speed_rpm)\
           .set_acceleration(acceleration)\
           .set_position_mode(position_mode)\
           .set_multi_sync(multi_sync)
        
        return cmd


if __name__ == "__main__":
    # 测试位置控制命令
    print("=== 位置控制命令测试 ===")
    
    # 测试1：基本脉冲控制
    pos_cmd = PositionControlCommand(address=1, subdivision=16)
    pos_cmd.set_direction(PositionControlCommand.DIRECTION_CCW)\
           .set_speed(1500)\
           .set_acceleration(0)\
           .set_pulse_count(32000)\
           .set_position_mode(PositionControlCommand.MODE_RELATIVE)
    
    command_data = pos_cmd.build_command_data()
    print(f"位置控制命令数据: {' '.join(f'{b:02X}' for b in command_data)}")
    
    # 测试2：角度控制（转10圈）
    angle_cmd = PositionControlCommand.create_angle_command(
        angle_degrees=3600,  # 10圈 = 3600度
        speed_rpm=1500,
        acceleration=0,
        address=1,
        subdivision=16
    )
    command_data2 = angle_cmd.build_command_data()
    print(f"角度控制命令数据: {' '.join(f'{b:02X}' for b in command_data2)}")
    
    # 测试3：转数控制
    rev_cmd = PositionControlCommand(address=1, subdivision=16)
    rev_cmd.set_revolutions(10.0)\
           .set_speed(1500)\
           .set_acceleration(0)\
           .set_position_mode(PositionControlCommand.MODE_RELATIVE)
    
    command_data3 = rev_cmd.build_command_data()
    print(f"转数控制命令数据: {' '.join(f'{b:02X}' for b in command_data3)}")
    
    # 验证脉冲数计算
    print(f"\n=== 脉冲数计算验证 ===")
    print(f"16细分下，10圈脉冲数: {10 * 200 * 16} = {rev_cmd.pulse_count}")