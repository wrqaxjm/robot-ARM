# 电机驱动板CAN指令封装库

一个结构清晰的Python库，用于控制基于CAN通信的电机驱动板。

## 特性

- 🚀 **模块化设计**: 指令定义和响应解析分离，便于维护和扩展
- 📦 **易于使用**: 简洁的API设计，快速上手
- 🔧 **类型安全**: 完整的类型注解，更好的开发体验
- 🛡️ **错误处理**: 完善的异常处理机制
- 📚 **详细文档**: 完整的示例和使用说明

## 安装

将 `motor_can_lib` 文件夹复制到您的项目目录中，或添加到Python路径中。

```bash
# 将库添加到Python路径
import sys
sys.path.insert(0, '/path/to/motor_can_lib')
```

## 快速开始

### 基本使用

```python
from motor_can_lib import MotorCANBase, EnableControlCommand, SpeedControlCommand
from motor_can_lib import EnableResponse, SpeedResponse

# 创建CAN通信实例
can_base = MotorCANBase()

# 连接到CAN设备
can_base.connect_device("COM3", 115200)

# 创建使能控制命令
enable_cmd = EnableControlCommand(address=1)
enable_cmd.set_enable(True)  # 启用电机

# 执行命令并获取响应
response = enable_cmd.execute(can_base, timeout=2.0)

# 解析响应
if response:
    enable_response = EnableResponse.analyze_response(response)
    print(f"使能控制结果: {'成功' if enable_response.is_success() else '失败'}")

# 断开连接
can_base.disconnect_device()
```

### 完整控制流程

```python
from motor_can_lib import MotorCANBase, EnableControlCommand, SpeedControlCommand, StopControlCommand

# 创建控制器实例
can_base = MotorCANBase()
can_base.connect_device("COM3", 115200)

# 1. 启用电机
enable_cmd = EnableControlCommand(1).set_enable(True)
enable_cmd.execute(can_base)

# 2. 设置速度
speed_cmd = SpeedControlCommand(1)
speed_cmd.set_direction(1).set_speed(1500).set_acceleration(800)
speed_cmd.execute(can_base)

# 3. 停止电机
stop_cmd = StopControlCommand(1)
stop_cmd.execute(can_base)

# 4. 禁用电机
enable_cmd.set_enable(False)
enable_cmd.execute(can_base)

can_base.disconnect_device()
```

## 库结构

```
motor_can_lib/
├── __init__.py          # 库主入口
├── core/                # 核心模块
│   ├── __init__.py
│   ├── can_base.py     # CAN通信基础类
│   └── exceptions.py   # 异常类定义
├── commands/            # 指令定义模块
│   ├── __init__.py
│   ├── enable_control.py    # 使能控制指令
│   ├── speed_control.py    # 速度控制指令
│   └── stop_control.py     # 停止控制指令
├── responses/           # 响应解析模块
│   ├── __init__.py
│   ├── enable_response.py  # 使能控制响应
│   ├── speed_response.py   # 速度控制响应
│   └── stop_response.py    # 停止控制响应
├── examples/            # 使用示例
│   ├── basic_usage.py      # 基本使用示例
│   └── motor_control_demo.py # 完整控制演示
└── docs/                # 文档
    └── README.md        # 使用说明
```

## 支持的指令

### 1. 电机使能控制
- **命令码**: 0xF3
- **子命令码**: 0xAB
- **功能**: 启用或禁用电机
- **数据格式**: 地址 + F3 + AB + 使能状态 + 多机同步 + 校验

### 2. 速度模式控制
- **命令码**: 0xF6
- **功能**: 设置电机速度、方向、加速度
- **数据格式**: 地址 + F6 + 方向 + 速度 + 加速度 + 多机同步 + 校验

### 3. 立即停止控制
- **命令码**: 0xFE
- **子命令码**: 0x98
- **功能**: 立即停止电机运行
- **数据格式**: 地址 + FE + 98 + 多机同步 + 校验

## 响应状态码

### 通用状态码
- `0x02`: 命令正确执行
- `0xE2`: 条件不满足
- `0xEE`: 错误命令

## 异常处理

库提供了完善的异常处理机制：

```python
from motor_can_lib.core.exceptions import CANError, CANTimeoutError, CANCommandError

try:
    # 执行CAN命令
    response = command.execute(can_base)
    
except CANTimeoutError:
    print("命令执行超时")
    
except CANCommandError as e:
    print(f"命令执行错误: {e}")
    
except CANError as e:
    print(f"CAN通信错误: {e}")
```

## 示例代码

查看 `examples/` 目录获取完整的使用示例：

- `basic_usage.py`: 基本使用示例
- `motor_control_demo.py`: 完整控制流程演示

## 开发指南

### 添加新指令

1. 在 `commands/` 目录创建新指令类
2. 在 `responses/` 目录创建对应的响应解析类
3. 更新相应的 `__init__.py` 文件
4. 添加使用示例

### 指令类规范

每个指令类应包含：
- `build_command_data()`: 构建命令数据
- `get_can_id()`: 获取CAN ID
- `execute()`: 执行命令
- 相应的设置方法

### 响应类规范

每个响应类应包含：
- `parse_response()`: 解析响应数据
- `is_success()`: 检查是否成功
- `get_status_meaning()`: 获取状态含义
- `analyze_response()`: 分析响应（类方法）

## 版本信息

- **版本**: 1.0.0
- **作者**: 电机驱动板开发团队
- **最后更新**: 2024年

## 支持与反馈

如有问题或建议，请提交Issue或联系开发团队。

## 许可证

MIT License

---

**注意**: 使用前请确保CAN设备正确连接，并根据实际情况修改串口参数。