"""
多机同步运动控制响应解析

响应格式（新）：0xFF + 命令状态 + 校验字节（地址不在数据中，来源于 CAN ID）
命令状态说明：
- 0x02: 命令执行成功
- 0xE2: 条件不满足（触发了堵转保护、电机没使能）
- 0xEE: 错误命令
"""

from typing import Optional, Dict, Any
from enum import Enum


class SyncStatus(Enum):
    """同步命令状态枚举"""
    SUCCESS = 0x02          # 命令执行成功
    CONDITION_NOT_MET = 0xE2  # 条件不满足
    INVALID_COMMAND = 0xEE    # 错误命令


class SyncResponse:
    """多机同步运动控制响应类（仅支持新格式）"""
    
    def __init__(self, raw_data: bytes, address: Optional[int] = None):
        """
        初始化同步响应（新格式）
        
        Args:
            raw_data: 原始响应数据（FF + 状态 + 校验）
            address: 设备地址（来源于 CAN ID，仅用于显示）
        """
        self.raw_data = raw_data
        self.address: Optional[int] = address if address is not None else 0
        self.command_code: Optional[int] = None
        self.status: Optional[SyncStatus] = None
        self.checksum: Optional[int] = None
        self.is_valid = False
        self.error_message = ""
        
        self._parse_response()
    
    def _parse_response(self) -> None:
        """解析响应数据"""
        try:
            if len(self.raw_data) != 3:
                self.error_message = f"响应数据长度错误，期望3字节，实际{len(self.raw_data)}字节"
                return
            
            # 解析各字段
            self.command_code = self.raw_data[0]
            status_byte = self.raw_data[1]
            self.checksum = self.raw_data[2]
            
            # 验证命令码
            if self.command_code != 0xFF:
                self.error_message = f"命令码错误，期望0xFF，实际0x{self.command_code:02X}"
                return
            
            # 解析状态
            try:
                self.status = SyncStatus(status_byte)
            except ValueError:
                self.error_message = f"未知的状态码: 0x{status_byte:02X}"
                return
            
            # 验证校验和
            calculated_checksum = (self.command_code + status_byte) & 0xFF
            if self.checksum != calculated_checksum:
                self.error_message = f"校验和错误，期望0x{calculated_checksum:02X}，实际0x{self.checksum:02X}"
                return
            
            self.is_valid = True
            
        except Exception as e:
            self.error_message = f"解析响应时发生异常: {e}"
    
    def is_success(self) -> bool:
        """
        检查命令是否执行成功
        
        Returns:
            bool: True表示成功，False表示失败
        """
        return self.is_valid and self.status == SyncStatus.SUCCESS
    
    def get_status_description(self) -> str:
        """
        获取状态描述
        
        Returns:
            str: 状态描述文本
        """
        if not self.is_valid:
            return f"响应无效: {self.error_message}"
        
        if self.status is None:
            return "未知状态"
            
        status_descriptions = {
            SyncStatus.SUCCESS: "命令执行成功",
            SyncStatus.CONDITION_NOT_MET: "条件不满足（触发了堵转保护或电机没使能）",
            SyncStatus.INVALID_COMMAND: "错误命令"
        }
        
        return status_descriptions.get(self.status, f"未知状态: {self.status}")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将响应转换为字典格式
        
        Returns:
            Dict[str, Any]: 响应信息字典
        """
        return {
            "raw_data": self.raw_data.hex().upper(),
            "address": self.address,
            "command_code": f"0x{self.command_code:02X}" if self.command_code is not None else None,
            "status": self.status.name if self.status is not None else None,
            "status_value": f"0x{self.status.value:02X}" if self.status is not None else None,
            "checksum": f"0x{self.checksum:02X}" if self.checksum is not None else None,
            "is_valid": self.is_valid,
            "is_success": self.is_success(),
            "status_description": self.get_status_description(),
            "error_message": self.error_message if self.error_message else None
        }
    
    def __str__(self) -> str:
        """字符串表示"""
        if not self.is_valid:
            return f"SyncResponse(无效响应: {self.error_message})"
        
        status_name = self.status.name if self.status is not None else "未知"
        return (f"SyncResponse(地址={self.address}, "
                f"状态={status_name}, "
                f"描述='{self.get_status_description()}')")
    
    def __repr__(self) -> str:
        """详细字符串表示"""
        return (f"SyncResponse(raw_data={self.raw_data.hex()}, "
                f"address={self.address}, "
                f"status={self.status}, "
                f"is_valid={self.is_valid})")


def parse_sync_response(raw_data: bytes, address: Optional[int] = None) -> SyncResponse:
    """
    解析同步响应数据的便捷函数
    
    Args:
        raw_data: 原始响应数据
        address: 设备地址（来源于 CAN ID，用于显示）
        
    Returns:
        SyncResponse: 解析后的响应对象
    """
    return SyncResponse(raw_data, address=address)


if __name__ == "__main__":
    # 测试代码
    print("=== 多机同步运动响应解析测试 ===")
    
    # 测试成功响应（新格式：FF 02 01 => 校验=FF+02=0x01）
    success_data = bytes([0xFF, 0x02, 0x01])
    success_response = SyncResponse(success_data, address=0x01)
    print(f"成功响应: {success_response}")
    print(f"详细信息: {success_response.to_dict()}")
    
    # 测试条件不满足响应（FF E2 E1 => 校验=FF+E2=0x1E1，低字节=0xE1）
    condition_data = bytes([0xFF, 0xE2, 0xE1])
    condition_response = SyncResponse(condition_data, address=0x01)
    print(f"\n条件不满足响应: {condition_response}")
    
    # 测试错误命令响应（命令码非 0xFF）
    error_data = bytes([0x00, 0xEE, 0xEF])
    error_response = SyncResponse(error_data, address=0x01)
    print(f"\n错误命令响应: {error_response}")
    
    # 测试无效数据
    invalid_data = bytes([0xFF])  # 数据长度不足
    invalid_response = SyncResponse(invalid_data, address=0x01)
    print(f"\n无效响应: {invalid_response}")