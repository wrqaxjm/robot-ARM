"""
位置模式控制响应解析

命令返回格式：地址 + 0xFD + 命令状态 + 校验字节
响应状态说明：
- 0x02: 命令正确执行
- 0xE2: 条件不满足（如堵转保护、电机没使能）
- 0xEE: 错误命令
"""

from typing import Optional, Dict
from ..core.exceptions import CANResponseError, CANCommandError


class PositionResponse:
    """位置模式控制响应解析类"""
    
    # 响应状态码
    STATUS_SUCCESS = 0x02      # 命令正确执行
    STATUS_CONDITION_FAIL = 0xE2  # 条件不满足
    STATUS_COMMAND_ERROR = 0xEE  # 错误命令
    
    # 状态码含义映射
    STATUS_MEANINGS = {
        STATUS_SUCCESS: "命令正确执行",
        STATUS_CONDITION_FAIL: "条件不满足（堵转保护或电机没使能）",
        STATUS_COMMAND_ERROR: "错误命令"
    }
    
    def __init__(self, response_data: bytes):
        """
        初始化响应解析
        
        Args:
            response_data: 响应数据字节
        """
        self.response_data = response_data
        self.command_code: Optional[int] = None
        self.status_code: Optional[int] = None
        self.checksum: Optional[int] = None
        
        self.parse_response()
    
    def parse_response(self):
        """解析响应数据"""
        if not self.response_data or len(self.response_data) < 3:
            raise CANResponseError("响应数据长度不足", self.response_data)
        
        # 解析响应格式: FD + 状态 + 校验 (地址在CAN ID中，不在数据中)
        self.command_code = self.response_data[0]
        self.status_code = self.response_data[1]
        self.checksum = self.response_data[2]
        
        # 验证命令码
        if self.command_code != 0xFD:
            raise CANResponseError(f"响应命令码不匹配，期望 0xFD，实际 0x{self.command_code:02X}", 
                                 self.response_data)
        
        # 验证状态码
        if self.status_code not in self.STATUS_MEANINGS:
            raise CANResponseError(f"未知的响应状态码: 0x{self.status_code:02X}", 
                                 self.response_data)
    
    def is_success(self) -> bool:
        """检查命令是否执行成功"""
        return self.status_code == self.STATUS_SUCCESS
    
    def get_status_meaning(self) -> str:
        """获取状态码含义"""
        if self.status_code is None:
            return "未知状态码"
        return self.STATUS_MEANINGS.get(self.status_code, f"未知状态码: 0x{self.status_code:02X}")
    
    def check_status(self) -> bool:
        """
        检查响应状态，如果不成功则抛出异常
        
        Returns:
            bool: 成功返回True
            
        Raises:
            CANCommandError: 命令执行失败时抛出
        """
        if not self.is_success():
            command_code = self.command_code if self.command_code is not None else 0xFD
            error_code = self.status_code if self.status_code is not None else 0xFF
            raise CANCommandError(command_code, error_code)
        return True
    
    def get_summary(self) -> Dict:
        """
        获取响应摘要信息
        
        Returns:
            Dict: 包含响应详细信息的字典
        """
        return {
            "command_code": f"0x{self.command_code:02X}",
            "status_code": f"0x{self.status_code:02X}",
            "status_meaning": self.get_status_meaning(),
            "is_success": self.is_success(),
            "checksum": f"0x{self.checksum:02X}",
            "raw_data": ' '.join(f'{b:02X}' for b in self.response_data)
        }
    
    def print_summary(self):
        """打印响应摘要"""
        summary = self.get_summary()
        print(f"位置控制响应摘要:")
        print(f"  命令码: {summary['command_code']}")
        print(f"  状态码: {summary['status_code']}")
        print(f"  状态含义: {summary['status_meaning']}")
        print(f"  执行成功: {summary['is_success']}")
        print(f"  校验字节: {summary['checksum']}")
        print(f"  原始数据: {summary['raw_data']}")
    
    @classmethod
    def analyze_response(cls, response_data: bytes) -> 'PositionResponse':
        """
        分析响应数据的便捷方法
        
        Args:
            response_data: 响应数据字节
            
        Returns:
            PositionResponse: 解析后的响应对象
        """
        return cls(response_data)


if __name__ == "__main__":
    # 测试位置控制响应解析
    print("=== 位置控制响应解析测试 ===")
    
    # 测试数据（基于文档示例）
    test_responses = [
        bytes([0xFD, 0x02, 0x6B]),  # 成功：01 FD 02 6B -> FD 02 6B (地址在CAN ID中)
        bytes([0xFD, 0xE2, 0x6B]),  # 条件不满足：01 FD E2 6B -> FD E2 6B
        bytes([0xFD, 0xEE, 0x6B]),  # 错误命令：01 00 EE 6B -> 00 EE 6B (但这里应该是FD)
    ]
    
    for i, response_data in enumerate(test_responses):
        print(f"\n=== 测试响应 {i+1} ===")
        print(f"响应数据: {' '.join(f'{b:02X}' for b in response_data)}")
        
        try:
            response = PositionResponse.analyze_response(response_data)
            response.print_summary()
            print("✓ 响应解析成功")
        except Exception as e:
            print(f"✗ 响应解析失败: {e}")