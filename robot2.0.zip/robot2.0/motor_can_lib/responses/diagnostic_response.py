#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
诊断与状态查询响应解析

解析 `xaxa.md` 中列出的读取命令的响应数据：
- 0x1F 固件版本/硬件版本
- 0x20 相电阻/相电感
- 0x21 位置环 PID 参数
- 0x24 总线电压
- 0x27 相电流
- 0x35 电机实时转速
- 0x36 电机实时位置
- 0x37 电机位置误差
- 0x3A 电机状态标志位
- 0x42 驱动配置参数（分包可能）
- 0x43 系统状态参数（分包可能）

仅支持新格式响应：
- `命令码 + 数据/状态 + 校验`（地址不在数据中，地址在 CAN ID）
"""

import struct
from typing import Optional, Dict, Any
from ..core.exceptions import CANError


class DiagnosticResponse:
    """诊断与状态查询响应解析类"""

    KNOWN_COMMAND_CODES = {0x1F, 0x20, 0x21, 0x24, 0x27, 0x35, 0x36, 0x37, 0x3A, 0x42, 0x43}

    def __init__(self, response_data: bytes, address: Optional[int] = None):
        """
        初始化响应数据解析（仅支持新格式）
        
        新格式：首字节为命令码，后续为数据/状态，最后为校验；地址不在数据中。
        """
        self.response_data = response_data or bytes()
        self.address = address if address is not None else 0
        self.command_code = self.response_data[0] if len(self.response_data) > 0 else 0

    def _start_index(self) -> int:
        """返回数据区起始索引（仅新格式，跳过命令码）"""
        return 1

    def _require_len(self, min_len: int) -> None:
        if len(self.response_data) < min_len:
            raise CANError("响应数据长度不足")

    # ===== 具体解析方法 =====
    def parse_fw_hw_version(self) -> Dict[str, Any]:
        start = self._start_index()
        # 至少两字节版本 + 校验
        self._require_len(start + 2 + 1)
        fw_code = self.response_data[start]
        hw_code = self.response_data[start + 1]
        return {
            'address': self.address,
            'command_code': self.command_code,
            'firmware_code': fw_code,
            'hardware_code': hw_code,
            'raw_data': self.response_data
        }

    def parse_phase_res_ind(self) -> Dict[str, Any]:
        start = self._start_index()
        # 两个2字节大端数值
        self._require_len(start + 4 + 1)
        resistance_milliohm, inductance_uH = struct.unpack('>HH', self.response_data[start:start + 4])
        return {
            'address': self.address,
            'command_code': self.command_code,
            'phase_resistance_milliohm': resistance_milliohm,
            'phase_inductance_uH': inductance_uH,
            'raw_data': self.response_data
        }

    def parse_position_pid(self) -> Dict[str, Any]:
        start = self._start_index()
        # Kp、Ki、Kd 各 4 字节大端
        self._require_len(start + 12 + 1)
        kp, ki, kd = struct.unpack('>III', self.response_data[start:start + 12])
        return {
            'address': self.address,
            'command_code': self.command_code,
            'Kp': kp,
            'Ki': ki,
            'Kd': kd,
            'raw_data': self.response_data
        }

    def parse_bus_voltage(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 2 + 1)
        voltage_mv = struct.unpack('>H', self.response_data[start:start + 2])[0]
        return {
            'address': self.address,
            'command_code': self.command_code,
            'bus_voltage_mv': voltage_mv,
            'raw_data': self.response_data
        }

    def parse_phase_current(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 2 + 1)
        current_ma = struct.unpack('>H', self.response_data[start:start + 2])[0]
        return {
            'address': self.address,
            'command_code': self.command_code,
            'phase_current_ma': current_ma,
            'raw_data': self.response_data
        }

    def parse_motor_speed(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 3 + 1)
        sign = self.response_data[start]
        speed_rpm = struct.unpack('>H', self.response_data[start + 1:start + 3])[0]
        signed_rpm = -speed_rpm if sign == 0x01 else speed_rpm
        return {
            'address': self.address,
            'command_code': self.command_code,
            'sign': sign,
            'speed_rpm': signed_rpm,
            'raw_data': self.response_data
        }

    def parse_motor_position(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 5 + 1)
        sign = self.response_data[start]
        position_raw = struct.unpack('>I', self.response_data[start + 1:start + 5])[0]
        multiplier = -1 if sign == 0x01 else 1
        position_deg = multiplier * (position_raw * 360.0 / 65536.0)
        return {
            'address': self.address,
            'command_code': self.command_code,
            'sign': sign,
            'position_raw': position_raw,
            'position_degrees': position_deg,
            'raw_data': self.response_data
        }

    def parse_position_error(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 5 + 1)
        sign = self.response_data[start]
        error_raw = struct.unpack('>I', self.response_data[start + 1:start + 5])[0]
        multiplier = -1 if sign == 0x01 else 1
        error_deg = multiplier * (error_raw * 360.0 / 65536.0)
        return {
            'address': self.address,
            'command_code': self.command_code,
            'sign': sign,
            'error_raw': error_raw,
            'error_degrees': error_deg,
            'raw_data': self.response_data
        }

    def parse_motor_state_flags(self) -> Dict[str, Any]:
        start = self._start_index()
        self._require_len(start + 1 + 1)
        flags = self.response_data[start]
        return {
            'address': self.address,
            'command_code': self.command_code,
            'flags_byte': flags,
            'enabled': bool(flags & 0x01),
            'in_position': bool(flags & 0x02),
            'stalled': bool(flags & 0x04),
            'stall_protection': bool(flags & 0x08),
            'raw_data': self.response_data
        }

    def parse_driver_config(self) -> Dict[str, Any]:
        start = self._start_index()
        if len(self.response_data) <= start:
            raise CANError("驱动配置响应数据长度不足")
        # 详细解析：首字节返回字节数、第二字节参数个数，其余为负载（大端）
        total_len = self.response_data[start]
        param_count = self.response_data[start + 1] if len(self.response_data) > start + 1 else 0
        payload = self.response_data[start + 2:-1]  # 去掉校验

        # 逐字段解析，根据 xaxa.md 文档描述的顺序
        # 注意：不同固件可能存在细微差异，解析时加入边界检查
        idx = 0

        def read_byte() -> int:
            nonlocal idx
            if idx >= len(payload):
                return 0
            val = payload[idx]
            idx += 1
            return val

        def read_u16_be() -> int:
            nonlocal idx
            if idx + 2 > len(payload):
                idx = len(payload)
                return 0
            val = struct.unpack('>H', payload[idx:idx+2])[0]
            idx += 2
            return val

        # 解析字段
        motor_type_code = read_byte()               # 电机类型（例：25=1.8°）
        pulse_mode_code = read_byte()               # 脉冲端口控制模式（0x02=PUL_FOC，其他代表开环）
        comm_func_code = read_byte()                # 通讯端口复用模式（0x02=UART，其它=CAN）
        en_level_code = read_byte()                 # En引脚有效电平（文档示例：0x02=Hold）
        dir_code = read_byte()                      # Dir引脚有效方向（0x00=CW，其他=CCW）
        subdivision_raw = read_byte()               # 细分（0x00=256，否则=值本身）
        subdivision_interp_enabled = (read_byte() == 0x01)  # 细分插补功能
        auto_screen_off_enabled = (read_byte() == 0x01)     # 自动熄屏功能（示例为0x00=Disable）
        open_loop_current_ma = read_u16_be()        # 开环模式工作电流（mA）
        stall_max_current_ma = read_u16_be()        # 闭环模式堵转最大电流（mA）
        max_output_voltage_mv = read_u16_be()       # 闭环模式最大输出电压（mV）
        uart_baud_option = read_byte()              # 串口波特率选项码（例：0x05=115200）
        can_bitrate_option = read_byte()            # CAN速率选项码（例：0x07=500000）
        device_id = read_byte()                     # ID地址
        checksum_mode_code = read_byte()            # 通讯校验方式（例：0x00=固定0x6B）
        command_ack_mode_code = read_byte()         # 控制命令应答模式（例：0x01=只回复确认）
        stall_protect_enabled = (read_byte() == 0x01)       # 堵转保护功能
        stall_speed_threshold_rpm = read_u16_be()    # 堵转转速阈值（RPM）
        stall_current_threshold_ma = read_u16_be()   # 堵转电流阈值（mA）
        stall_time_threshold_ms = read_u16_be()      # 堵转检测时间阈值（ms）
        position_window_raw = read_u16_be()          # 位置到达窗口原始值（单位=0.1°）
        position_window_deg = position_window_raw * 0.1

        # 枚举映射（尽量贴近文档；未知值保留原码）
        motor_type_desc = '1.8° 电机' if motor_type_code == 25 else f'未知({motor_type_code})'
        pulse_mode_desc = 'FOC矢量闭环' if pulse_mode_code == 0x02 else '开环'
        comm_func_desc = '串口/RS232/RS485' if comm_func_code == 0x02 else 'CAN'
        en_level_desc = 'Hold(一直有效)' if en_level_code == 0x02 else f'未知({en_level_code})'
        dir_desc = '顺时针(CW)' if dir_code == 0x00 else '逆时针(CCW)'
        subdivision_value = 256 if subdivision_raw == 0x00 else subdivision_raw

        # 串口波特率和CAN速率的常见映射（部分枚举，根据文档样例）
        uart_baud_map = {0x00: 9600, 0x01: 19200, 0x02: 38400, 0x03: 57600, 0x04: 76800, 0x05: 115200}
        can_rate_map = {0x00: 10000, 0x01: 20000, 0x02: 50000, 0x03: 100000, 0x04: 125000, 0x05: 250000, 0x06: 400000, 0x07: 500000}
        uart_baud_rate = uart_baud_map.get(uart_baud_option)
        can_bitrate_value = can_rate_map.get(can_bitrate_option)

        checksum_mode_desc = '固定校验0x6B' if checksum_mode_code == 0 else f'未知({checksum_mode_code})'
        command_ack_mode_desc = '只回复确认收到命令' if command_ack_mode_code == 1 else f'未知({command_ack_mode_code})'

        result = {
            'address': self.address,
            'command_code': self.command_code,
            'total_len': total_len,
            'param_count': param_count,
            'payload': payload,
            'raw_data': self.response_data,
            # 详细解析字段
            'motor_type_code': motor_type_code,
            'motor_type_desc': motor_type_desc,
            'pulse_mode_code': pulse_mode_code,
            'pulse_mode_desc': pulse_mode_desc,
            'comm_func_code': comm_func_code,
            'comm_func_desc': comm_func_desc,
            'en_level_code': en_level_code,
            'en_level_desc': en_level_desc,
            'dir_code': dir_code,
            'dir_desc': dir_desc,
            'subdivision_raw': subdivision_raw,
            'subdivision_value': subdivision_value,
            'subdivision_interp_enabled': subdivision_interp_enabled,
            'auto_screen_off_enabled': auto_screen_off_enabled,
            'open_loop_current_ma': open_loop_current_ma,
            'stall_max_current_ma': stall_max_current_ma,
            'max_output_voltage_mv': max_output_voltage_mv,
            'uart_baud_option': uart_baud_option,
            'uart_baud_rate': uart_baud_rate,
            'can_bitrate_option': can_bitrate_option,
            'can_bitrate_value': can_bitrate_value,
            'device_id': device_id,
            'checksum_mode_code': checksum_mode_code,
            'checksum_mode_desc': checksum_mode_desc,
            'command_ack_mode_code': command_ack_mode_code,
            'command_ack_mode_desc': command_ack_mode_desc,
            'stall_protect_enabled': stall_protect_enabled,
            'stall_speed_threshold_rpm': stall_speed_threshold_rpm,
            'stall_current_threshold_ma': stall_current_threshold_ma,
            'stall_time_threshold_ms': stall_time_threshold_ms,
            'position_window_raw': position_window_raw,
            'position_window_deg': position_window_deg,
        }
        return result

    def parse_system_status(self) -> Dict[str, Any]:
        start = self._start_index()
        if len(self.response_data) <= start:
            raise CANError("系统状态响应数据长度不足")

        # 详细解析：首字节返回字节数、第二字节参数个数，其余为负载（大端）
        total_len = self.response_data[start]
        param_count = self.response_data[start + 1] if len(self.response_data) > start + 1 else 0
        payload = self.response_data[start + 2:-1]

        idx = 0

        def read_byte() -> int:
            nonlocal idx
            if idx >= len(payload):
                return 0
            val = payload[idx]
            idx += 1
            return val

        def read_u16_be() -> int:
            nonlocal idx
            if idx + 2 > len(payload):
                idx = len(payload)
                return 0
            val = struct.unpack('>H', payload[idx:idx+2])[0]
            idx += 2
            return val

        def read_u32_be() -> int:
            nonlocal idx
            if idx + 4 > len(payload):
                idx = len(payload)
                return 0
            val = struct.unpack('>I', payload[idx:idx+4])[0]
            idx += 4
            return val

        def signed_deg(sign_byte: int, raw_u32: int) -> float:
            multiplier = -1 if sign_byte == 0x01 else 1
            return multiplier * (raw_u32 * 360.0 / 65536.0)

        # 按 xaxa.md 描述的顺序解析九类参数
        bus_voltage_mv = read_u16_be()               # 总线电压 mV
        phase_current_ma = read_u16_be()             # 总线相电流 mA
        encoder_calibrated_value = read_u16_be()     # 校准后编码器值

        target_pos_sign = read_byte()                # 电机目标位置 符号
        target_pos_raw = read_u32_be()               # 电机目标位置 原始值
        target_pos_deg = signed_deg(target_pos_sign, target_pos_raw)

        speed_sign = read_byte()                     # 电机实时转速 符号
        speed_rpm_raw = read_u16_be()                # 电机实时转速 原始值（RPM）
        speed_rpm = -speed_rpm_raw if speed_sign == 0x01 else speed_rpm_raw

        position_sign = read_byte()                  # 电机实时位置 符号
        position_raw = read_u32_be()                 # 电机实时位置 原始值
        position_deg = signed_deg(position_sign, position_raw)

        error_sign = read_byte()                     # 电机位置误差 符号
        error_raw = read_u32_be()                    # 电机位置误差 原始值
        error_deg = signed_deg(error_sign, error_raw)

        ready_flags = read_byte()                    # 就绪状态标志位
        encoder_ready = bool(ready_flags & 0x01)
        calib_table_ready = bool(ready_flags & 0x02)
        homing_running = bool(ready_flags & 0x04)
        homing_failed = bool(ready_flags & 0x08)

        motor_state_flags = read_byte()              # 电机状态标志位
        enabled = bool(motor_state_flags & 0x01)
        in_position = bool(motor_state_flags & 0x02)
        stalled = bool(motor_state_flags & 0x04)
        stall_protection = bool(motor_state_flags & 0x08)

        result = {
            'address': self.address,
            'command_code': self.command_code,
            'total_len': total_len,
            'param_count': param_count,
            'payload': payload,
            'raw_data': self.response_data,
            # 详细解析字段
            'bus_voltage_mv': bus_voltage_mv,
            'phase_current_ma': phase_current_ma,
            'encoder_calibrated_value': encoder_calibrated_value,
            'target_position_sign': target_pos_sign,
            'target_position_raw': target_pos_raw,
            'target_position_degrees': target_pos_deg,
            'speed_sign': speed_sign,
            'speed_rpm': speed_rpm,
            'position_sign': position_sign,
            'position_raw': position_raw,
            'position_degrees': position_deg,
            'error_sign': error_sign,
            'error_raw': error_raw,
            'error_degrees': error_deg,
            'ready_flags_byte': ready_flags,
            'encoder_ready': encoder_ready,
            'calibration_table_ready': calib_table_ready,
            'homing_running': homing_running,
            'homing_failed': homing_failed,
            'motor_state_flags_byte': motor_state_flags,
            'enabled': enabled,
            'in_position': in_position,
            'stalled': stalled,
            'stall_protection': stall_protection,
        }
        return result

    @classmethod
    def parse_response(cls, response_data: bytes, command_code: int, address: Optional[int] = None) -> Dict[str, Any]:
        """根据命令码自动解析响应数据"""
        parser = cls(response_data, address=address)

        if command_code == 0x1F:
            return parser.parse_fw_hw_version()
        elif command_code == 0x20:
            return parser.parse_phase_res_ind()
        elif command_code == 0x21:
            return parser.parse_position_pid()
        elif command_code == 0x24:
            return parser.parse_bus_voltage()
        elif command_code == 0x27:
            return parser.parse_phase_current()
        elif command_code == 0x35:
            return parser.parse_motor_speed()
        elif command_code == 0x36:
            return parser.parse_motor_position()
        elif command_code == 0x37:
            return parser.parse_position_error()
        elif command_code == 0x3A:
            return parser.parse_motor_state_flags()
        elif command_code == 0x42:
            return parser.parse_driver_config()
        elif command_code == 0x43:
            return parser.parse_system_status()
        else:
            raise CANError(f"未知的诊断命令码: 0x{command_code:02X}")