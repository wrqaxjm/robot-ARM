#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
原点回零响应数据解析

解析电机原点回零相关命令的响应数据，包括：
- 设置零点位置响应
- 触发回零响应
- 强制停止回零响应
- 读取回零参数响应
- 修改回零参数响应
- 读取回零状态响应
"""

import struct
from typing import Optional, Dict, Any
from ..core.exceptions import CANError


class HomingResponse:
    """原点回零响应数据解析类"""
    
    # 回零模式定义
    HOMING_MODE_NAMES = {
        0x00: "单圈就近回零",
        0x01: "单圈方向回零",
        0x02: "多圈无限位碰撞回零",
        0x03: "多圈有限位开关回零"
    }
    
    # 回零方向定义
    DIRECTION_NAMES = {
        0x00: "顺时针",
        0x01: "逆时针"
    }
    
    # 读取回零状态(0x3B)的位含义：
    # bit0: 编码器就绪
    # bit1: 校准表就绪
    # bit2: 正在回零
    # bit3: 回零失败
    
    KNOWN_COMMAND_CODES = {0x93, 0x9A, 0x9C, 0x22, 0x4C, 0x3B}

    def __init__(self, response_data: bytes, address: Optional[int] = None):
        """
        初始化响应数据解析（仅支持新格式）
        
        新格式说明：`命令码 + 状态/数据 + 校验`（数据不包含地址，地址在 CAN ID 中）。
        """
        # 原始响应数据
        self.response_data = response_data or bytes()
        # 地址仅从调用方（CAN ID）传入；若无则为 0（显示用途）
        self.address = address if address is not None else 0
        # 命令码为首字节
        self.command_code = self.response_data[0] if len(self.response_data) > 0 else 0
    
    def parse_set_zero_position_response(self) -> Dict[str, Any]:
        """
        解析设置零点位置响应
        
        Returns:
            解析结果字典
        """
        if len(self.response_data) < 3:
            raise CANError("设置零点位置响应数据长度不足")
        # 新格式：状态字节在第 2 字节（索引 1）
        status_index = 1
        result = {
            'address': self.address,
            'command_code': self.command_code,
            'success': self.response_data[status_index] == 0x02,
            'raw_data': self.response_data
        }
        
        return result
    
    def parse_trigger_homing_response(self) -> Dict[str, Any]:
        """
        解析触发回零响应
        
        Returns:
            解析结果字典
        """
        if len(self.response_data) < 3:
            raise CANError("触发回零响应数据长度不足")
        # 新格式：状态字节在第 2 字节（索引 1）
        status_index = 1
        result = {
            'address': self.address,
            'command_code': self.command_code,
            'success': self.response_data[status_index] == 0x02,
            'raw_data': self.response_data
        }
        
        return result
    
    def parse_force_stop_homing_response(self) -> Dict[str, Any]:
        """
        解析强制停止回零响应
        
        Returns:
            解析结果字典
        """
        if len(self.response_data) < 3:
            raise CANError("强制停止回零响应数据长度不足")
        # 新格式：状态字节在第 2 字节（索引 1）
        status_index = 1
        result = {
            'address': self.address,
            'command_code': self.command_code,
            'success': self.response_data[status_index] == 0x02,
            'raw_data': self.response_data
        }
        
        return result
    
    def parse_read_homing_params_response(self) -> Dict[str, Any]:
        """
        解析读取回零参数响应
        
        Returns:
            解析结果字典，包含所有回零参数
        """
        # 起始索引：新格式从第 2 字节开始（索引 1）
        start_index = 1
        # 至少需要 15 字节参数 + 1 校验 + 1 命令码
        if len(self.response_data) < (start_index + 15 + 1):
            raise CANError("读取回零参数响应数据长度不足")
        
        # 解析参数数据 (去掉头和最后的校验字节)
        param_data = self.response_data[start_index:-1]
        
        if len(param_data) < 15:  # 参数数据至少15字节
            raise CANError("回零参数数据长度不足")
        
        # 按照协议解析参数
        # 说明：设备返回的多字节数值为大端（示例：速度 00 1E，超时 00 00 27 10），
        # 之前误按小端解析导致数值偏大（如 0x1E00 = 7680）。
        # 修正为大端解析格式：'>BBHIHHHB'
        homing_mode, direction, speed_rpm, timeout_ms, collision_speed_rpm, \
        collision_current_ma, collision_time_ms, auto_homing_enable = struct.unpack(
            '>BBHIHHHB', param_data[:15]
        )
        
        result = {
            'address': self.address,
            'command_code': self.command_code,
            'homing_mode': homing_mode,
            'homing_mode_name': self.HOMING_MODE_NAMES.get(homing_mode, f"未知模式({homing_mode})"),
            'direction': direction,
            'direction_name': self.DIRECTION_NAMES.get(direction, f"未知方向({direction})"),
            'speed_rpm': speed_rpm,
            'timeout_ms': timeout_ms,
            'collision_speed_rpm': collision_speed_rpm,
            'collision_current_ma': collision_current_ma,
            'collision_time_ms': collision_time_ms,
            'auto_homing_enable': bool(auto_homing_enable),
            'raw_data': self.response_data
        }
        
        return result
    
    def parse_modify_homing_params_response(self) -> Dict[str, Any]:
        """
        解析修改回零参数响应
        
        Returns:
            解析结果字典
        """
        if len(self.response_data) < 3:
            raise CANError("修改回零参数响应数据长度不足")
        # 新格式：状态字节在第 2 字节（索引 1）
        status_index = 1
        result = {
            'address': self.address,
            'command_code': self.command_code,
            'success': self.response_data[status_index] == 0x02,
            'raw_data': self.response_data
        }
        
        return result
    
    def parse_read_homing_status_response(self) -> Dict[str, Any]:
        """
        解析读取回零状态响应
        
        Returns:
            解析结果字典，包含回零状态信息
        """
        # 新格式：状态字节在第 2 字节（索引 1）
        status_index = 1
        if len(self.response_data) <= status_index:
            raise CANError("读取回零状态响应数据长度不足")
        
        status_byte = self.response_data[status_index]

        # 位解析
        encoder_ready = bool(status_byte & 0x01)
        calibration_ready = bool(status_byte & 0x02)
        homing_in_progress = bool(status_byte & 0x04)
        homing_failed = bool(status_byte & 0x08)

        # 派生总结：优先级 失败 > 进行中 > 成功
        if homing_failed:
            state_summary = "回零失败"
        elif homing_in_progress:
            state_summary = "回零中"
        else:
            # 不在回零，且未失败，视为已就绪/成功（依据文档示例 0x03）
            state_summary = "回零成功"

        result = {
            'address': self.address,
            'command_code': self.command_code,
            'status_byte': status_byte,
            'encoder_ready': encoder_ready,
            'calibration_ready': calibration_ready,
            'homing_in_progress': homing_in_progress,
            'homing_failed': homing_failed,
            'state_summary': state_summary,
            'raw_data': self.response_data
        }
        
        return result
    
    def format_homing_params(self, params: Dict[str, Any]) -> str:
        """
        格式化回零参数为可读字符串
        
        Args:
            params: 回零参数字典
            
        Returns:
            格式化的参数字符串
        """
        lines = [
            f"设备地址: {params['address']}",
            f"回零模式: {params['homing_mode_name']} ({params['homing_mode']})",
            f"回零方向: {params['direction_name']} ({params['direction']})",
            f"回零速度: {params['speed_rpm']} RPM",
            f"回零超时: {params['timeout_ms']} ms",
            f"碰撞检测转速: {params['collision_speed_rpm']} RPM",
            f"碰撞检测电流: {params['collision_current_ma']} mA",
            f"碰撞检测时间: {params['collision_time_ms']} ms",
            f"上电自动回零: {'启用' if params['auto_homing_enable'] else '禁用'}"
        ]
        return '\n'.join(lines)
    
    def format_homing_status(self, status: Dict[str, Any]) -> str:
        """
        格式化回零状态为可读字符串
        
        Args:
            status: 回零状态字典
            
        Returns:
            格式化的状态字符串
        """
        lines = [
            f"设备地址: {status['address']}",
            f"回零状态: {status['state_summary']}",
            f"编码器就绪: {'是' if status['encoder_ready'] else '否'}",
            f"校准表就绪: {'是' if status['calibration_ready'] else '否'}",
            f"正在回零: {'是' if status['homing_in_progress'] else '否'}",
            f"回零失败: {'是' if status['homing_failed'] else '否'}",
            f"状态字节: 0x{status['status_byte']:02X}"
        ]
        return '\n'.join(lines)
    
    @classmethod
    def parse_response(cls, response_data: bytes, command_code: int) -> Dict[str, Any]:
        """
        根据命令码自动解析响应数据
        
        Args:
            response_data: 响应数据字节
            command_code: 命令码
            
        Returns:
            解析结果字典
        """
        parser = cls(response_data)
        
        if command_code == 0x93:  # 设置零点位置
            return parser.parse_set_zero_position_response()
        elif command_code == 0x9A:  # 触发回零
            return parser.parse_trigger_homing_response()
        elif command_code == 0x9C:  # 强制停止回零
            return parser.parse_force_stop_homing_response()
        elif command_code == 0x22:  # 读取回零参数
            return parser.parse_read_homing_params_response()
        elif command_code == 0x4C:  # 修改回零参数
            return parser.parse_modify_homing_params_response()
        elif command_code == 0x3B:  # 读取回零状态
            return parser.parse_read_homing_status_response()
        else:
            raise CANError(f"未知的回零命令码: 0x{command_code:02X}")


if __name__ == "__main__":
    # 测试代码
    print("=== 原点回零响应解析测试 ===")
    
    # 测试设置零点位置响应
    print("\n1. 设置零点位置响应:")
    set_zero_response = bytes([0x01, 0x93, 0x01, 0x6B])
    parser = HomingResponse(set_zero_response)
    result = parser.parse_set_zero_position_response()
    print(f"   解析结果: {result}")
    
    # 测试触发回零响应
    print("\n2. 触发回零响应:")
    trigger_response = bytes([0x01, 0x9A, 0x01, 0x6B])
    parser = HomingResponse(trigger_response)
    result = parser.parse_trigger_homing_response()
    print(f"   解析结果: {result}")
    
    # 测试读取回零状态响应
    print("\n3. 读取回零状态响应:")
    status_response = bytes([0x01, 0x3B, 0x02, 0x6B])  # 回零成功状态
    parser = HomingResponse(status_response)
    result = parser.parse_read_homing_status_response()
    print(f"   解析结果: {result}")
    print(f"   格式化状态:\n{parser.format_homing_status(result)}")
    
    # 测试读取回零参数响应（模拟数据）
    print("\n4. 读取回零参数响应:")
    # 构造模拟的参数响应数据
    param_response = bytes([
        0x01, 0x22,  # 地址和命令码
        0x00, 0x00,  # 回零模式和方向
        0x1E, 0x00,  # 速度30 RPM
        0x10, 0x27, 0x00, 0x00,  # 超时10000 ms
        0x2C, 0x01,  # 碰撞检测转速300 RPM
        0x20, 0x03,  # 碰撞检测电流800 mA
        0x3C, 0x00,  # 碰撞检测时间60 ms
        0x00,        # 自动回零禁用
        0x6B         # 校验字节
    ])
    parser = HomingResponse(param_response)
    result = parser.parse_read_homing_params_response()
    print(f"   解析结果: {result}")
    print(f"   格式化参数:\n{parser.format_homing_params(result)}")