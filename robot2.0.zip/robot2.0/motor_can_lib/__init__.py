"""
电机驱动板CAN指令封装库

一个结构清晰的CAN指令库，用于控制电机驱动板。
将指令定义和返回数据含义分开存放，便于维护和扩展。
"""

__version__ = "1.4.2"
__author__ = "Motor CAN Library"

# 导入核心模块
from .core.can_base import MotorCANBase
from .core.exceptions import CANError, CANTimeoutError

# 导入指令模块
from .commands.enable_control import EnableControlCommand
from .commands.speed_control import SpeedControlCommand  
from .commands.stop_control import StopControlCommand
from .commands.position_control import PositionControlCommand
from .commands.sync_control import SyncControlCommand
from .commands.homing_control import HomingControlCommand
from .commands.diagnostic_control import DiagnosticCommand

# 导入响应解析模块
from .responses.enable_response import EnableResponse
from .responses.speed_response import SpeedResponse
from .responses.stop_response import StopResponse
from .responses.position_response import PositionResponse
from .responses.sync_response import SyncResponse
from .responses.homing_response import HomingResponse
from .responses.diagnostic_response import DiagnosticResponse

__all__ = [
    'MotorCANBase',
    'CANError', 'CANTimeoutError',
    'EnableControlCommand', 'SpeedControlCommand', 'StopControlCommand', 'PositionControlCommand', 'SyncControlCommand', 'HomingControlCommand',
    'DiagnosticCommand',
    'EnableResponse', 'SpeedResponse', 'StopResponse', 'PositionResponse', 'SyncResponse', 'HomingResponse', 'DiagnosticResponse'
]