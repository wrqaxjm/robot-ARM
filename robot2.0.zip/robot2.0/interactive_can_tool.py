#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
交互式CAN通信工具
专为CANable设备设计，支持COM11端口，500K波特率，87.5%采样率
使用扩展帧格式进行CAN通信
"""

import can
import sys
import time
from typing import Optional

class InteractiveCANTool:
    """交互式CAN通信工具类"""
    
    def __init__(self):
        """初始化CAN工具"""
        # 固定配置参数
        self.com_port = "COM11"  # 固定使用COM11端口
        self.bitrate = 500000  # 500K波特率
        self.sample_point = 0.875  # 87.5%采样率
        
        self.bus: Optional[can.BusABC] = None  # 修复类型注解
        self.is_connected = False
        
    def show_main_menu(self):
        """显示主菜单"""
        print("\n" + "="*50)
        print("           交互式CAN通信工具")
        print("="*50)
        print(f"配置信息:")
        print(f"  端口: {self.com_port}")
        print(f"  波特率: {self.bitrate} bps")
        print(f"  采样率: {self.sample_point*100}%")
        print(f"  帧类型: 扩展帧")
        print(f"  连接状态: {'已连接' if self.is_connected else '未连接'}")
        print("-"*50)
        print("请选择操作:")
        print("  1. 设备连接")
        print("  2. CAN指令发送")
        print("  3. 位置控制命令")
        print("  4. CAN消息监听")
        print("  5. 断开连接")
        print("  0. 退出程序")
        print("-"*50)
    
    def connect_device(self):
        """连接CANable设备"""
        print(f"\n正在连接到 {self.com_port}...")
        
        try:
            # 创建slcan总线连接，使用bitrate参数而不是BitTiming
            self.bus = can.Bus(
                bustype='slcan',
                channel=self.com_port,
                bitrate=self.bitrate,  # 直接使用bitrate参数
                timeout=0.1,
                sleep_after_open=2  # 连接后等待2秒
            )
            
            self.is_connected = True
            print("✓ 设备连接成功!")
            print(f"✓ 端口: {self.com_port}")
            print(f"✓ 波特率: {self.bitrate} bps")
            print(f"✓ 采样率: {self.sample_point*100}%")
            
            # 获取设备版本信息（如果支持）
            try:
                # 尝试获取版本信息，但不是所有slcan设备都支持此功能
                print("✓ 设备已就绪，可以进行CAN通信")
            except:
                pass  # 某些设备可能不支持版本查询
                
        except Exception as e:
            print(f"✗ 连接失败: {e}")
            print("请检查:")
            print("  - CANable设备是否正确连接")
            print("  - COM11端口是否可用")
            print("  - 设备是否被其他程序占用")
            self.is_connected = False
            
    def disconnect_device(self):
        """断开设备连接"""
        if self.bus and self.is_connected:
            try:
                self.bus.shutdown()
                self.bus = None
                self.is_connected = False
                print("✓ 设备已断开连接")
            except Exception as e:
                print(f"✗ 断开连接时出错: {e}")
        else:
            print("✗ 设备未连接")
    
    def send_can_message(self):
        """发送CAN消息"""
        if not self.is_connected or not self.bus:
            print("✗ 设备未连接，请先连接设备")
            return
            
        print("\n--- CAN消息发送 ---")
        
        # 获取CAN ID
        can_id = self.get_can_id_input()
        if can_id is None:
            return
            
        # 获取数据
        data = self.get_data_input()
        if data is None:
            return
            
        # 确认发送
        print(f"\n准备发送消息:")
        print(f"  CAN ID: 0x{can_id:08X} (扩展帧)")
        print(f"  数据: {' '.join(f'{b:02X}' for b in data)} ({len(data)}字节)")
        
        confirm = input("确认发送? (y/n): ").strip().lower()
        if confirm not in ['y', 'yes', '是']:
            print("✗ 取消发送")
            return
            
        try:
            # 创建CAN消息（扩展帧）
            message = can.Message(
                arbitration_id=can_id,
                data=data,
                is_extended_id=True  # 固定使用扩展帧
            )
            
            # 发送消息
            self.bus.send(message, timeout=1.0)
            print("✓ 消息发送成功!")
            
            # 监听返回消息
            self.listen_for_response()
            
        except Exception as e:
            print(f"✗ 发送失败: {e}")
    
    def send_position_control_command(self):
        """发送位置控制命令（支持分包发送）"""
        if not self.is_connected or not self.bus:
            print("✗ 设备未连接，请先连接设备")
            return
            
        print("\n--- 位置控制命令 ---")
        print("注意: 位置控制命令大于8字节，将使用分包发送")
        
        try:
            # 获取电机地址
            address_input = input("请输入电机地址 (1-255): ").strip()
            if not address_input:
                print("✗ 地址不能为空")
                return
            
            address = int(address_input)
            if address < 1 or address > 255:
                print("✗ 地址超出范围 (1-255)")
                return
            
            # 获取脉冲数参数
            pulse_input = input("请输入目标脉冲数 (0-4294967295): ").strip()
            if not pulse_input:
                print("✗ 脉冲数不能为空")
                return
            
            pulse_count = int(pulse_input)
            if pulse_count < 0 or pulse_count > 4294967295:
                print("✗ 脉冲数超出范围 (0-4294967295)")
                return
            
            # 获取方向参数
            print("请选择旋转方向:")
            print("  0. 顺时针 (CW)")
            print("  1. 逆时针 (CCW)")
            direction_input = input("请输入方向 (0/1): ").strip()
            
            if direction_input not in ["0", "1"]:
                print("✗ 方向必须是 0 或 1")
                return
            
            direction = int(direction_input)
            
            # 获取速度参数
            speed_input = input("请输入运行速度 (RPM, 1-65535, 默认1000): ").strip()
            speed_rpm = 1000  # 默认值
            if speed_input:
                speed_rpm = int(speed_input)
                if speed_rpm < 1 or speed_rpm > 65535:
                    print("✗ 速度值超出范围 (1-65535)")
                    return
            
            # 获取加速度参数
            accel_input = input("请输入加速度档位 (0-255, 默认10): ").strip()
            acceleration = 10  # 默认值
            if accel_input:
                acceleration = int(accel_input)
                if acceleration < 0 or acceleration > 255:
                    print("✗ 加速度档位超出范围 (0-255)")
                    return
            
            # 获取位置模式参数
            print("请选择位置模式:")
            print("  0. 绝对位置模式")
            print("  1. 相对位置模式")
            position_mode_input = input("请输入位置模式 (0/1, 默认0): ").strip()
            position_mode = 0  # 默认绝对位置模式
            if position_mode_input:
                if position_mode_input not in ["0", "1"]:
                    print("✗ 位置模式必须是 0 或 1")
                    return
                position_mode = int(position_mode_input)
            
            # 询问是否启用多机同步
            multi_sync_input = input("是否启用多机同步? (y/N): ").strip().lower()
            multi_sync = multi_sync_input in ['y', 'yes', '是']
            
            # 构建位置控制命令数据
            command_data = self.build_position_command_data(
                address, pulse_count, direction, speed_rpm, 
                acceleration, position_mode, multi_sync
            )
            
            # 显示命令信息
            print(f"\n准备发送位置控制命令:")
            print(f"  电机地址: {address}")
            print(f"  目标脉冲数: {pulse_count}")
            print(f"  方向: {'逆时针' if direction else '顺时针'}")
            print(f"  速度: {speed_rpm} RPM")
            print(f"  加速度: {acceleration}")
            print(f"  位置模式: {'相对位置' if position_mode else '绝对位置'}")
            print(f"  多机同步: {'是' if multi_sync else '否'}")
            print(f"  命令数据长度: {len(command_data)} 字节")
            
            # 确认发送
            confirm = input("确认发送? (y/n): ").strip().lower()
            if confirm not in ['y', 'yes', '是']:
                print("✗ 取消发送")
                return
            
            # 执行分包发送
            self.send_multi_packet_command(command_data)
            
        except ValueError as e:
            print(f"✗ 输入格式错误: {e}")
        except Exception as e:
            print(f"✗ 发生未知错误: {e}")
    
    def build_position_command_data(self, address: int, pulse_count: int, direction: int, 
                                  speed_rpm: int, acceleration: int, position_mode: int, 
                                  multi_sync: bool) -> bytes:
        """构建位置控制命令数据"""
        # 按照PositionControlCommand的格式构建数据
        data = bytearray()
        
        # 地址 (1字节)
        data.append(address)
        
        # 命令码 (1字节) - 位置控制命令码为0xFD
        data.append(0xFD)
        
        # 方向 (1字节)
        data.append(direction)
        
        # 速度 (2字节，小端序)
        data.extend(speed_rpm.to_bytes(2, byteorder='little'))
        
        # 加速度 (1字节)
        data.append(acceleration)
        
        # 脉冲数 (4字节，小端序)
        data.extend(pulse_count.to_bytes(4, byteorder='little'))
        
        # 位置模式 (1字节)
        data.append(position_mode)
        
        # 多机同步标志 (1字节)
        data.append(1 if multi_sync else 0)
        
        # 计算校验和 (1字节)
        checksum = sum(data) & 0xFF
        data.append(checksum)
        
        return bytes(data)
    
    def send_multi_packet_command(self, command_data: bytes):
        """发送分包命令"""
        try:
            # 从命令数据中提取设备地址（第一个字节）
            device_address = command_data[0]
            
            # 按照调试文档的分包方式
            # 包1: 从命令码开始的8字节，CAN ID为(地址 << 8) + 0x00
            # 包2: 剩余数据 + 固定校验字节0x6B，CAN ID为(地址 << 8) + 0x01
            
            # 包1: 从命令码开始的8字节（不包含地址）
            packet1 = command_data[1:9]   # FD 01 05 DC 00 00 00 7D
            
            # 包2: 剩余数据字节 + 固定校验字节0x6B
            remaining_data = command_data[9:12]  # 位置模式、多机同步等
            packet2 = bytes([command_data[1]]) + remaining_data + bytes([0x6B])  # FD + 剩余数据 + 0x6B
            
            # 根据设备地址计算CAN ID：(地址 << 8) + 包序号
            base_can_id = (device_address << 8)  # 使用实际的设备地址
            
            print(f"\n分包发送位置控制命令:")
            print(f"  设备地址: {device_address}")
            print(f"  包1 (CAN ID: 0x{base_can_id:04X}): {' '.join(f'{b:02X}' for b in packet1)}")
            print(f"  包2 (CAN ID: 0x{base_can_id + 1:04X}): {' '.join(f'{b:02X}' for b in packet2)}")
            
            # 发送第一包
            message1 = can.Message(
                arbitration_id=base_can_id,
                data=packet1,
                is_extended_id=True
            )
            if self.bus is not None:
                self.bus.send(message1, timeout=1.0)
                print("✓ 包1发送成功")
            else:
                print("✗ CAN总线未连接")
                return
            
            # 短暂延迟
            time.sleep(0.01)
            
            # 发送第二包
            message2 = can.Message(
                arbitration_id=base_can_id + 1,
                data=packet2,
                is_extended_id=True
            )
            if self.bus is not None:
                self.bus.send(message2, timeout=1.0)
            else:
                print("✗ CAN总线未连接")
                return
            print("✓ 包2发送成功")
            
            print("✓ 位置控制命令发送完成!")
            
            # 监听返回消息
            self.listen_for_response()
            
        except Exception as e:
            print(f"✗ 分包发送失败: {e}")
    
    def listen_for_response(self, timeout: float = 2.0):
        """监听CAN总线上的返回消息"""
        print(f"\n--- 监听返回消息 (超时: {timeout}秒) ---")
        
        start_time = time.time()
        message_count = 0
        
        try:
            while time.time() - start_time < timeout:
                # 尝试接收消息
                received_msg = self.bus.recv(timeout=0.1)  # type: ignore
                
                if received_msg is not None:
                    message_count += 1
                    self.display_received_message(received_msg, message_count)
                    
            if message_count == 0:
                print("✗ 未接收到任何返回消息")
            else:
                print(f"\n✓ 共接收到 {message_count} 条消息")
                
        except Exception as e:
            print(f"✗ 接收消息时出错: {e}")
    
    def display_received_message(self, message: can.Message, count: int):
        """显示接收到的CAN消息"""
        timestamp = time.strftime("%H:%M:%S", time.localtime())
        
        print(f"\n[{count}] 接收时间: {timestamp}")
        print(f"    CAN ID: 0x{message.arbitration_id:08X} ({'扩展帧' if message.is_extended_id else '标准帧'})")
        
        if message.data:
            data_hex = ' '.join(f'{b:02X}' for b in message.data)
            print(f"    数据: {data_hex} ({len(message.data)}字节)")
            
            # 尝试显示ASCII表示（如果可打印）
            try:
                ascii_data = ''.join(chr(b) if 32 <= b <= 126 else '.' for b in message.data)
                print(f"    ASCII: {ascii_data}")
            except:
                pass
        else:
            print("    数据: 无数据")
            
        print(f"    DLC: {message.dlc}")
        if hasattr(message, 'channel'):
             print(f"    通道: {message.channel}")
     
    def continuous_listen(self):
         """持续监听CAN消息"""
         if not self.is_connected or not self.bus:
             print("✗ 设备未连接，请先连接设备")
             return
             
         print("\n--- CAN消息持续监听 ---")
         print("按 Ctrl+C 停止监听")
         print("-" * 40)
         
         message_count = 0
         
         try:
             while True:
                 # 接收消息
                 received_msg = self.bus.recv(timeout=1.0)
                 
                 if received_msg is not None:
                     message_count += 1
                     self.display_received_message(received_msg, message_count)
                     
         except KeyboardInterrupt:
             print(f"\n✓ 监听已停止，共接收到 {message_count} 条消息")
         except Exception as e:
             print(f"\n✗ 监听过程中出错: {e}")
     
    def get_can_id_input(self) -> Optional[int]:
        """获取CAN ID输入"""
        while True:
            try:
                user_input = input("请输入CAN ID (十六进制，如: 0x1FFFFFFF): ").strip()
                
                if not user_input:
                    print("✗ CAN ID不能为空")
                    continue
                
                # 处理十六进制输入
                if user_input.lower().startswith('0x'):
                    can_id = int(user_input, 16)
                else:
                    can_id = int(user_input, 16)
                
                # 验证扩展帧CAN ID范围 (0x0 - 0x1FFFFFFF)
                if can_id < 0 or can_id > 0x1FFFFFFF:
                    print("✗ CAN ID超出扩展帧范围 (0x00000000 - 0x1FFFFFFF)")
                    continue
                    
                return can_id
                
            except ValueError:
                print("✗ 无效的CAN ID格式，请输入十六进制数值")
            except KeyboardInterrupt:
                print("\n✗ 操作已取消")
                return None
    
    def get_data_input(self) -> Optional[bytes]:
        """获取数据输入"""
        while True:
            try:
                user_input = input("请输入数据 (十六进制，空格分隔，如: AA BB CC DD): ").strip()
                
                if not user_input:
                    # 允许空数据
                    return b''
                
                # 分割数据字节
                data_parts = user_input.split()
                
                if len(data_parts) > 8:
                    print("✗ 数据长度不能超过8字节")
                    continue
                
                data_bytes = []
                for part in data_parts:
                    # 处理十六进制输入
                    if part.lower().startswith('0x'):
                        byte_val = int(part, 16)
                    else:
                        byte_val = int(part, 16)
                    
                    if byte_val < 0 or byte_val > 255:
                        print(f"✗ 数据格式错误: 字节值 {part} 超出范围 (0x00-0xFF)")
                        break
                        
                    data_bytes.append(byte_val)
                else:
                    # 所有字节都有效
                    return bytes(data_bytes)
                
            except ValueError as e:
                print(f"✗ 数据格式错误: {e}")
                print("请使用十六进制格式，如: AA BB CC 或 0xAA 0xBB 0xCC")
            except KeyboardInterrupt:
                print("\n✗ 操作已取消")
                return None
    
    def validate_input_range(self, value: str, min_val: int, max_val: int) -> Optional[int]:
        """验证输入值范围"""
        try:
            num_val = int(value, 16) if value.lower().startswith('0x') else int(value, 16)
            if min_val <= num_val <= max_val:
                return num_val
            else:
                print(f"✗ 值超出范围 ({min_val:X} - {max_val:X})")
                return None
        except ValueError:
            print("✗ 无效的十六进制格式")
            return None
    
    def run(self):
        """运行主程序"""
        print("欢迎使用交互式CAN通信工具!")
        print("专为CANable设备设计")
        
        while True:
            try:
                self.show_main_menu()
                choice = input("请选择操作 (0-5): ").strip()
                
                if choice == '1':
                    # 设备连接
                    if self.is_connected:
                        print("✗ 设备已连接")
                    else:
                        self.connect_device()
                        
                elif choice == '2':
                    # CAN指令发送
                    self.send_can_message()
                    
                elif choice == '3':
                    # 位置控制命令
                    self.send_position_control_command()
                    
                elif choice == '4':
                    # CAN消息监听
                    self.continuous_listen()
                    
                elif choice == '5':
                    # 断开连接
                    self.disconnect_device()
                    
                elif choice == '0':
                    # 退出程序
                    print("\n正在退出...")
                    if self.is_connected:
                        self.disconnect_device()
                    print("再见!")
                    break
                    
                else:
                    print("✗ 无效选择，请输入 0-5")
                    
            except KeyboardInterrupt:
                print("\n\n正在退出...")
                if self.is_connected:
                    self.disconnect_device()
                print("再见!")
                break
            except Exception as e:
                print(f"✗ 程序错误: {e}")

def main():
    """主函数"""
    # 检查依赖
    try:
        import can
        import serial
    except ImportError as e:
        print(f"✗ 缺少依赖库: {e}")
        print("请安装依赖: cnpm install python-can")
        sys.exit(1)
    
    # 创建并运行工具
    tool = InteractiveCANTool()
    tool.run()

if __name__ == "__main__":
    main()